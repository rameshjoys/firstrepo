import { useState, useEffect, ReactNode } from "react";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "@/lib/store";
import { fetchCurrentUser } from "@/features/auth/authSlice";
import { setSidebarOpen } from "@/features/ui/uiSlice";
import { useIsMobile } from "@/hooks/use-mobile";
import Header from "./Header";
import Sidebar from "./Sidebar";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const dispatch = useDispatch();
  const { user, isAuthenticated } = useSelector((state: RootState) => state.auth);
  const { isSidebarOpen } = useSelector((state: RootState) => state.ui);
  const isMobile = useIsMobile();
  const [isInitialized, setIsInitialized] = useState(false);
  
  // Fetch current user on initial load
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        dispatch(fetchCurrentUser());
      } finally {
        setIsInitialized(true);
      }
    };
    
    initializeAuth();
  }, [dispatch]);
  
  // Close sidebar on mobile when navigating
  useEffect(() => {
    if (isMobile && isSidebarOpen) {
      dispatch(setSidebarOpen(false));
    }
  }, [isMobile, isSidebarOpen, dispatch]);
  
  // Toggle sidebar handler
  const toggleSidebar = () => {
    dispatch(setSidebarOpen(!isSidebarOpen));
  };
  
  // Loading state while checking authentication
  if (!isInitialized) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  return (
    <div className="flex min-h-screen flex-col">
      <Header 
        user={user} 
        toggleSidebar={toggleSidebar} 
        isMobile={isMobile} 
      />
      
      <div className="flex flex-1">
        {isAuthenticated && (
          <Sidebar
            userType={user?.role || 'user'}
            isOpen={isSidebarOpen}
            onClose={() => dispatch(setSidebarOpen(false))}
            isMobile={isMobile}
          />
        )}
        
        <main className={`flex-1 px-4 py-8 md:px-6 ${isAuthenticated && !isMobile ? 'ml-64' : ''}`}>
          <div className="mx-auto max-w-7xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}