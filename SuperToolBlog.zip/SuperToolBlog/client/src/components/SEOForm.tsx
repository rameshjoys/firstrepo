import { FC, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { seoSchema } from "@/lib/validation";
import { seoApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { LoadingButton } from "@/components/ui/loading-button";
import { Loader2, Sparkles } from "lucide-react";
import { SEOData } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

interface SEOFormProps {
  entityType: "blog" | "tool";
  entityId: number;
  title: string;
  content: string;
  currentSeoTitle?: string;
  currentSeoDescription?: string;
  currentSeoKeywords?: string[];
  onUpdate: (seoData: {
    seoTitle: string;
    seoDescription: string;
    seoKeywords: string[];
  }) => void;
}

const SEOForm: FC<SEOFormProps> = ({
  entityType,
  entityId,
  title,
  content,
  currentSeoTitle,
  currentSeoDescription,
  currentSeoKeywords,
  onUpdate,
}) => {
  const { toast } = useToast();
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationResult, setOptimizationResult] = useState<SEOData | null>(null);

  const form = useForm<z.infer<typeof seoSchema>>({
    resolver: zodResolver(seoSchema),
    defaultValues: {
      seoTitle: currentSeoTitle || title,
      seoDescription: currentSeoDescription || "",
      seoKeywords: currentSeoKeywords || [],
    },
  });

  const onSubmit = (values: z.infer<typeof seoSchema>) => {
    onUpdate(values);
  };

  const handleKeywordRemove = (index: number) => {
    const currentKeywords = form.getValues("seoKeywords");
    const updatedKeywords = [...currentKeywords];
    updatedKeywords.splice(index, 1);
    form.setValue("seoKeywords", updatedKeywords);
  };

  const handleKeywordAdd = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && e.currentTarget.value) {
      e.preventDefault();
      const keyword = e.currentTarget.value.trim();
      const currentKeywords = form.getValues("seoKeywords");
      
      if (keyword && !currentKeywords.includes(keyword)) {
        form.setValue("seoKeywords", [...currentKeywords, keyword]);
        e.currentTarget.value = "";
      }
    }
  };

  const optimizeSEO = async () => {
    setIsOptimizing(true);
    try {
      const result = await seoApi.optimizeSEO(entityType, entityId, content);
      setOptimizationResult(result);
      
      // Automatically apply the optimized values
      form.setValue("seoTitle", result.title);
      form.setValue("seoDescription", result.description);
      form.setValue("seoKeywords", result.keywords);
      
      toast({
        title: "SEO Optimization Complete",
        description: "AI suggestions have been applied to the form.",
      });
    } catch (error) {
      toast({
        title: "Optimization Failed",
        description: "An error occurred while optimizing SEO.",
        variant: "destructive",
      });
    } finally {
      setIsOptimizing(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>SEO Optimization</CardTitle>
        <CardDescription>
          Optimize your content for search engines to increase visibility.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="seoTitle"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>SEO Title</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="Enter SEO title (max 60 characters)"
                      maxLength={60}
                    />
                  </FormControl>
                  <div className="text-xs text-muted-foreground">
                    {field.value?.length || 0}/60 characters
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="seoDescription"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Meta Description</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      placeholder="Enter meta description (max 160 characters)"
                      maxLength={160}
                    />
                  </FormControl>
                  <div className="text-xs text-muted-foreground">
                    {field.value?.length || 0}/160 characters
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="seoKeywords"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Keywords</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Type a keyword and press Enter"
                      onKeyDown={handleKeywordAdd}
                    />
                  </FormControl>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {field.value?.map((keyword, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="flex items-center gap-1"
                      >
                        {keyword}
                        <button
                          type="button"
                          className="ml-1 text-xs hover:text-destructive"
                          onClick={() => handleKeywordRemove(index)}
                        >
                          ✕
                        </button>
                      </Badge>
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-2">
              <Button
                type="button"
                variant="outline"
                onClick={optimizeSEO}
                disabled={isOptimizing}
              >
                {isOptimizing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Optimizing...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" />
                    Generate SEO Suggestions
                  </>
                )}
              </Button>
              <LoadingButton type="submit" isLoading={form.formState.isSubmitting}>
                Save SEO Settings
              </LoadingButton>
            </div>
          </form>
        </Form>

        {optimizationResult && (
          <div className="mt-6 border-t pt-4">
            <h3 className="text-lg font-medium mb-2">SEO Suggestions</h3>
            <div className="space-y-3">
              {optimizationResult.suggestions.map((suggestion, index) => (
                <div key={index} className="bg-muted p-3 rounded text-sm">
                  {suggestion}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SEOForm;
