import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Settings,
  Package,
  List,
  BookOpen,
  Layers,
  Users,
  BarChart3,
  Search,
  X
} from "lucide-react";

interface SidebarProps {
  userType: string;
  isOpen: boolean;
  onClose: () => void;
  isMobile: boolean;
}

interface SidebarLink {
  href: string;
  label: string;
  icon: React.ReactNode;
  roles: string[];
}

export default function Sidebar({ userType, isOpen, onClose, isMobile }: SidebarProps) {
  const [location] = useLocation();
  
  // Define sidebar links with role-based access
  const links: SidebarLink[] = [
    {
      href: "/dashboard",
      label: "Dashboard",
      icon: <LayoutDashboard className="h-5 w-5" />,
      roles: ["user", "admin", "superadmin"],
    },
    {
      href: "/tools",
      label: "Tools",
      icon: <Package className="h-5 w-5" />,
      roles: ["user", "admin", "superadmin"],
    },
    {
      href: "/blogs",
      label: "Blogs",
      icon: <BookOpen className="h-5 w-5" />,
      roles: ["user", "admin", "superadmin"],
    },
    {
      href: "/comparison",
      label: "Compare Tools",
      icon: <BarChart3 className="h-5 w-5" />,
      roles: ["user", "admin", "superadmin"],
    },
    {
      href: "/categories",
      label: "Categories",
      icon: <Layers className="h-5 w-5" />,
      roles: ["admin", "superadmin"],
    },
    {
      href: "/users",
      label: "Users",
      icon: <Users className="h-5 w-5" />,
      roles: ["admin", "superadmin"],
    },
    {
      href: "/settings",
      label: "Settings",
      icon: <Settings className="h-5 w-5" />,
      roles: ["user", "admin", "superadmin"],
    },
  ];

  // Filter links based on user role
  const filteredLinks = links.filter((link) => link.roles.includes(userType));

  return (
    <>
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex h-full w-64 flex-col border-r bg-background transition-transform duration-300 ease-in-out",
          isMobile && !isOpen && "-translate-x-full",
          isMobile && isOpen && "translate-x-0",
          !isMobile && "translate-x-0 relative"
        )}
      >
        {/* Sidebar header with close button for mobile */}
        <div className="flex items-center justify-between h-16 px-4 border-b">
          <h2 className="text-lg font-semibold">Menu</h2>
          {isMobile && (
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-5 w-5" />
              <span className="sr-only">Close sidebar</span>
            </Button>
          )}
        </div>
        
        {/* Sidebar navigation */}
        <nav className="flex-1 overflow-auto p-4">
          <ul className="space-y-2">
            {filteredLinks.map((link) => (
              <li key={link.href}>
                <Button
                  variant={location === link.href ? "default" : "ghost"}
                  className={cn(
                    "w-full justify-start",
                    location === link.href
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-accent hover:text-accent-foreground"
                  )}
                  onClick={() => {
                    if (isMobile) {
                      onClose();
                    }
                    window.location.href = link.href;
                  }}
                >
                  {link.icon}
                  <span className="ml-2">{link.label}</span>
                </Button>
              </li>
            ))}
          </ul>
        </nav>
        
        {/* App info */}
        <div className="border-t p-4">
          <div className="text-center">
            <p className="text-sm text-muted-foreground">ToolBlogHub</p>
            <p className="text-xs text-muted-foreground mt-1">v1.0.0</p>
          </div>
        </div>
      </aside>
    </>
  );
}