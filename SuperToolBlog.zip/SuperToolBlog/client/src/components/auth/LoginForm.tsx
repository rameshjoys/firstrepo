import { FC, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { loginSchema } from "@/lib/validation";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { LoadingButton } from "@/components/ui/loading-button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, Mail, Lock } from "lucide-react";

interface LoginFormProps {
  redirectTo?: string;
}

const LoginForm: FC<LoginFormProps> = ({ redirectTo = "/dashboard" }) => {
  const { login, error, clearAuthError } = useAuth();
  const [, setLocation] = useLocation();
  const [generalError, setGeneralError] = useState<string | null>(null);
  
  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });
  
  const onSubmit = async (values: z.infer<typeof loginSchema>) => {
    setGeneralError(null);
    clearAuthError();
    
    try {
      const success = await login(values.email, values.password);
      if (success) {
        setLocation(redirectTo);
      } else {
        setGeneralError("Invalid email or password");
      }
    } catch (err) {
      setGeneralError("An unexpected error occurred. Please try again.");
    }
  };
  
  return (
    <div className="space-y-6">
      {(error || generalError) && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {error || generalError}
          </AlertDescription>
        </Alert>
      )}
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="your-email@example.com"
                      type="email"
                      autoComplete="email"
                      className="pl-10"
                      {...field}
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Password</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="••••••••"
                      type="password"
                      autoComplete="current-password"
                      className="pl-10"
                      {...field}
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex justify-end">
            <Link href="/forgot-password">
              <a className="text-sm text-primary hover:underline">
                Forgot password?
              </a>
            </Link>
          </div>
          
          <LoadingButton 
            type="submit" 
            className="w-full"
            isLoading={form.formState.isSubmitting}
          >
            Log in
          </LoadingButton>
        </form>
      </Form>
      
      <div className="text-center">
        <p className="text-sm text-muted-foreground">
          Don't have an account?{" "}
          <Link href="/signup">
            <a className="text-primary font-medium hover:underline">
              Sign up
            </a>
          </Link>
        </p>
      </div>
    </div>
  );
};

export default LoginForm;
