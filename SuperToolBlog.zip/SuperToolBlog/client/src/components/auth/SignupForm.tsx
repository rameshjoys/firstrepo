import { FC, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link, useLocation } from "wouter";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/lib/store";
import { signup } from "@/features/auth/authSlice";
import { signupSchema } from "@/lib/validation";
import { useAuth } from "@/hooks/use-auth";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { LoadingButton } from "@/components/ui/loading-button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, User, Mail, Lock } from "lucide-react";

interface SignupFormProps {}

const SignupForm: FC<SignupFormProps> = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { error, clearAuthError } = useAuth();
  const [, setLocation] = useLocation();
  const [generalError, setGeneralError] = useState<string | null>(null);
  const [signupSuccess, setSignupSuccess] = useState<boolean>(false);
  const [userId, setUserId] = useState<number | null>(null);
  
  const form = useForm<z.infer<typeof signupSchema>>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });
  
  const onSubmit = async (values: z.infer<typeof signupSchema>) => {
    setGeneralError(null);
    clearAuthError();
    
    try {
      const result = await dispatch(signup({
        username: values.username,
        email: values.email,
        password: values.password,
        role: "user" // Default role for new signups
      })).unwrap();
      
      if (result && result.user) {
        setSignupSuccess(true);
        setUserId(result.user.id);
        
        // Redirect to verification page after signup success
        setLocation(`/verify-email?userId=${result.user.id}`);
      } else {
        setGeneralError("Failed to create account. Please try again.");
      }
    } catch (err) {
      setGeneralError("An unexpected error occurred. Please try again.");
    }
  };
  
  return (
    <div className="space-y-6">
      {(error || generalError) && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {error || generalError}
          </AlertDescription>
        </Alert>
      )}
      
      {signupSuccess && (
        <Alert>
          <AlertDescription>
            Account created successfully! Please check your email to verify your account.
          </AlertDescription>
        </Alert>
      )}
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Username</FormLabel>
                <FormControl>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="johnsmith"
                      autoComplete="username"
                      className="pl-10"
                      {...field}
                    />
                  </div>
                </FormControl>
                <FormDescription>
                  This will be your display name on the platform.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="your-email@example.com"
                      type="email"
                      autoComplete="email"
                      className="pl-10"
                      {...field}
                    />
                  </div>
                </FormControl>
                <FormDescription>
                  You'll need to verify this email address.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Password</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="••••••••"
                      type="password"
                      autoComplete="new-password"
                      className="pl-10"
                      {...field}
                    />
                  </div>
                </FormControl>
                <FormDescription>
                  Must be at least 6 characters with uppercase, lowercase and numbers.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="confirmPassword"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Confirm Password</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="••••••••"
                      type="password"
                      autoComplete="new-password"
                      className="pl-10"
                      {...field}
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <LoadingButton 
            type="submit" 
            className="w-full"
            isLoading={form.formState.isSubmitting}
          >
            Sign up
          </LoadingButton>
        </form>
      </Form>
      
      <div className="text-center">
        <p className="text-sm text-muted-foreground">
          Already have an account?{" "}
          <Link href="/login">
            <a className="text-primary font-medium hover:underline">
              Log in
            </a>
          </Link>
        </p>
      </div>
    </div>
  );
};

export default SignupForm;
