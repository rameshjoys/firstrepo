import { FC, useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { verifyEmailSchema } from "@/lib/validation";
import { useAuth } from "@/hooks/use-auth";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { LoadingButton } from "@/components/ui/loading-button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, CheckCircle2, RefreshCw } from "lucide-react";

interface VerifyEmailProps {
  userId: number;
}

const VerifyEmail: FC<VerifyEmailProps> = ({ userId }) => {
  const { verifyEmail, error, clearAuthError } = useAuth();
  const [, setLocation] = useLocation();
  const [verificationSuccess, setVerificationSuccess] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [generalError, setGeneralError] = useState<string | null>(null);
  
  const form = useForm<z.infer<typeof verifyEmailSchema>>({
    resolver: zodResolver(verifyEmailSchema),
    defaultValues: {
      code: "",
    },
  });
  
  useEffect(() => {
    // Clean up error state when component unmounts
    return () => {
      clearAuthError();
    };
  }, [clearAuthError]);
  
  const onSubmit = async (values: z.infer<typeof verifyEmailSchema>) => {
    setGeneralError(null);
    clearAuthError();
    
    try {
      const result = await verifyEmail(userId, values.code);
      
      if (result) {
        setVerificationSuccess(true);
        // Redirect to login after verification
        setTimeout(() => {
          setLocation("/login");
        }, 3000);
      } else {
        setGeneralError("Invalid verification code. Please try again.");
      }
    } catch (err) {
      setGeneralError("An unexpected error occurred. Please try again.");
    }
  };
  
  const handleResendCode = () => {
    setIsResending(true);
    setGeneralError(null);
    
    // In a real implementation, you would call an API to resend the code
    setTimeout(() => {
      setIsResending(false);
      // Show success message for resending
      setGeneralError("Verification code has been resent to your email.");
    }, 2000);
  };
  
  if (verificationSuccess) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-green-600">
            <CheckCircle2 className="mr-2 h-5 w-5" />
            Email Verified
          </CardTitle>
          <CardDescription>
            Your email has been successfully verified.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-center text-sm text-muted-foreground">
            You will be redirected to the login page in a moment.
          </p>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button onClick={() => setLocation("/login")}>
            Go to Login
          </Button>
        </CardFooter>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Verify Your Email</CardTitle>
        <CardDescription>
          We've sent a verification code to your email address. Please enter it below to verify your account.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {(error || generalError) && (
          <Alert variant={generalError?.includes("resent") ? "default" : "destructive"} className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {error || generalError}
            </AlertDescription>
          </Alert>
        )}
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Verification Code</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter verification code"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <LoadingButton 
              type="submit" 
              className="w-full"
              isLoading={form.formState.isSubmitting}
            >
              Verify Email
            </LoadingButton>
          </form>
        </Form>
      </CardContent>
      <CardFooter className="flex flex-col">
        <div className="text-sm text-muted-foreground mb-4">
          Didn't receive the code? Check your spam folder or request a new one.
        </div>
        <Button
          variant="outline"
          className="w-full"
          onClick={handleResendCode}
          disabled={isResending}
        >
          {isResending ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Resending code...
            </>
          ) : (
            "Resend Verification Code"
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default VerifyEmail;
