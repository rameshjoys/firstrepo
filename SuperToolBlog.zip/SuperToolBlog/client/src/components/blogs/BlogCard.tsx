import { FC } from "react";
import { Link } from "wouter";
import { Blog } from "@shared/schema";
import { Calendar, Eye, Edit, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { formatDistanceToNow } from "date-fns";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/lib/store";
import { deleteBlog } from "@/features/blogs/blogsSlice";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface BlogCardProps {
  blog: Blog;
  isOwner?: boolean;
}

const BlogCard: FC<BlogCardProps> = ({ blog, isOwner = false }) => {
  const dispatch = useDispatch<AppDispatch>();
  const { toast } = useToast();
  const { hasRole } = useAuth();
  
  const canEdit = isOwner || hasRole(["admin", "superadmin"]);
  const canDelete = isOwner || hasRole(["admin", "superadmin"]);
  
  const handleDelete = async () => {
    try {
      await dispatch(deleteBlog(blog.id)).unwrap();
      toast({
        title: "Blog Deleted",
        description: "The blog post has been deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete the blog post",
        variant: "destructive",
      });
    }
  };
  
  // Format date for display
  const formatDate = (dateString?: string) => {
    if (!dateString) return "Unknown date";
    
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (error) {
      return "Invalid date";
    }
  };
  
  // Extract plain text from JSON content for excerpt
  const getExcerpt = () => {
    if (blog.excerpt) return blog.excerpt;
    
    try {
      const contentObj = JSON.parse(blog.content);
      if (contentObj && contentObj.blocks) {
        const textBlocks = contentObj.blocks.filter((block: any) => 
          block.type === 'paragraph' || block.type === 'header'
        );
        if (textBlocks.length > 0) {
          const text = textBlocks[0].data.text;
          return text.length > 120 ? `${text.substring(0, 120)}...` : text;
        }
      }
      return "No content preview available";
    } catch (error) {
      // If content is not valid JSON or has a different structure
      const textContent = blog.content.replace(/<[^>]*>?/gm, '');
      return textContent.length > 120 ? `${textContent.substring(0, 120)}...` : textContent;
    }
  };

  return (
    <Card className="overflow-hidden flex flex-col h-full">
      {blog.featuredImageUrl ? (
        <div className="aspect-video overflow-hidden">
          <img
            src={blog.featuredImageUrl}
            alt={blog.title}
            className="object-cover w-full h-full"
          />
        </div>
      ) : (
        <div className="aspect-video bg-muted flex items-center justify-center">
          <span className="text-muted-foreground">No featured image</span>
        </div>
      )}
      
      <CardHeader className="p-4 pb-0">
        <div className="flex items-center gap-2 mb-2">
          {blog.status === "published" ? (
            <Badge variant="outline" className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300">
              Published
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-300">
              Draft
            </Badge>
          )}
          {blog.categoryId && (
            <Badge variant="secondary">
              {/* Would normally fetch category name by ID */}
              Category {blog.categoryId}
            </Badge>
          )}
        </div>
        
        <Link href={`/blogs/${blog.id}`}>
          <a className="text-xl font-bold hover:text-primary transition-colors line-clamp-2">
            {blog.title}
          </a>
        </Link>
        
        <div className="flex items-center text-xs text-muted-foreground mt-1">
          <Calendar className="h-3 w-3 mr-1" />
          <span>
            {blog.status === "published" && blog.publishedAt 
              ? formatDate(blog.publishedAt) 
              : formatDate(blog.updatedAt || blog.createdAt)}
          </span>
          {blog.viewCount !== undefined && blog.viewCount > 0 && (
            <span className="ml-3 flex items-center">
              <Eye className="h-3 w-3 mr-1" />
              {blog.viewCount} views
            </span>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="p-4 flex-grow">
        <p className="text-muted-foreground line-clamp-3 text-sm">
          {getExcerpt()}
        </p>
        
        {blog.tags && blog.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-3">
            {blog.tags.slice(0, 3).map((tag, i) => (
              <Badge key={i} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
            {blog.tags.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{blog.tags.length - 3}
              </Badge>
            )}
          </div>
        )}
      </CardContent>
      
      <CardFooter className="p-4 pt-0 flex justify-between">
        <Link href={`/blogs/${blog.id}`}>
          <Button variant="link" className="p-0 h-auto" size="sm">
            Read More
          </Button>
        </Link>
        
        {(canEdit || canDelete) && (
          <div className="flex gap-2">
            {canEdit && (
              <Link href={`/blogs/${blog.id}/edit`}>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Edit className="h-4 w-4" />
                  <span className="sr-only">Edit</span>
                </Button>
              </Link>
            )}
            
            {canDelete && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                    <Trash2 className="h-4 w-4" />
                    <span className="sr-only">Delete</span>
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Blog Post</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to delete "{blog.title}"? This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        )}
      </CardFooter>
    </Card>
  );
};

export default BlogCard;
