import { FC, useCallback, useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/lib/store";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { fetchCategories } from "@/features/categories/categoriesSlice";
import { createBlog, updateBlog } from "@/features/blogs/blogsSlice";
import { Blog } from "@shared/schema";
import { blogSchema } from "@/lib/validation";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { LoadingButton } from "@/components/ui/loading-button";
import { Badge } from "@/components/ui/badge";
import SEOForm from "@/components/SEOForm";
import { useToast } from "@/hooks/use-toast";
import { useSelector } from "react-redux";
import { RootState } from "@/lib/store";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bold,
  Italic,
  Underline,
  Heading,
  List,
  ListOrdered,
  Link as LinkIcon,
  Image,
  Code,
  Quote,
  FileText,
  Eye,
  Save,
  CheckCircle,
  X
} from "lucide-react";

// Import and setup editor
import { createReactEditorJS } from 'react-editor-js';
import { EDITOR_JS_TOOLS } from './editorTools';

const ReactEditorJS = createReactEditorJS();

interface BlogEditorProps {
  blog?: Blog;
  isEditMode?: boolean;
}

const BlogEditor: FC<BlogEditorProps> = ({ blog, isEditMode = false }) => {
  const [location, setLocation] = useLocation();
  const dispatch = useDispatch<AppDispatch>();
  const { toast } = useToast();
  const { categories } = useSelector((state: RootState) => state.categories);
  
  const [editorInstance, setEditorInstance] = useState<any>(null);
  const [previewMode, setPreviewMode] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [isSavingDraft, setIsSavingDraft] = useState(false);
  
  const form = useForm<z.infer<typeof blogSchema>>({
    resolver: zodResolver(blogSchema),
    defaultValues: {
      title: blog?.title || "",
      content: blog?.content || "",
      excerpt: blog?.excerpt || "",
      status: blog?.status || "draft",
      categoryId: blog?.categoryId || undefined,
      tags: blog?.tags || [],
      featuredImageUrl: blog?.featuredImageUrl || "",
      seoTitle: blog?.seoTitle || "",
      seoDescription: blog?.seoDescription || "",
      seoKeywords: blog?.seoKeywords || [],
    },
  });
  
  // Initialize the editor with content from the blog if in edit mode
  const initializeEditor = useCallback(() => {
    try {
      if (blog?.content) {
        return JSON.parse(blog.content);
      }
    } catch (error) {
      console.error("Failed to parse blog content:", error);
    }
    
    return {
      blocks: []
    };
  }, [blog]);
  
  // Fetch categories on component mount
  useEffect(() => {
    dispatch(fetchCategories());
  }, [dispatch]);
  
  const handleSaveContent = async () => {
    if (editorInstance) {
      try {
        const savedData = await editorInstance.save();
        return JSON.stringify(savedData);
      } catch (error) {
        console.error("Failed to save editor content:", error);
        return "";
      }
    }
    return "";
  };
  
  const handleTagInput = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && e.currentTarget.value.trim()) {
      e.preventDefault();
      const tag = e.currentTarget.value.trim();
      const currentTags = form.getValues("tags") || [];
      
      if (!currentTags.includes(tag)) {
        form.setValue("tags", [...currentTags, tag]);
        e.currentTarget.value = "";
      }
    }
  };
  
  const handleTagRemove = (tagToRemove: string) => {
    const currentTags = form.getValues("tags") || [];
    form.setValue(
      "tags",
      currentTags.filter((tag) => tag !== tagToRemove)
    );
  };
  
  const handleEditorReady = (instance: any) => {
    setEditorInstance(instance);
  };
  
  const saveBlog = async (status: "draft" | "published") => {
    try {
      const content = await handleSaveContent();
      if (!content) {
        toast({
          title: "Error",
          description: "Failed to save blog content",
          variant: "destructive",
        });
        return;
      }
      
      const values = form.getValues();
      const blogData = {
        ...values,
        content,
        status,
      };
      
      if (isEditMode && blog) {
        status === "draft" ? setIsSavingDraft(true) : setIsPublishing(true);
        await dispatch(updateBlog({ id: blog.id, blog: blogData })).unwrap();
        toast({
          title: "Success",
          description: status === "published" 
            ? "Blog published successfully" 
            : "Blog saved as draft",
        });
      } else {
        status === "draft" ? setIsSavingDraft(true) : setIsPublishing(true);
        await dispatch(createBlog(blogData)).unwrap();
        toast({
          title: "Success",
          description: status === "published" 
            ? "Blog published successfully" 
            : "Blog saved as draft",
        });
      }
      
      setLocation("/blogs");
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save blog",
        variant: "destructive",
      });
    } finally {
      setIsSavingDraft(false);
      setIsPublishing(false);
    }
  };
  
  const onSubmit = async (values: z.infer<typeof blogSchema>) => {
    await saveBlog(values.status);
  };
  
  const handleSEOUpdate = (seoData: {
    seoTitle: string;
    seoDescription: string;
    seoKeywords: string[];
  }) => {
    form.setValue("seoTitle", seoData.seoTitle);
    form.setValue("seoDescription", seoData.seoDescription);
    form.setValue("seoKeywords", seoData.seoKeywords);
    
    toast({
      title: "SEO Settings Updated",
      description: "SEO settings have been updated successfully",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">
          {isEditMode ? "Edit Blog Post" : "Create New Blog Post"}
        </h1>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setPreviewMode(!previewMode)}
          >
            {previewMode ? <FileText className="mr-2 h-4 w-4" /> : <Eye className="mr-2 h-4 w-4" />}
            {previewMode ? "Edit Mode" : "Preview"}
          </Button>
          <LoadingButton
            variant="outline"
            onClick={() => saveBlog("draft")}
            isLoading={isSavingDraft}
            disabled={isSavingDraft || isPublishing}
            loadingText="Saving..."
          >
            <Save className="mr-2 h-4 w-4" />
            Save Draft
          </LoadingButton>
          <LoadingButton
            onClick={() => saveBlog("published")}
            isLoading={isPublishing}
            disabled={isSavingDraft || isPublishing}
            loadingText="Publishing..."
          >
            <CheckCircle className="mr-2 h-4 w-4" />
            Publish
          </LoadingButton>
        </div>
      </div>

      <Tabs defaultValue="content">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="content">Content</TabsTrigger>
          <TabsTrigger value="seo">SEO Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="content">
          <Card>
            <CardContent className="p-6">
              <Form {...form}>
                <form className="space-y-8">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter blog title"
                            className="text-xl font-heading font-semibold"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="categoryId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select
                            onValueChange={(value) => 
                              form.setValue("categoryId", value ? parseInt(value) : undefined)
                            }
                            defaultValue={field.value?.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {categories.map((category) => (
                                <SelectItem key={category.id} value={category.id.toString()}>
                                  {category.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Status</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="draft">Draft</SelectItem>
                              <SelectItem value="published">Published</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="excerpt"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Excerpt</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Brief excerpt for the blog post (max 160 characters)"
                            {...field}
                            maxLength={160}
                          />
                        </FormControl>
                        <div className="text-xs text-muted-foreground mt-1">
                          {field.value ? field.value.length : 0}/160 characters
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div>
                    <FormLabel>Tags</FormLabel>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {form.watch("tags")?.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="flex items-center gap-1">
                          {tag}
                          <button
                            type="button"
                            className="ml-1 rounded-full hover:bg-muted p-1"
                            onClick={() => handleTagRemove(tag)}
                          >
                            <X className="h-3 w-3" />
                            <span className="sr-only">Remove</span>
                          </button>
                        </Badge>
                      ))}
                    </div>
                    <Input
                      placeholder="Type a tag and press Enter"
                      onKeyDown={handleTagInput}
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Press Enter to add tags
                    </p>
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="featuredImageUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Featured Image URL</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="https://example.com/image.jpg"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div>
                    <FormLabel>Content</FormLabel>
                    <div className="border border-input rounded-md mt-1 bg-background">
                      <div className="flex flex-wrap p-2 gap-1 border-b">
                        <Button type="button" variant="ghost" size="sm" className="h-8 px-2 py-1">
                          <Bold className="h-4 w-4" />
                        </Button>
                        <Button type="button" variant="ghost" size="sm" className="h-8 px-2 py-1">
                          <Italic className="h-4 w-4" />
                        </Button>
                        <Button type="button" variant="ghost" size="sm" className="h-8 px-2 py-1">
                          <Underline className="h-4 w-4" />
                        </Button>
                        <Separator orientation="vertical" className="mx-1 h-8" />
                        <Button type="button" variant="ghost" size="sm" className="h-8 px-2 py-1">
                          <Heading className="h-4 w-4" />
                        </Button>
                        <Button type="button" variant="ghost" size="sm" className="h-8 px-2 py-1">
                          <List className="h-4 w-4" />
                        </Button>
                        <Button type="button" variant="ghost" size="sm" className="h-8 px-2 py-1">
                          <ListOrdered className="h-4 w-4" />
                        </Button>
                        <Separator orientation="vertical" className="mx-1 h-8" />
                        <Button type="button" variant="ghost" size="sm" className="h-8 px-2 py-1">
                          <LinkIcon className="h-4 w-4" />
                        </Button>
                        <Button type="button" variant="ghost" size="sm" className="h-8 px-2 py-1">
                          <Image className="h-4 w-4" />
                        </Button>
                        <Button type="button" variant="ghost" size="sm" className="h-8 px-2 py-1">
                          <Code className="h-4 w-4" />
                        </Button>
                        <Separator orientation="vertical" className="mx-1 h-8" />
                        <Button type="button" variant="ghost" size="sm" className="h-8 px-2 py-1">
                          <Quote className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <div className="p-4 min-h-[400px]">
                        <ReactEditorJS
                          tools={EDITOR_JS_TOOLS}
                          defaultValue={initializeEditor()}
                          onInitialize={handleEditorReady}
                        />
                      </div>
                    </div>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="seo">
          <SEOForm
            entityType="blog"
            entityId={blog?.id || 0}
            title={form.getValues("title")}
            content={form.getValues("content")}
            currentSeoTitle={form.getValues("seoTitle")}
            currentSeoDescription={form.getValues("seoDescription")}
            currentSeoKeywords={form.getValues("seoKeywords")}
            onUpdate={handleSEOUpdate}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default BlogEditor;
