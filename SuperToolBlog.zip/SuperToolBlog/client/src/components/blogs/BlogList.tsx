import { FC, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "wouter";
import { RootState, AppDispatch } from "@/lib/store";
import { fetchBlogs } from "@/features/blogs/blogsSlice";
import BlogCard from "./BlogCard";
import { Button } from "@/components/ui/button";
import { Plus, RefreshCw, FileText } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";

interface BlogListProps {
  filters?: {
    search?: string;
    categoryId?: number;
    authorId?: number;
    status?: string;
    sort?: string;
  };
}

const BlogList: FC<BlogListProps> = ({ filters }) => {
  const dispatch = useDispatch<AppDispatch>();
  const { blogs, isLoading, error } = useSelector((state: RootState) => state.blogs);
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    dispatch(fetchBlogs(filters));
  }, [dispatch, filters]);

  if (error) {
    return (
      <div className="py-8 text-center">
        <p className="text-destructive mb-4">{error}</p>
        <Button onClick={() => dispatch(fetchBlogs(filters))}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Try Again
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Blogs</h2>
        {isAuthenticated && (
          <Link href="/blogs/new">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Blog
            </Button>
          </Link>
        )}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="bg-card overflow-hidden shadow rounded-lg border border-border flex flex-col">
              <Skeleton className="h-40 w-full" />
              <div className="p-4">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/4 mb-4" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-5/6 mb-2" />
                <Skeleton className="h-4 w-4/6 mb-4" />
                <div className="flex gap-2">
                  <Skeleton className="h-4 w-10" />
                  <Skeleton className="h-4 w-10" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : blogs.length === 0 ? (
        <div className="py-12 text-center">
          <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No blogs found</h3>
          <p className="text-muted-foreground mb-6">
            {filters?.search
              ? "Try adjusting your search or filters"
              : "Be the first to publish a blog post"}
          </p>
          {isAuthenticated && (
            <Link href="/blogs/new">
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Blog
              </Button>
            </Link>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {blogs.map((blog) => (
            <BlogCard 
              key={blog.id} 
              blog={blog}
              isOwner={user && blog.authorId === user.id}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default BlogList;
