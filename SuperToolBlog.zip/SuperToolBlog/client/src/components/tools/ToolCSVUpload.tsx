import { FC, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LoadingButton } from "@/components/ui/loading-button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { FileSpreadsheet, Download, UploadCloud, AlertCircle, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";
import { apiRequest } from "@/lib/queryClient";
import { toolsApi } from "@/lib/api";

interface ToolCSVUploadProps {}

const ToolCSVUpload: FC<ToolCSVUploadProps> = () => {
  const { toast } = useToast();
  const [isUploading, setIsUploading] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadResult, setUploadResult] = useState<{
    success: number;
    failed: number;
    errors: string[];
  } | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    
    if (!selectedFile) {
      return;
    }
    
    if (selectedFile.type !== "text/csv" && !selectedFile.name.endsWith('.csv')) {
      toast({
        title: "Invalid file type",
        description: "Please upload a CSV file",
        variant: "destructive",
      });
      return;
    }
    
    setFile(selectedFile);
    setUploadResult(null);
  };

  const handleDownloadTemplate = async () => {
    try {
      const response = await toolsApi.getToolsCSVTemplate();
      
      // Create a URL for the blob
      const url = window.URL.createObjectURL(await response.blob());
      
      // Create a temporary anchor element
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      a.download = "tool-template.csv";
      
      // Append to the document and trigger the download
      document.body.appendChild(a);
      a.click();
      
      // Clean up
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Template downloaded",
        description: "CSV template has been downloaded successfully",
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "Failed to download the CSV template",
        variant: "destructive",
      });
    }
  };

  const handleUpload = async () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please select a CSV file to upload",
        variant: "destructive",
      });
      return;
    }
    
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      // Create form data
      const formData = new FormData();
      formData.append("csv", file);
      
      // Set up progress simulation
      const progressInterval = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev >= 95) {
            clearInterval(progressInterval);
            return 95;
          }
          return prev + 5;
        });
      }, 200);
      
      // Make the request
      const response = await fetch("/api/tools/import-csv", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      setUploadResult(result);
      
      toast({
        title: "Upload complete",
        description: `Successfully imported ${result.success} tools. ${result.failed} failed.`,
        variant: result.failed > 0 ? "default" : "default",
      });
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload CSV file",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileSpreadsheet className="h-5 w-5 mr-2" />
          Bulk Tool Import
        </CardTitle>
        <CardDescription>
          Upload a CSV file to import multiple tools at once
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <Button 
              variant="outline" 
              onClick={handleDownloadTemplate}
              className="w-full md:w-auto"
            >
              <Download className="mr-2 h-4 w-4" />
              Download CSV Template
            </Button>
            <p className="text-sm text-muted-foreground">
              Download the template and fill it with your tool data before uploading
            </p>
          </div>

          <div className="border-2 border-dashed border-muted rounded-lg p-6 text-center">
            <input
              type="file"
              id="csv-upload"
              accept=".csv"
              onChange={handleFileChange}
              className="hidden"
              disabled={isUploading}
            />
            <div className="space-y-4">
              <UploadCloud className="h-10 w-10 text-muted-foreground mx-auto" />
              <div className="space-y-2">
                <p className="text-sm font-medium">
                  {file ? file.name : "Drag and drop your CSV file here or click to browse"}
                </p>
                <p className="text-xs text-muted-foreground">
                  CSV file up to 5MB
                </p>
              </div>
              <Button 
                variant="secondary" 
                onClick={() => document.getElementById("csv-upload")?.click()}
                disabled={isUploading}
              >
                Select CSV File
              </Button>
            </div>
          </div>

          {file && (
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5 text-primary" />
              <span className="font-medium">{file.name}</span>
              <Badge variant="outline">{(file.size / 1024).toFixed(1)} KB</Badge>
              <Button 
                variant="ghost" 
                size="sm"
                className="ml-auto"
                onClick={() => setFile(null)}
                disabled={isUploading}
              >
                Remove
              </Button>
            </div>
          )}

          {isUploading && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Uploading...</span>
                <span>{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} className="h-2" />
            </div>
          )}

          {uploadResult && (
            <Alert variant={uploadResult.failed > 0 ? "destructive" : "default"}>
              <div className="flex items-center gap-2">
                {uploadResult.failed > 0 ? (
                  <AlertCircle className="h-4 w-4" />
                ) : (
                  <CheckCircle2 className="h-4 w-4" />
                )}
                <AlertTitle>Import Results</AlertTitle>
              </div>
              <AlertDescription className="mt-2">
                <p className="mb-2">
                  Successfully imported {uploadResult.success} tools.
                  {uploadResult.failed > 0 && ` Failed to import ${uploadResult.failed} tools.`}
                </p>
                {uploadResult.errors.length > 0 && (
                  <div className="mt-2 text-sm max-h-32 overflow-y-auto">
                    <p className="font-medium mb-1">Errors:</p>
                    <ul className="list-disc list-inside space-y-1">
                      {uploadResult.errors.slice(0, 5).map((error, i) => (
                        <li key={i}>{error}</li>
                      ))}
                      {uploadResult.errors.length > 5 && (
                        <li>And {uploadResult.errors.length - 5} more errors...</li>
                      )}
                    </ul>
                  </div>
                )}
              </AlertDescription>
            </Alert>
          )}

          <div className="flex justify-end">
            <LoadingButton 
              onClick={handleUpload} 
              isLoading={isUploading}
              disabled={!file || isUploading}
              loadingText="Uploading..."
            >
              Upload CSV
            </LoadingButton>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ToolCSVUpload;
