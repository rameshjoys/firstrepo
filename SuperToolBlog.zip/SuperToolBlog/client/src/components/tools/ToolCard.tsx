import { FC } from "react";
import { Link } from "wouter";
import { Tool } from "@shared/schema";
import { ArrowUpRight, Star, StarHalf, Plus, Edit, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToolComparison } from "@/hooks/use-tool-comparison";
import { useAuth } from "@/hooks/use-auth";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/lib/store";
import { deleteTool } from "@/features/tools/toolsSlice";
import { useToast } from "@/hooks/use-toast";

interface ToolCardProps {
  tool: Tool;
}

const ToolCard: FC<ToolCardProps> = ({ tool }) => {
  const { toolIds, addTool, removeTool } = useToolComparison();
  const { hasRole } = useAuth();
  const dispatch = useDispatch<AppDispatch>();
  const { toast } = useToast();
  
  const isInComparison = toolIds.includes(tool.id);
  
  const handleComparisonToggle = async () => {
    if (isInComparison) {
      await removeTool(tool.id);
    } else {
      await addTool(tool.id);
    }
  };
  
  const handleDelete = async () => {
    try {
      await dispatch(deleteTool(tool.id)).unwrap();
      toast({
        title: "Tool Deleted",
        description: `${tool.name} has been deleted successfully.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete the tool.",
        variant: "destructive",
      });
    }
  };
  
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="text-yellow-400 fill-yellow-400 h-4 w-4" />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="text-yellow-400 fill-yellow-400 h-4 w-4" />);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-gray-300 dark:text-gray-600 h-4 w-4" />);
    }
    
    return stars;
  };

  return (
    <Card className="overflow-hidden flex flex-col h-full">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{tool.name}</CardTitle>
            <CardDescription className="mt-1">
              {tool.categoryId && (
                <span>
                  {tool.subcategoryId && `${tool.subcategoryId}, `}
                  {tool.categoryId}
                </span>
              )}
            </CardDescription>
          </div>
          <div>
            {tool.viewCount > 50 && (
              <Badge variant="secondary" className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300">
                <ArrowUpRight className="mr-1 h-3 w-3" />
                Trending
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      
      {tool.imageUrl ? (
        <div className="relative aspect-video overflow-hidden">
          <img
            src={tool.imageUrl}
            alt={tool.name}
            className="object-cover w-full h-48"
          />
        </div>
      ) : (
        <div className="bg-muted flex items-center justify-center h-48 text-muted-foreground">
          No image available
        </div>
      )}
      
      <CardContent className="pt-4 flex-grow">
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center">
            <div className="flex items-center mr-1">
              {renderStars(tool.averageRating || 0)}
            </div>
            <span className="text-sm text-muted-foreground">
              ({tool.averageRating ? tool.averageRating.toFixed(1) : "0.0"})
            </span>
          </div>
          <Badge>{tool.priceModel}</Badge>
        </div>
        
        <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
          {tool.description}
        </p>
        
        <div className="mt-2">
          {tool.features && tool.features.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-3">
              {tool.features.slice(0, 3).map((feature, i) => (
                <Badge key={i} variant="outline" className="text-xs">
                  {feature}
                </Badge>
              ))}
              {tool.features.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{tool.features.length - 3}
                </Badge>
              )}
            </div>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="pt-0 pb-3 gap-2 flex flex-wrap">
        <Link href={`/tools/${tool.id}`}>
          <Button variant="default" size="sm">
            View Details
          </Button>
        </Link>
        
        <Button
          variant="outline"
          size="sm"
          onClick={handleComparisonToggle}
        >
          {isInComparison ? (
            "Remove from Compare"
          ) : (
            <>
              <Plus className="mr-1 h-4 w-4" />
              Compare
            </>
          )}
        </Button>
        
        {hasRole(["admin", "superadmin"]) && (
          <div className="flex ml-auto gap-1">
            <Link href={`/tools/${tool.id}/edit`}>
              <Button variant="outline" size="icon" className="h-8 w-8">
                <Edit className="h-4 w-4" />
                <span className="sr-only">Edit</span>
              </Button>
            </Link>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="icon" className="h-8 w-8 text-destructive">
                  <Trash2 className="h-4 w-4" />
                  <span className="sr-only">Delete</span>
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Tool</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete "{tool.name}"? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        )}
      </CardFooter>
    </Card>
  );
};

export default ToolCard;
