import { FC, useEffect, useMemo } from "react";
import { useToolComparison } from "@/hooks/use-tool-comparison";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Check, X, FileText } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useNavigate } from "wouter";
import { Badge } from "@/components/ui/badge";

interface ToolComparisonProps {
  showTitle?: boolean;
  showExport?: boolean;
  limit?: number;
}

const ToolComparison: FC<ToolComparisonProps> = ({ 
  showTitle = true,
  showExport = true,
  limit
}) => {
  const { tools, isLoading, getComparison, clearComparison, removeTool } = useToolComparison();
  const [, navigate] = useNavigate();

  useEffect(() => {
    getComparison();
  }, [getComparison]);

  // Limit the number of tools if specified
  const displayedTools = useMemo(() => {
    if (limit && tools.length > limit) {
      return tools.slice(0, limit);
    }
    return tools;
  }, [tools, limit]);
  
  // Common features across all tools to compare
  const featuresList = useMemo(() => {
    if (!displayedTools.length) return [];
    
    const features = new Set<string>();
    
    // Collect all features
    displayedTools.forEach(tool => {
      if (tool.features && Array.isArray(tool.features)) {
        tool.features.forEach(feature => features.add(feature));
      }
    });
    
    return Array.from(features);
  }, [displayedTools]);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-60 mb-2" />
          <Skeleton className="h-4 w-full max-w-md" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!displayedTools.length) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Tool Comparison</CardTitle>
          <CardDescription>
            Select tools to compare features and pricing
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center py-10">
          <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground mb-4">No tools selected for comparison</p>
          <Button onClick={() => navigate('/tools')}>
            Browse Tools
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="border-b border-border">
        {showTitle && (
          <>
            <div className="flex justify-between items-center">
              <CardTitle>Tool Comparison</CardTitle>
              {showExport && (
                <Button variant="outline" size="sm">
                  <FileText className="mr-2 h-4 w-4" />
                  Export
                </Button>
              )}
            </div>
            <CardDescription>
              Comparing {displayedTools.length} of {tools.length} selected tools
            </CardDescription>
          </>
        )}
      </CardHeader>
      <CardContent className="p-0 overflow-x-auto">
        <Table>
          {!showTitle && (
            <TableCaption>
              Comparing {displayedTools.length} of {tools.length} selected tools
              {tools.length > displayedTools.length && limit && (
                <Button
                  variant="link"
                  onClick={() => navigate('/comparison')}
                >
                  View all comparisons
                </Button>
              )}
            </TableCaption>
          )}
          <TableHeader>
            <TableRow>
              <TableHead className="w-[200px]">Feature</TableHead>
              {displayedTools.map(tool => (
                <TableHead key={tool.id} className="min-w-[200px]">
                  <div className="flex items-center justify-between">
                    <span>{tool.name}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0 rounded-full"
                      onClick={() => removeTool(tool.id)}
                    >
                      <X className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </div>
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell className="font-medium">Pricing</TableCell>
              {displayedTools.map(tool => (
                <TableCell key={`${tool.id}-pricing`}>
                  <Badge>
                    {tool.priceModel}
                  </Badge>
                  {tool.priceDescription && (
                    <div className="text-sm text-muted-foreground mt-1">
                      {tool.priceDescription}
                    </div>
                  )}
                </TableCell>
              ))}
            </TableRow>
            
            {/* Features comparison */}
            {featuresList.map(feature => (
              <TableRow key={feature}>
                <TableCell className="font-medium">{feature}</TableCell>
                {displayedTools.map(tool => {
                  const hasFeature = tool.features?.includes(feature);
                  return (
                    <TableCell key={`${tool.id}-${feature}`}>
                      {hasFeature ? (
                        <Check className="h-5 w-5 text-green-500" />
                      ) : (
                        <X className="h-5 w-5 text-red-500" />
                      )}
                    </TableCell>
                  );
                })}
              </TableRow>
            ))}
            
            {/* Rating row */}
            <TableRow>
              <TableCell className="font-medium">Rating</TableCell>
              {displayedTools.map(tool => (
                <TableCell key={`${tool.id}-rating`}>
                  <div className="flex items-center">
                    <span className="text-yellow-500 font-medium mr-1">
                      {tool.averageRating?.toFixed(1) || "0.0"}
                    </span>
                    <span className="text-muted-foreground text-sm">/5</span>
                  </div>
                </TableCell>
              ))}
            </TableRow>
            
            {/* Website row */}
            <TableRow>
              <TableCell className="font-medium">Website</TableCell>
              {displayedTools.map(tool => (
                <TableCell key={`${tool.id}-website`}>
                  {tool.website ? (
                    <a 
                      href={tool.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                    >
                      Visit Site
                    </a>
                  ) : (
                    <span className="text-muted-foreground">Not available</span>
                  )}
                </TableCell>
              ))}
            </TableRow>
          </TableBody>
        </Table>
      </CardContent>
      {displayedTools.length > 0 && (
        <div className="px-6 py-4 border-t border-border flex justify-end">
          <Button variant="outline" onClick={clearComparison}>
            Clear Comparison
          </Button>
        </div>
      )}
    </Card>
  );
};

export default ToolComparison;
