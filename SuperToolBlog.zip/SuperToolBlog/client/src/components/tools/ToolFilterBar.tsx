import { FC, useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RootState, AppDispatch } from "@/lib/store";
import { setFilters } from "@/features/tools/toolsSlice";
import { fetchCategories, fetchSubcategories } from "@/features/categories/categoriesSlice";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, X } from "lucide-react";

interface ToolFilterBarProps {}

const ToolFilterBar: FC<ToolFilterBarProps> = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { filters } = useSelector((state: RootState) => state.tools);
  const { categories, subcategories } = useSelector((state: RootState) => state.categories);
  
  const [localFilters, setLocalFilters] = useState({
    search: filters.search || "",
    categoryId: filters.categoryId || undefined,
    subcategoryId: filters.subcategoryId || undefined,
    priceModel: filters.priceModel || "",
    sort: filters.sort || "trending"
  });
  
  const [activeFilters, setActiveFilters] = useState<{
    key: string;
    value: string;
    label: string;
  }[]>([]);
  
  // Fetch categories and subcategories
  useEffect(() => {
    dispatch(fetchCategories());
    if (localFilters.categoryId) {
      dispatch(fetchSubcategories(localFilters.categoryId));
    }
  }, [dispatch, localFilters.categoryId]);
  
  // Apply filters when component mounts
  useEffect(() => {
    if (Object.keys(filters).length > 0) {
      setLocalFilters({
        search: filters.search || "",
        categoryId: filters.categoryId || undefined,
        subcategoryId: filters.subcategoryId || undefined,
        priceModel: filters.priceModel || "",
        sort: filters.sort || "trending"
      });
    }
  }, [filters]);
  
  // Update active filters for display
  useEffect(() => {
    const newActiveFilters = [];
    
    if (localFilters.search) {
      newActiveFilters.push({
        key: "search",
        value: localFilters.search,
        label: `Search: ${localFilters.search}`
      });
    }
    
    if (localFilters.categoryId) {
      const category = categories.find(c => c.id === localFilters.categoryId);
      if (category) {
        newActiveFilters.push({
          key: "categoryId",
          value: String(localFilters.categoryId),
          label: category.name
        });
      }
    }
    
    if (localFilters.subcategoryId) {
      const subcategory = subcategories.find(s => s.id === localFilters.subcategoryId);
      if (subcategory) {
        newActiveFilters.push({
          key: "subcategoryId",
          value: String(localFilters.subcategoryId),
          label: subcategory.name
        });
      }
    }
    
    if (localFilters.priceModel) {
      newActiveFilters.push({
        key: "priceModel",
        value: localFilters.priceModel,
        label: getPriceModelLabel(localFilters.priceModel)
      });
    }
    
    if (localFilters.sort && localFilters.sort !== "trending") {
      newActiveFilters.push({
        key: "sort",
        value: localFilters.sort,
        label: getSortLabel(localFilters.sort)
      });
    }
    
    setActiveFilters(newActiveFilters);
  }, [localFilters, categories, subcategories]);
  
  const getPriceModelLabel = (priceModel: string): string => {
    switch (priceModel) {
      case "free": return "Free";
      case "freemium": return "Freemium";
      case "paid": return "Paid";
      case "enterprise": return "Enterprise";
      default: return priceModel;
    }
  };
  
  const getSortLabel = (sort: string): string => {
    switch (sort) {
      case "trending": return "Trending";
      case "latest": return "Last Updated";
      case "rating": return "Highest Rated";
      case "reviews": return "Most Reviews";
      case "name": return "Name (A-Z)";
      default: return sort;
    }
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocalFilters({ ...localFilters, search: e.target.value });
  };
  
  const handleCategoryChange = (value: string) => {
    const categoryId = value ? parseInt(value) : undefined;
    setLocalFilters({ 
      ...localFilters, 
      categoryId,
      subcategoryId: undefined // Reset subcategory when category changes
    });
  };
  
  const handleSubcategoryChange = (value: string) => {
    const subcategoryId = value ? parseInt(value) : undefined;
    setLocalFilters({ ...localFilters, subcategoryId });
  };
  
  const handlePriceModelChange = (value: string) => {
    setLocalFilters({ ...localFilters, priceModel: value });
  };
  
  const handleSortChange = (value: string) => {
    setLocalFilters({ ...localFilters, sort: value });
  };
  
  const handleApplyFilters = () => {
    dispatch(setFilters(localFilters));
  };
  
  const handleRemoveFilter = (key: string) => {
    const updatedFilters = { ...localFilters };
    
    if (key === "search") {
      updatedFilters.search = "";
    } else if (key === "categoryId") {
      updatedFilters.categoryId = undefined;
      updatedFilters.subcategoryId = undefined; // Also clear subcategory
    } else if (key === "subcategoryId") {
      updatedFilters.subcategoryId = undefined;
    } else if (key === "priceModel") {
      updatedFilters.priceModel = "";
    } else if (key === "sort") {
      updatedFilters.sort = "trending";
    }
    
    setLocalFilters(updatedFilters);
    dispatch(setFilters(updatedFilters));
  };
  
  const handleClearAllFilters = () => {
    const resetFilters = {
      search: "",
      categoryId: undefined,
      subcategoryId: undefined,
      priceModel: "",
      sort: "trending"
    };
    
    setLocalFilters(resetFilters);
    dispatch(setFilters(resetFilters));
  };
  
  return (
    <Card className="mb-6">
      <CardContent className="p-4 sm:p-6">
        <div className="grid grid-cols-1 gap-y-4 sm:grid-cols-2 sm:gap-x-6 sm:gap-y-4 lg:grid-cols-4 xl:gap-x-8">
          <div>
            <Label htmlFor="search" className="block text-sm font-medium mb-1.5">
              Search
            </Label>
            <div className="relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-muted-foreground" />
              </div>
              <Input
                type="text"
                id="search"
                placeholder="Search tools..."
                className="pl-10"
                value={localFilters.search}
                onChange={handleInputChange}
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="category" className="block text-sm font-medium mb-1.5">
              Category
            </Label>
            <Select
              value={localFilters.categoryId?.toString() || ""}
              onValueChange={handleCategoryChange}
            >
              <SelectTrigger id="category">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Categories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="sort" className="block text-sm font-medium mb-1.5">
              Sort By
            </Label>
            <Select
              value={localFilters.sort || "trending"}
              onValueChange={handleSortChange}
            >
              <SelectTrigger id="sort">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="trending">Trending</SelectItem>
                <SelectItem value="latest">Last Updated</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="reviews">Most Reviews</SelectItem>
                <SelectItem value="name">Name (A-Z)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="price-range" className="block text-sm font-medium mb-1.5">
              Price Range
            </Label>
            <Select
              value={localFilters.priceModel || ""}
              onValueChange={handlePriceModelChange}
            >
              <SelectTrigger id="price-range">
                <SelectValue placeholder="All Prices" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Prices</SelectItem>
                <SelectItem value="free">Free</SelectItem>
                <SelectItem value="freemium">Freemium</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="enterprise">Enterprise</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {localFilters.categoryId && (
          <div className="mt-4">
            <Label htmlFor="subcategory" className="block text-sm font-medium mb-1.5">
              Subcategory
            </Label>
            <Select
              value={localFilters.subcategoryId?.toString() || ""}
              onValueChange={handleSubcategoryChange}
            >
              <SelectTrigger id="subcategory">
                <SelectValue placeholder="All Subcategories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Subcategories</SelectItem>
                {subcategories
                  .filter(sub => sub.categoryId === localFilters.categoryId)
                  .map((subcategory) => (
                    <SelectItem key={subcategory.id} value={subcategory.id.toString()}>
                      {subcategory.name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
        )}
        
        <div className="mt-4 flex justify-between">
          <div className="flex flex-wrap gap-2">
            {activeFilters.map((filter) => (
              <Badge
                key={filter.key}
                variant="secondary"
                className="flex items-center gap-1"
              >
                {filter.label}
                <button
                  type="button"
                  className="ml-1 rounded-full hover:bg-muted p-0.5"
                  onClick={() => handleRemoveFilter(filter.key)}
                >
                  <X className="h-3 w-3" />
                  <span className="sr-only">Remove filter</span>
                </button>
              </Badge>
            ))}
            
            {activeFilters.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="h-6 px-2 text-xs"
                onClick={handleClearAllFilters}
              >
                Clear all filters
              </Button>
            )}
          </div>
          
          <Button size="sm" onClick={handleApplyFilters}>
            Apply Filters
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ToolFilterBar;
