import { FC, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useDispatch, useSelector } from "react-redux";
import { RootState, AppDispatch } from "@/lib/store";
import { fetchCategories, fetchSubcategories } from "@/features/categories/categoriesSlice";
import { createTool, updateTool } from "@/features/tools/toolsSlice";
import { useLocation } from "wouter";
import { toolSchema } from "@/lib/validation";
import { Tool } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { LoadingButton } from "@/components/ui/loading-button";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ToolFormProps {
  tool?: Tool;
  isEditMode?: boolean;
}

const ToolForm: FC<ToolFormProps> = ({ tool, isEditMode = false }) => {
  const [location, setLocation] = useLocation();
  const dispatch = useDispatch<AppDispatch>();
  const { toast } = useToast();
  
  const { categories, subcategories, isLoading: isCategoryLoading } = useSelector(
    (state: RootState) => state.categories
  );
  
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(
    tool?.categoryId || null
  );
  
  const form = useForm<z.infer<typeof toolSchema>>({
    resolver: zodResolver(toolSchema),
    defaultValues: {
      name: tool?.name || "",
      description: tool?.description || "",
      website: tool?.website || "",
      categoryId: tool?.categoryId || 0,
      subcategoryId: tool?.subcategoryId || undefined,
      priceModel: tool?.priceModel || "",
      priceDescription: tool?.priceDescription || "",
      features: tool?.features || [],
      imageUrl: tool?.imageUrl || "",
    },
  });
  
  // Fetch categories on component mount
  useEffect(() => {
    dispatch(fetchCategories());
  }, [dispatch]);
  
  // Fetch subcategories when category changes
  useEffect(() => {
    if (selectedCategoryId) {
      dispatch(fetchSubcategories(selectedCategoryId));
    }
  }, [dispatch, selectedCategoryId]);
  
  // Handle category change
  const handleCategoryChange = (categoryId: string) => {
    const id = parseInt(categoryId);
    setSelectedCategoryId(id);
    form.setValue("categoryId", id);
    form.setValue("subcategoryId", undefined);
  };
  
  // Handle feature input
  const handleFeatureInput = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && e.currentTarget.value.trim()) {
      e.preventDefault();
      const feature = e.currentTarget.value.trim();
      const currentFeatures = form.getValues("features");
      
      if (!currentFeatures.includes(feature)) {
        form.setValue("features", [...currentFeatures, feature]);
        e.currentTarget.value = "";
      }
    }
  };
  
  // Handle feature removal
  const handleFeatureRemove = (featureToRemove: string) => {
    const currentFeatures = form.getValues("features");
    form.setValue(
      "features",
      currentFeatures.filter((feature) => feature !== featureToRemove)
    );
  };
  
  const onSubmit = async (values: z.infer<typeof toolSchema>) => {
    try {
      if (isEditMode && tool) {
        await dispatch(updateTool({ id: tool.id, tool: values })).unwrap();
        toast({
          title: "Success",
          description: "Tool updated successfully",
        });
      } else {
        await dispatch(createTool(values)).unwrap();
        toast({
          title: "Success",
          description: "Tool created successfully",
        });
      }
      setLocation("/tools");
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save tool",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{isEditMode ? "Edit Tool" : "Add New Tool"}</CardTitle>
        <CardDescription>
          {isEditMode
            ? "Update the details of this tool"
            : "Fill out the form below to add a new tool to the platform"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tool Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. HubSpot CRM" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="website"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Website URL</FormLabel>
                    <FormControl>
                      <Input placeholder="https://example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="categoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select
                      onValueChange={handleCategoryChange}
                      defaultValue={field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.id} value={category.id.toString()}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="subcategoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subcategory</FormLabel>
                    <Select
                      onValueChange={(value) => form.setValue("subcategoryId", parseInt(value))}
                      defaultValue={field.value?.toString()}
                      disabled={!selectedCategoryId || subcategories.length === 0}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a subcategory" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {subcategories
                          .filter((sub) => sub.categoryId === selectedCategoryId)
                          .map((subcategory) => (
                            <SelectItem
                              key={subcategory.id}
                              value={subcategory.id.toString()}
                            >
                              {subcategory.name}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="priceModel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Pricing Model</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select pricing model" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="free">Free</SelectItem>
                        <SelectItem value="freemium">Freemium</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                        <SelectItem value="enterprise">Enterprise</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="priceDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Price Description</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g. Starting from $10/month"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="A brief description of the tool and its key features..."
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div>
              <FormLabel>Key Features</FormLabel>
              <div className="flex flex-wrap gap-2 mb-2">
                {form.watch("features").map((feature, index) => (
                  <Badge key={index} variant="secondary" className="flex items-center gap-1">
                    {feature}
                    <button
                      type="button"
                      className="ml-1 rounded-full hover:bg-muted p-1"
                      onClick={() => handleFeatureRemove(feature)}
                    >
                      <X className="h-3 w-3" />
                      <span className="sr-only">Remove</span>
                    </button>
                  </Badge>
                ))}
              </div>
              <Input
                placeholder="Type a feature and press Enter (e.g. Email Marketing)"
                onKeyDown={handleFeatureInput}
              />
              <FormDescription className="mt-1.5">
                Press Enter to add each feature
              </FormDescription>
              {form.formState.errors.features && (
                <p className="text-sm font-medium text-destructive mt-1">
                  {form.formState.errors.features.message}
                </p>
              )}
            </div>
            
            <FormField
              control={form.control}
              name="imageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Image URL</FormLabel>
                  <FormControl>
                    <Input placeholder="https://example.com/image.jpg" {...field} />
                  </FormControl>
                  <FormDescription>
                    Enter a URL for the tool's screenshot or logo
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <CardFooter className="px-0 pb-0 pt-6">
              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation("/tools")}
                >
                  Cancel
                </Button>
                <LoadingButton
                  type="submit"
                  isLoading={form.formState.isSubmitting}
                  loadingText="Saving..."
                >
                  {isEditMode ? "Update Tool" : "Save Tool"}
                </LoadingButton>
              </div>
            </CardFooter>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default ToolForm;
