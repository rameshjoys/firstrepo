import { FC, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "wouter";
import { RootState, AppDispatch } from "@/lib/store";
import { fetchTools } from "@/features/tools/toolsSlice";
import ToolCard from "./ToolCard";
import { Button } from "@/components/ui/button";
import { Plus, BarChart3, RefreshCw } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";

interface ToolListProps {
  filters?: {
    search?: string;
    categoryId?: number;
    subcategoryId?: number;
    priceModel?: string;
    sort?: string;
  };
}

const ToolList: FC<ToolListProps> = ({ filters }) => {
  const dispatch = useDispatch<AppDispatch>();
  const { tools, isLoading, error } = useSelector((state: RootState) => state.tools);
  const { hasRole } = useAuth();

  useEffect(() => {
    dispatch(fetchTools(filters));
  }, [dispatch, filters]);

  if (error) {
    return (
      <div className="py-8 text-center">
        <p className="text-destructive mb-4">{error}</p>
        <Button onClick={() => dispatch(fetchTools(filters))}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Try Again
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Available Tools</h2>
        {hasRole(["admin", "superadmin"]) && (
          <Link href="/tools/new">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add New Tool
            </Button>
          </Link>
        )}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="bg-card overflow-hidden shadow rounded-lg border border-border flex flex-col">
              <div className="px-4 py-5 sm:px-6 flex justify-between">
                <Skeleton className="h-7 w-32" />
                <Skeleton className="h-5 w-20" />
              </div>
              <Skeleton className="h-48 w-full" />
              <div className="border-t border-border px-4 py-4 sm:px-6 flex-grow">
                <div className="flex justify-between items-center mb-3">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-5 w-16" />
                </div>
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-5/6 mb-2" />
                <Skeleton className="h-4 w-4/6 mb-4" />
                <div className="flex gap-2">
                  <Skeleton className="h-8 w-24" />
                  <Skeleton className="h-8 w-24" />
                  <Skeleton className="h-8 w-24" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : tools.length === 0 ? (
        <div className="py-12 text-center">
          <BarChart3 className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No tools found</h3>
          <p className="text-muted-foreground mb-6">
            {filters?.search
              ? "Try adjusting your search or filters"
              : "Add your first tool to get started"}
          </p>
          {hasRole(["admin", "superadmin"]) && (
            <Link href="/tools/new">
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add New Tool
              </Button>
            </Link>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {tools.map((tool) => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ToolList;
