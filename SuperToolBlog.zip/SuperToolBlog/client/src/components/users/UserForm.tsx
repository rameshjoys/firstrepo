import { FC, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { usersApi } from "@/lib/api";
import { User } from "@shared/schema";
import { userSchema } from "@/lib/validation";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { LoadingButton } from "@/components/ui/loading-button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

interface UserFormProps {
  user?: User;
  isEditMode?: boolean;
}

const UserForm: FC<UserFormProps> = ({ user, isEditMode = false }) => {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const { hasRole } = useAuth();
  const [error, setError] = useState<string | null>(null);
  
  // Form schema with conditional password validation
  const formSchema = z.object({
    username: z.string().min(3, "Username must be at least 3 characters"),
    email: z.string().email("Invalid email address"),
    firstName: z.string().optional(),
    lastName: z.string().optional(),
    role: z.string(),
    password: isEditMode 
      ? z.string().min(6, "Password must be at least 6 characters").optional().or(z.literal(''))
      : z.string().min(6, "Password must be at least 6 characters"),
    confirmPassword: isEditMode 
      ? z.string().optional().or(z.literal(''))
      : z.string()
  }).refine(data => {
    // If we're editing and no password is provided, we're good
    if (isEditMode && (!data.password || data.password === '')) {
      return true;
    }
    
    // Otherwise, passwords must match
    return data.password === data.confirmPassword;
  }, {
    message: "Passwords don't match",
    path: ["confirmPassword"]
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: user?.username || "",
      email: user?.email || "",
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      role: user?.role || "user",
      password: "",
      confirmPassword: "",
    },
  });
  
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setError(null);
    
    try {
      // Remove confirmPassword and empty optional fields
      const userData = {
        username: values.username,
        email: values.email,
        firstName: values.firstName || undefined,
        lastName: values.lastName || undefined,
        role: values.role,
        password: values.password || undefined,
      };
      
      if (isEditMode && user) {
        await usersApi.updateUser(user.id, userData);
        toast({
          title: "Success",
          description: "User updated successfully",
        });
      } else {
        await usersApi.createUser(userData);
        toast({
          title: "Success",
          description: "User created successfully",
        });
      }
      
      setLocation("/users");
    } catch (err: any) {
      setError(err.message || "An error occurred while saving the user");
      toast({
        title: "Error",
        description: "Failed to save user",
        variant: "destructive",
      });
    }
  };
  
  const isSuperAdmin = hasRole(["superadmin"]);
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>{isEditMode ? "Edit User" : "Create User"}</CardTitle>
        <CardDescription>
          {isEditMode 
            ? "Update user information and permissions" 
            : "Add a new user to the platform"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid gap-6 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormDescription>
                      The user's unique username for login
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="user">User</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                        {isSuperAdmin && (
                          <SelectItem value="superadmin">Super Admin</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Controls what the user can access and modify
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="border-t border-border pt-6">
              <h3 className="text-lg font-medium mb-4">
                {isEditMode ? "Change Password" : "Set Password"}
              </h3>
              
              <div className="grid gap-6 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {isEditMode ? "New Password" : "Password"}
                      </FormLabel>
                      <FormControl>
                        <Input type="password" {...field} />
                      </FormControl>
                      {isEditMode && (
                        <FormDescription>
                          Leave blank to keep current password
                        </FormDescription>
                      )}
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Confirm Password</FormLabel>
                      <FormControl>
                        <Input type="password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            <CardFooter className="px-0 pb-0 pt-6">
              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation("/users")}
                >
                  Cancel
                </Button>
                <LoadingButton
                  type="submit"
                  isLoading={form.formState.isSubmitting}
                >
                  {isEditMode ? "Update User" : "Create User"}
                </LoadingButton>
              </div>
            </CardFooter>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default UserForm;
