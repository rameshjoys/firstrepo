import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { blogsApi } from '@/lib/api';
import { BlogState } from '@/lib/types';
import { Blog, InsertBlog } from '@shared/schema';

// Async thunks
export const fetchBlogs = createAsyncThunk(
  'blogs/fetchBlogs',
  async (filters?: {
    search?: string;
    categoryId?: number;
    authorId?: number;
    status?: string;
    sort?: string;
  }, { rejectWithValue }) => {
    try {
      return await blogsApi.getBlogs(filters);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch blogs');
    }
  }
);

export const fetchBlog = createAsyncThunk(
  'blogs/fetchBlog',
  async (id: number, { rejectWithValue }) => {
    try {
      return await blogsApi.getBlog(id);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch blog');
    }
  }
);

export const createBlog = createAsyncThunk(
  'blogs/createBlog',
  async (blog: InsertBlog, { rejectWithValue }) => {
    try {
      return await blogsApi.createBlog(blog);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to create blog');
    }
  }
);

export const updateBlog = createAsyncThunk(
  'blogs/updateBlog',
  async ({ id, blog }: { id: number; blog: Partial<Blog> }, { rejectWithValue }) => {
    try {
      return await blogsApi.updateBlog(id, blog);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to update blog');
    }
  }
);

export const deleteBlog = createAsyncThunk(
  'blogs/deleteBlog',
  async (id: number, { rejectWithValue }) => {
    try {
      return await blogsApi.deleteBlog(id);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to delete blog');
    }
  }
);

export const fetchTrendingBlogs = createAsyncThunk(
  'blogs/fetchTrendingBlogs',
  async (limit?: number, { rejectWithValue }) => {
    try {
      return await blogsApi.getTrendingBlogs(limit);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch trending blogs');
    }
  }
);

// Initial state
const initialState: BlogState = {
  blogs: [],
  selectedBlog: null,
  isLoading: false,
  error: null,
  filters: {}
};

// Blogs slice
const blogsSlice = createSlice({
  name: 'blogs',
  initialState,
  reducers: {
    clearBlogError: (state) => {
      state.error = null;
    },
    setFilters: (state, action) => {
      state.filters = action.payload;
    },
    clearSelectedBlog: (state) => {
      state.selectedBlog = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Fetch Blogs
      .addCase(fetchBlogs.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchBlogs.fulfilled, (state, action) => {
        state.isLoading = false;
        state.blogs = action.payload;
      })
      .addCase(fetchBlogs.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Fetch Blog
      .addCase(fetchBlog.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchBlog.fulfilled, (state, action) => {
        state.isLoading = false;
        state.selectedBlog = action.payload;
      })
      .addCase(fetchBlog.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Create Blog
      .addCase(createBlog.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(createBlog.fulfilled, (state, action) => {
        state.isLoading = false;
        state.blogs = [...state.blogs, action.payload];
      })
      .addCase(createBlog.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Update Blog
      .addCase(updateBlog.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(updateBlog.fulfilled, (state, action) => {
        state.isLoading = false;
        state.blogs = state.blogs.map(blog => 
          blog.id === action.payload.id ? action.payload : blog
        );
        state.selectedBlog = action.payload;
      })
      .addCase(updateBlog.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Delete Blog
      .addCase(deleteBlog.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(deleteBlog.fulfilled, (state, action) => {
        state.isLoading = false;
        state.blogs = state.blogs.filter(blog => blog.id !== action.meta.arg);
        if (state.selectedBlog && state.selectedBlog.id === action.meta.arg) {
          state.selectedBlog = null;
        }
      })
      .addCase(deleteBlog.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Fetch Trending Blogs
      .addCase(fetchTrendingBlogs.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchTrendingBlogs.fulfilled, (state, action) => {
        state.isLoading = false;
        state.blogs = action.payload;
      })
      .addCase(fetchTrendingBlogs.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });
  }
});

export const { clearBlogError, setFilters, clearSelectedBlog } = blogsSlice.actions;

export default blogsSlice.reducer;
