import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { categoriesApi, subcategoriesApi } from '@/lib/api';
import { CategoryState } from '@/lib/types';
import { Category, Subcategory, InsertCategory, InsertSubcategory } from '@shared/schema';

// Async thunks for categories
export const fetchCategories = createAsyncThunk(
  'categories/fetchCategories',
  async (_, { rejectWithValue }) => {
    try {
      return await categoriesApi.getCategories();
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch categories');
    }
  }
);

export const fetchCategory = createAsyncThunk(
  'categories/fetchCategory',
  async (id: number, { rejectWithValue }) => {
    try {
      return await categoriesApi.getCategory(id);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch category');
    }
  }
);

export const createCategory = createAsyncThunk(
  'categories/createCategory',
  async (category: InsertCategory, { rejectWithValue }) => {
    try {
      return await categoriesApi.createCategory(category);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to create category');
    }
  }
);

export const updateCategory = createAsyncThunk(
  'categories/updateCategory',
  async ({ id, category }: { id: number; category: Partial<Category> }, { rejectWithValue }) => {
    try {
      return await categoriesApi.updateCategory(id, category);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to update category');
    }
  }
);

export const deleteCategory = createAsyncThunk(
  'categories/deleteCategory',
  async (id: number, { rejectWithValue }) => {
    try {
      return await categoriesApi.deleteCategory(id);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to delete category');
    }
  }
);

// Async thunks for subcategories
export const fetchSubcategories = createAsyncThunk(
  'categories/fetchSubcategories',
  async (categoryId?: number, { rejectWithValue }) => {
    try {
      return await subcategoriesApi.getSubcategories(categoryId);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch subcategories');
    }
  }
);

export const createSubcategory = createAsyncThunk(
  'categories/createSubcategory',
  async (subcategory: InsertSubcategory, { rejectWithValue }) => {
    try {
      return await subcategoriesApi.createSubcategory(subcategory);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to create subcategory');
    }
  }
);

export const updateSubcategory = createAsyncThunk(
  'categories/updateSubcategory',
  async ({ id, subcategory }: { id: number; subcategory: Partial<Subcategory> }, { rejectWithValue }) => {
    try {
      return await subcategoriesApi.updateSubcategory(id, subcategory);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to update subcategory');
    }
  }
);

export const deleteSubcategory = createAsyncThunk(
  'categories/deleteSubcategory',
  async (id: number, { rejectWithValue }) => {
    try {
      return await subcategoriesApi.deleteSubcategory(id);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to delete subcategory');
    }
  }
);

// Initial state
const initialState: CategoryState = {
  categories: [],
  subcategories: [],
  isLoading: false,
  error: null
};

// Categories slice
const categoriesSlice = createSlice({
  name: 'categories',
  initialState,
  reducers: {
    clearCategoryError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Fetch Categories
      .addCase(fetchCategories.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchCategories.fulfilled, (state, action) => {
        state.isLoading = false;
        state.categories = action.payload;
      })
      .addCase(fetchCategories.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Create Category
      .addCase(createCategory.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(createCategory.fulfilled, (state, action) => {
        state.isLoading = false;
        state.categories = [...state.categories, action.payload];
      })
      .addCase(createCategory.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Update Category
      .addCase(updateCategory.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(updateCategory.fulfilled, (state, action) => {
        state.isLoading = false;
        state.categories = state.categories.map(category => 
          category.id === action.payload.id ? action.payload : category
        );
      })
      .addCase(updateCategory.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Delete Category
      .addCase(deleteCategory.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(deleteCategory.fulfilled, (state, action) => {
        state.isLoading = false;
        state.categories = state.categories.filter(category => category.id !== action.meta.arg);
      })
      .addCase(deleteCategory.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Fetch Subcategories
      .addCase(fetchSubcategories.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchSubcategories.fulfilled, (state, action) => {
        state.isLoading = false;
        state.subcategories = action.payload;
      })
      .addCase(fetchSubcategories.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Create Subcategory
      .addCase(createSubcategory.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(createSubcategory.fulfilled, (state, action) => {
        state.isLoading = false;
        state.subcategories = [...state.subcategories, action.payload];
      })
      .addCase(createSubcategory.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Update Subcategory
      .addCase(updateSubcategory.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(updateSubcategory.fulfilled, (state, action) => {
        state.isLoading = false;
        state.subcategories = state.subcategories.map(subcategory => 
          subcategory.id === action.payload.id ? action.payload : subcategory
        );
      })
      .addCase(updateSubcategory.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Delete Subcategory
      .addCase(deleteSubcategory.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(deleteSubcategory.fulfilled, (state, action) => {
        state.isLoading = false;
        state.subcategories = state.subcategories.filter(subcategory => subcategory.id !== action.meta.arg);
      })
      .addCase(deleteSubcategory.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });
  }
});

export const { clearCategoryError } = categoriesSlice.actions;

export default categoriesSlice.reducer;
