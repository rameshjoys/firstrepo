import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { comparisonApi, toolsApi } from '@/lib/api';
import { ComparisonState } from '@/lib/types';
import { Tool } from '@shared/schema';

// Async thunks
export const fetchComparison = createAsyncThunk(
  'comparison/fetchComparison',
  async (_, { rejectWithValue }) => {
    try {
      const comparison = await comparisonApi.getComparison();
      if (comparison.toolIds && comparison.toolIds.length > 0) {
        const toolPromises = comparison.toolIds.map((id: number) => toolsApi.getTool(id));
        const tools = await Promise.all(toolPromises);
        return {
          ...comparison,
          tools
        };
      }
      return comparison;
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch comparison');
    }
  }
);

export const createOrUpdateComparison = createAsyncThunk(
  'comparison/createOrUpdateComparison',
  async (toolIds: number[], { rejectWithValue }) => {
    try {
      const comparison = await comparisonApi.createOrUpdateComparison(toolIds);
      const toolPromises = toolIds.map(id => toolsApi.getTool(id));
      const tools = await Promise.all(toolPromises);
      return {
        ...comparison,
        tools
      };
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to create or update comparison');
    }
  }
);

export const updateComparison = createAsyncThunk(
  'comparison/updateComparison',
  async ({ id, toolIds }: { id: number; toolIds: number[] }, { rejectWithValue }) => {
    try {
      const comparison = await comparisonApi.updateComparison(id, toolIds);
      const toolPromises = toolIds.map(id => toolsApi.getTool(id));
      const tools = await Promise.all(toolPromises);
      return {
        ...comparison,
        tools
      };
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to update comparison');
    }
  }
);

export const deleteComparison = createAsyncThunk(
  'comparison/deleteComparison',
  async (id: number, { rejectWithValue }) => {
    try {
      return await comparisonApi.deleteComparison(id);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to delete comparison');
    }
  }
);

export const addToolToComparison = createAsyncThunk(
  'comparison/addToolToComparison',
  async ({ toolId, currentToolIds, comparisonId }: { toolId: number; currentToolIds: number[]; comparisonId?: number }, { rejectWithValue }) => {
    try {
      if (currentToolIds.includes(toolId)) {
        return { toolIds: currentToolIds };
      }
      
      // Check if we've reached the maximum number of tools (5)
      if (currentToolIds.length >= 5) {
        return rejectWithValue('You can compare up to 5 tools at a time');
      }
      
      const newToolIds = [...currentToolIds, toolId];
      
      if (comparisonId) {
        const comparison = await comparisonApi.updateComparison(comparisonId, newToolIds);
        const toolPromises = newToolIds.map(id => toolsApi.getTool(id));
        const tools = await Promise.all(toolPromises);
        return {
          ...comparison,
          tools
        };
      } else {
        const comparison = await comparisonApi.createOrUpdateComparison(newToolIds);
        const toolPromises = newToolIds.map(id => toolsApi.getTool(id));
        const tools = await Promise.all(toolPromises);
        return {
          ...comparison,
          tools
        };
      }
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to add tool to comparison');
    }
  }
);

export const removeToolFromComparison = createAsyncThunk(
  'comparison/removeToolFromComparison',
  async ({ toolId, currentToolIds, comparisonId }: { toolId: number; currentToolIds: number[]; comparisonId?: number }, { rejectWithValue }) => {
    try {
      if (!currentToolIds.includes(toolId)) {
        return { toolIds: currentToolIds };
      }
      
      const newToolIds = currentToolIds.filter(id => id !== toolId);
      
      if (comparisonId) {
        if (newToolIds.length === 0) {
          await comparisonApi.deleteComparison(comparisonId);
          return { toolIds: [], tools: [] };
        } else {
          const comparison = await comparisonApi.updateComparison(comparisonId, newToolIds);
          const toolPromises = newToolIds.map(id => toolsApi.getTool(id));
          const tools = await Promise.all(toolPromises);
          return {
            ...comparison,
            tools
          };
        }
      }
      
      return { toolIds: newToolIds, tools: [] };
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to remove tool from comparison');
    }
  }
);

// Initial state
const initialState: ComparisonState = {
  toolIds: [],
  tools: [],
  isLoading: false,
  error: null
};

// Comparison slice
const comparisonSlice = createSlice({
  name: 'comparison',
  initialState,
  reducers: {
    clearComparisonError: (state) => {
      state.error = null;
    },
    clearComparison: () => initialState
  },
  extraReducers: (builder) => {
    builder
      // Fetch Comparison
      .addCase(fetchComparison.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchComparison.fulfilled, (state, action) => {
        state.isLoading = false;
        state.toolIds = action.payload.toolIds || [];
        state.tools = action.payload.tools || [];
      })
      .addCase(fetchComparison.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Create or Update Comparison
      .addCase(createOrUpdateComparison.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(createOrUpdateComparison.fulfilled, (state, action) => {
        state.isLoading = false;
        state.toolIds = action.payload.toolIds;
        state.tools = action.payload.tools || [];
      })
      .addCase(createOrUpdateComparison.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Update Comparison
      .addCase(updateComparison.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(updateComparison.fulfilled, (state, action) => {
        state.isLoading = false;
        state.toolIds = action.payload.toolIds;
        state.tools = action.payload.tools || [];
      })
      .addCase(updateComparison.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Delete Comparison
      .addCase(deleteComparison.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(deleteComparison.fulfilled, (state) => {
        state.isLoading = false;
        state.toolIds = [];
        state.tools = [];
      })
      .addCase(deleteComparison.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Add Tool to Comparison
      .addCase(addToolToComparison.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(addToolToComparison.fulfilled, (state, action) => {
        state.isLoading = false;
        state.toolIds = action.payload.toolIds;
        if (action.payload.tools) {
          state.tools = action.payload.tools;
        }
      })
      .addCase(addToolToComparison.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Remove Tool from Comparison
      .addCase(removeToolFromComparison.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(removeToolFromComparison.fulfilled, (state, action) => {
        state.isLoading = false;
        state.toolIds = action.payload.toolIds;
        if (action.payload.tools) {
          state.tools = action.payload.tools;
        }
      })
      .addCase(removeToolFromComparison.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });
  }
});

export const { clearComparisonError, clearComparison } = comparisonSlice.actions;

export default comparisonSlice.reducer;
