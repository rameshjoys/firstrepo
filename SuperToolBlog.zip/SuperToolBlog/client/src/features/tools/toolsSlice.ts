import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { toolsApi } from '@/lib/api';
import { ToolState } from '@/lib/types';
import { Tool, InsertTool } from '@shared/schema';

// Async thunks
export const fetchTools = createAsyncThunk(
  'tools/fetchTools',
  async (filters?: {
    search?: string;
    categoryId?: number;
    subcategoryId?: number;
    priceModel?: string;
    sort?: string;
  }, { rejectWithValue }) => {
    try {
      return await toolsApi.getTools(filters);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch tools');
    }
  }
);

export const fetchTool = createAsyncThunk(
  'tools/fetchTool',
  async (id: number, { rejectWithValue }) => {
    try {
      return await toolsApi.getTool(id);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch tool');
    }
  }
);

export const createTool = createAsyncThunk(
  'tools/createTool',
  async (tool: InsertTool, { rejectWithValue }) => {
    try {
      return await toolsApi.createTool(tool);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to create tool');
    }
  }
);

export const updateTool = createAsyncThunk(
  'tools/updateTool',
  async ({ id, tool }: { id: number; tool: Partial<Tool> }, { rejectWithValue }) => {
    try {
      return await toolsApi.updateTool(id, tool);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to update tool');
    }
  }
);

export const deleteTool = createAsyncThunk(
  'tools/deleteTool',
  async (id: number, { rejectWithValue }) => {
    try {
      return await toolsApi.deleteTool(id);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to delete tool');
    }
  }
);

export const fetchTrendingTools = createAsyncThunk(
  'tools/fetchTrendingTools',
  async (limit?: number, { rejectWithValue }) => {
    try {
      return await toolsApi.getTrendingTools(limit);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch trending tools');
    }
  }
);

export const fetchMostRatedTools = createAsyncThunk(
  'tools/fetchMostRatedTools',
  async (limit?: number, { rejectWithValue }) => {
    try {
      return await toolsApi.getMostRatedTools(limit);
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch most rated tools');
    }
  }
);

// Initial state
const initialState: ToolState = {
  tools: [],
  selectedTool: null,
  isLoading: false,
  error: null,
  filters: {}
};

// Tools slice
const toolsSlice = createSlice({
  name: 'tools',
  initialState,
  reducers: {
    clearToolError: (state) => {
      state.error = null;
    },
    setFilters: (state, action) => {
      state.filters = action.payload;
    },
    clearSelectedTool: (state) => {
      state.selectedTool = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Fetch Tools
      .addCase(fetchTools.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchTools.fulfilled, (state, action) => {
        state.isLoading = false;
        state.tools = action.payload;
      })
      .addCase(fetchTools.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Fetch Tool
      .addCase(fetchTool.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchTool.fulfilled, (state, action) => {
        state.isLoading = false;
        state.selectedTool = action.payload;
      })
      .addCase(fetchTool.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Create Tool
      .addCase(createTool.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(createTool.fulfilled, (state, action) => {
        state.isLoading = false;
        state.tools = [...state.tools, action.payload];
      })
      .addCase(createTool.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Update Tool
      .addCase(updateTool.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(updateTool.fulfilled, (state, action) => {
        state.isLoading = false;
        state.tools = state.tools.map(tool => 
          tool.id === action.payload.id ? action.payload : tool
        );
        state.selectedTool = action.payload;
      })
      .addCase(updateTool.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Delete Tool
      .addCase(deleteTool.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(deleteTool.fulfilled, (state, action) => {
        state.isLoading = false;
        state.tools = state.tools.filter(tool => tool.id !== action.meta.arg);
        if (state.selectedTool && state.selectedTool.id === action.meta.arg) {
          state.selectedTool = null;
        }
      })
      .addCase(deleteTool.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Fetch Trending Tools
      .addCase(fetchTrendingTools.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchTrendingTools.fulfilled, (state, action) => {
        state.isLoading = false;
        state.tools = action.payload;
      })
      .addCase(fetchTrendingTools.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      
      // Fetch Most Rated Tools
      .addCase(fetchMostRatedTools.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchMostRatedTools.fulfilled, (state, action) => {
        state.isLoading = false;
        state.tools = action.payload;
      })
      .addCase(fetchMostRatedTools.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });
  }
});

export const { clearToolError, setFilters, clearSelectedTool } = toolsSlice.actions;

export default toolsSlice.reducer;
