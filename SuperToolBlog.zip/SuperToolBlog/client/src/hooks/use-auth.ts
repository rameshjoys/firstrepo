import { useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'wouter';
import { RootState } from '@/lib/store';
import { 
  login as loginAction, 
  signup as signupAction, 
  logout as logoutAction, 
  verifyEmail as verifyEmailAction, 
  getCurrentUser, 
  clearError 
} from '@/features/auth/authSlice';
import { AppDispatch } from '@/lib/store';
import { User, InsertUser } from '@shared/schema';

export function useAuth() {
  const dispatch = useDispatch<AppDispatch>();
  const [, setLocation] = useLocation();
  const { user, isAuthenticated, isLoading, error, isVerifying } = useSelector(
    (state: RootState) => state.auth
  );

  // Check if user is authenticated on initial load
  useEffect(() => {
    dispatch(getCurrentUser());
  }, [dispatch]);

  // Login function
  const login = useCallback(
    async (email: string, password: string) => {
      try {
        await dispatch(loginAction({ email, password })).unwrap();
        setLocation('/dashboard');
        return true;
      } catch (error) {
        return false;
      }
    },
    [dispatch, setLocation]
  );

  // Signup function
  const signup = useCallback(
    async (userData: InsertUser) => {
      try {
        const result = await dispatch(signupAction(userData)).unwrap();
        return result;
      } catch (error) {
        return null;
      }
    },
    [dispatch]
  );

  // Verify email function
  const verifyEmail = useCallback(
    async (userId: number, code: string) => {
      try {
        const result = await dispatch(verifyEmailAction({ userId, code })).unwrap();
        return result;
      } catch (error) {
        return null;
      }
    },
    [dispatch]
  );

  // Logout function
  const logout = useCallback(async () => {
    try {
      await dispatch(logoutAction()).unwrap();
      setLocation('/login');
      return true;
    } catch (error) {
      return false;
    }
  }, [dispatch, setLocation]);

  // Clear error function
  const clearAuthError = useCallback(() => {
    dispatch(clearError());
  }, [dispatch]);

  // Check if user has required role
  const hasRole = useCallback(
    (roles: string[]) => {
      if (!isAuthenticated || !user) return false;
      return roles.includes(user.role);
    },
    [isAuthenticated, user]
  );

  return {
    user,
    isAuthenticated,
    isLoading,
    isVerifying,
    error,
    login,
    signup,
    verifyEmail,
    logout,
    clearAuthError,
    hasRole
  };
}
