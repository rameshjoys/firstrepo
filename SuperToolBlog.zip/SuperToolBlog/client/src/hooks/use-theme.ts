import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '@/lib/store';
import { setTheme } from '@/features/ui/uiSlice';

type Theme = 'light' | 'dark' | 'system';

export function useTheme() {
  const dispatch = useDispatch();
  const theme = useSelector((state: RootState) => state.ui.theme);

  // Set the theme in the local storage and update the DOM
  const updateTheme = (newTheme: Theme) => {
    // Save to local storage
    localStorage.setItem('theme', newTheme);
    
    // Update DOM
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    
    if (newTheme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark'
        : 'light';
      root.classList.add(systemTheme);
    } else {
      root.classList.add(newTheme);
    }
  };

  // Initialize theme from local storage or system preference
  useEffect(() => {
    const storedTheme = localStorage.getItem('theme') as Theme | null;
    
    if (storedTheme) {
      dispatch(setTheme(storedTheme));
      updateTheme(storedTheme);
    } else {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark'
        : 'light';
      dispatch(setTheme(systemTheme));
      updateTheme(systemTheme);
    }
  }, [dispatch]);

  // Update the DOM when theme changes
  useEffect(() => {
    updateTheme(theme);
  }, [theme]);

  // Function to change the theme
  const changeTheme = (newTheme: Theme) => {
    dispatch(setTheme(newTheme));
  };

  // Toggle between light and dark
  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    dispatch(setTheme(newTheme));
  };

  return { theme, setTheme: changeTheme, toggleTheme };
}