import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '@/lib/store';
import { AppDispatch } from '@/lib/store';
import { 
  fetchComparison,
  createOrUpdateComparison,
  updateComparison,
  deleteComparison,
  addToolToComparison,
  removeToolFromComparison,
  clearComparisonError
} from '@/features/comparison/comparisonSlice';
import { useToast } from '@/hooks/use-toast';

export function useToolComparison() {
  const dispatch = useDispatch<AppDispatch>();
  const { toast } = useToast();
  const { toolIds, tools, isLoading, error } = useSelector(
    (state: RootState) => state.comparison
  );

  // Get the comparison
  const getComparison = useCallback(async () => {
    try {
      await dispatch(fetchComparison()).unwrap();
      return true;
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to fetch comparison',
        variant: 'destructive'
      });
      return false;
    }
  }, [dispatch, toast]);

  // Create or update comparison
  const saveComparison = useCallback(
    async (toolIds: number[]) => {
      try {
        if (toolIds.length > 5) {
          toast({
            title: 'Error',
            description: 'You can compare up to 5 tools at a time',
            variant: 'destructive'
          });
          return false;
        }
        
        await dispatch(createOrUpdateComparison(toolIds)).unwrap();
        toast({
          title: 'Success',
          description: 'Tool comparison updated'
        });
        return true;
      } catch (error: any) {
        toast({
          title: 'Error',
          description: error.message || 'Failed to update comparison',
          variant: 'destructive'
        });
        return false;
      }
    },
    [dispatch, toast]
  );

  // Add tool to comparison
  const addTool = useCallback(
    async (toolId: number) => {
      try {
        if (toolIds.includes(toolId)) {
          toast({
            title: 'Info',
            description: 'This tool is already in your comparison'
          });
          return true;
        }
        
        if (toolIds.length >= 5) {
          toast({
            title: 'Error',
            description: 'You can compare up to 5 tools at a time',
            variant: 'destructive'
          });
          return false;
        }
        
        const result = await dispatch(
          addToolToComparison({
            toolId,
            currentToolIds: toolIds,
            comparisonId: tools.length > 0 ? tools[0].id : undefined
          })
        ).unwrap();
        
        toast({
          title: 'Success',
          description: 'Tool added to comparison'
        });
        
        return true;
      } catch (error: any) {
        toast({
          title: 'Error',
          description: error.message || 'Failed to add tool to comparison',
          variant: 'destructive'
        });
        return false;
      }
    },
    [dispatch, toolIds, tools, toast]
  );

  // Remove tool from comparison
  const removeTool = useCallback(
    async (toolId: number) => {
      try {
        if (!toolIds.includes(toolId)) {
          return true;
        }
        
        await dispatch(
          removeToolFromComparison({
            toolId,
            currentToolIds: toolIds,
            comparisonId: tools.length > 0 ? tools[0].id : undefined
          })
        ).unwrap();
        
        toast({
          title: 'Success',
          description: 'Tool removed from comparison'
        });
        
        return true;
      } catch (error: any) {
        toast({
          title: 'Error',
          description: error.message || 'Failed to remove tool from comparison',
          variant: 'destructive'
        });
        return false;
      }
    },
    [dispatch, toolIds, tools, toast]
  );

  // Clear comparison
  const clearComparison = useCallback(
    async () => {
      try {
        if (tools.length > 0) {
          await dispatch(deleteComparison(tools[0].id)).unwrap();
        }
        
        toast({
          title: 'Success',
          description: 'Comparison cleared'
        });
        
        return true;
      } catch (error: any) {
        toast({
          title: 'Error',
          description: error.message || 'Failed to clear comparison',
          variant: 'destructive'
        });
        return false;
      }
    },
    [dispatch, tools, toast]
  );

  return {
    toolIds,
    tools,
    isLoading,
    error,
    getComparison,
    saveComparison,
    addTool,
    removeTool,
    clearComparison,
    clearError: () => dispatch(clearComparisonError())
  };
}
