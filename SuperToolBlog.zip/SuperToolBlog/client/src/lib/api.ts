import { apiRequest } from "./queryClient";
import { 
  User, InsertUser, 
  Tool, InsertTool, 
  Blog, InsertBlog,
  Category, InsertCategory,
  Subcategory, InsertSubcategory,
  Comment, Review
} from "@shared/schema";

// Auth API
export const authApi = {
  login: async (email: string, password: string) => {
    const response = await apiRequest("POST", "/api/auth/login", { email, password });
    return response.json();
  },
  
  signup: async (userData: InsertUser) => {
    const response = await apiRequest("POST", "/api/auth/signup", userData);
    return response.json();
  },
  
  verifyEmail: async (userId: number, code: string) => {
    const response = await apiRequest("POST", "/api/auth/verify-email", { userId, code });
    return response.json();
  },
  
  logout: async () => {
    const response = await apiRequest("POST", "/api/auth/logout");
    return response.json();
  },
  
  getCurrentUser: async () => {
    const response = await apiRequest("GET", "/api/auth/me");
    return response.json();
  }
};

// Tools API
export const toolsApi = {
  getTools: async (filters?: {
    search?: string;
    categoryId?: number;
    subcategoryId?: number;
    priceModel?: string;
    sort?: string;
  }) => {
    let url = "/api/tools";
    if (filters) {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value.toString());
      });
      if (params.toString()) url += `?${params.toString()}`;
    }
    const response = await apiRequest("GET", url);
    return response.json();
  },
  
  getTool: async (id: number) => {
    const response = await apiRequest("GET", `/api/tools/${id}`);
    return response.json();
  },
  
  createTool: async (tool: InsertTool) => {
    const response = await apiRequest("POST", "/api/tools", tool);
    return response.json();
  },
  
  updateTool: async (id: number, tool: Partial<Tool>) => {
    const response = await apiRequest("PUT", `/api/tools/${id}`, tool);
    return response.json();
  },
  
  deleteTool: async (id: number) => {
    const response = await apiRequest("DELETE", `/api/tools/${id}`);
    return response.json();
  },
  
  getTrendingTools: async (limit?: number) => {
    const url = limit ? `/api/tools/trending?limit=${limit}` : "/api/tools/trending";
    const response = await apiRequest("GET", url);
    return response.json();
  },
  
  getMostRatedTools: async (limit?: number) => {
    const url = limit ? `/api/tools/most-rated?limit=${limit}` : "/api/tools/most-rated";
    const response = await apiRequest("GET", url);
    return response.json();
  },
  
  getToolsCSVTemplate: async () => {
    const response = await apiRequest("GET", "/api/tools/csv-template");
    return response;
  }
};

// Blogs API
export const blogsApi = {
  getBlogs: async (filters?: {
    search?: string;
    categoryId?: number;
    authorId?: number;
    status?: string;
    sort?: string;
  }) => {
    let url = "/api/blogs";
    if (filters) {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value.toString());
      });
      if (params.toString()) url += `?${params.toString()}`;
    }
    const response = await apiRequest("GET", url);
    return response.json();
  },
  
  getBlog: async (id: number) => {
    const response = await apiRequest("GET", `/api/blogs/${id}`);
    return response.json();
  },
  
  createBlog: async (blog: InsertBlog) => {
    const response = await apiRequest("POST", "/api/blogs", blog);
    return response.json();
  },
  
  updateBlog: async (id: number, blog: Partial<Blog>) => {
    const response = await apiRequest("PUT", `/api/blogs/${id}`, blog);
    return response.json();
  },
  
  deleteBlog: async (id: number) => {
    const response = await apiRequest("DELETE", `/api/blogs/${id}`);
    return response.json();
  },
  
  getTrendingBlogs: async (limit?: number) => {
    const url = limit ? `/api/blogs/trending?limit=${limit}` : "/api/blogs/trending";
    const response = await apiRequest("GET", url);
    return response.json();
  }
};

// Categories API
export const categoriesApi = {
  getCategories: async () => {
    const response = await apiRequest("GET", "/api/categories");
    return response.json();
  },
  
  getCategory: async (id: number) => {
    const response = await apiRequest("GET", `/api/categories/${id}`);
    return response.json();
  },
  
  createCategory: async (category: InsertCategory) => {
    const response = await apiRequest("POST", "/api/categories", category);
    return response.json();
  },
  
  updateCategory: async (id: number, category: Partial<Category>) => {
    const response = await apiRequest("PUT", `/api/categories/${id}`, category);
    return response.json();
  },
  
  deleteCategory: async (id: number) => {
    const response = await apiRequest("DELETE", `/api/categories/${id}`);
    return response.json();
  }
};

// Subcategories API
export const subcategoriesApi = {
  getSubcategories: async (categoryId?: number) => {
    const url = categoryId ? `/api/subcategories?categoryId=${categoryId}` : "/api/subcategories";
    const response = await apiRequest("GET", url);
    return response.json();
  },
  
  getSubcategory: async (id: number) => {
    const response = await apiRequest("GET", `/api/subcategories/${id}`);
    return response.json();
  },
  
  createSubcategory: async (subcategory: InsertSubcategory) => {
    const response = await apiRequest("POST", "/api/subcategories", subcategory);
    return response.json();
  },
  
  updateSubcategory: async (id: number, subcategory: Partial<Subcategory>) => {
    const response = await apiRequest("PUT", `/api/subcategories/${id}`, subcategory);
    return response.json();
  },
  
  deleteSubcategory: async (id: number) => {
    const response = await apiRequest("DELETE", `/api/subcategories/${id}`);
    return response.json();
  }
};

// Users API
export const usersApi = {
  getUsers: async () => {
    const response = await apiRequest("GET", "/api/users");
    return response.json();
  },
  
  getUser: async (id: number) => {
    const response = await apiRequest("GET", `/api/users/${id}`);
    return response.json();
  },
  
  createUser: async (user: InsertUser) => {
    const response = await apiRequest("POST", "/api/users", user);
    return response.json();
  },
  
  updateUser: async (id: number, user: Partial<User>) => {
    const response = await apiRequest("PUT", `/api/users/${id}`, user);
    return response.json();
  },
  
  deleteUser: async (id: number) => {
    const response = await apiRequest("DELETE", `/api/users/${id}`);
    return response.json();
  }
};

// Comments API
export const commentsApi = {
  getComments: async (entityId: number, entityType: string) => {
    const response = await apiRequest("GET", `/api/comments?entityId=${entityId}&entityType=${entityType}`);
    return response.json();
  },
  
  createComment: async (comment: { content: string; entityId: number; entityType: string }) => {
    const response = await apiRequest("POST", "/api/comments", comment);
    return response.json();
  },
  
  updateComment: async (id: number, content: string) => {
    const response = await apiRequest("PUT", `/api/comments/${id}`, { content });
    return response.json();
  },
  
  deleteComment: async (id: number) => {
    const response = await apiRequest("DELETE", `/api/comments/${id}`);
    return response.json();
  }
};

// Reviews API
export const reviewsApi = {
  getReviews: async (toolId: number) => {
    const response = await apiRequest("GET", `/api/reviews?toolId=${toolId}`);
    return response.json();
  },
  
  createReview: async (review: { content: string; rating: number; toolId: number }) => {
    const response = await apiRequest("POST", "/api/reviews", review);
    return response.json();
  },
  
  updateReview: async (id: number, review: Partial<{ content: string; rating: number }>) => {
    const response = await apiRequest("PUT", `/api/reviews/${id}`, review);
    return response.json();
  },
  
  deleteReview: async (id: number) => {
    const response = await apiRequest("DELETE", `/api/reviews/${id}`);
    return response.json();
  }
};

// Tool comparison API
export const comparisonApi = {
  getComparison: async () => {
    const response = await apiRequest("GET", "/api/comparison");
    return response.json();
  },
  
  createOrUpdateComparison: async (toolIds: number[]) => {
    const response = await apiRequest("POST", "/api/comparison", { toolIds });
    return response.json();
  },
  
  updateComparison: async (id: number, toolIds: number[]) => {
    const response = await apiRequest("PUT", `/api/comparison/${id}`, { toolIds });
    return response.json();
  },
  
  deleteComparison: async (id: number) => {
    const response = await apiRequest("DELETE", `/api/comparison/${id}`);
    return response.json();
  }
};

// SEO API
export const seoApi = {
  optimizeSEO: async (type: 'blog' | 'tool', id: number, content?: string) => {
    const response = await apiRequest("POST", "/api/seo/optimize", { type, id, content });
    return response.json();
  }
};

// Config API
export const configApi = {
  getConfig: async () => {
    const response = await apiRequest("GET", "/api/config");
    return response.json();
  }
};
