import { configureStore } from '@reduxjs/toolkit';
import { setupListeners } from '@reduxjs/toolkit/query';
import { combineReducers } from 'redux';
import authReducer from '../features/auth/authSlice';
import toolsReducer from '../features/tools/toolsSlice';
import blogsReducer from '../features/blogs/blogsSlice';
import categoriesReducer from '../features/categories/categoriesSlice';
import comparisonReducer from '../features/comparison/comparisonSlice';
import uiReducer from '../features/ui/uiSlice';

const rootReducer = combineReducers({
  auth: authReducer,
  tools: toolsReducer,
  blogs: blogsReducer,
  categories: categoriesReducer,
  comparison: comparisonReducer,
  ui: uiReducer
});

export const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
});

setupListeners(store.dispatch);

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
