import { Tool, Blog, Category, Subcategory, User, Comment, Review } from "@shared/schema";

// SEO Types
export interface SEOData {
  title: string;
  description: string;
  keywords: string[];
  openGraph: {
    title: string;
    description: string;
  };
  twitter: {
    title: string;
    description: string;
  };
  suggestions: string[];
}

// Redux Store Types
export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  isVerifying: boolean;
}

export interface ToolState {
  tools: Tool[];
  selectedTool: Tool | null;
  isLoading: boolean;
  error: string | null;
  filters: {
    search?: string;
    categoryId?: number;
    subcategoryId?: number;
    priceModel?: string;
    sort?: string;
  };
}

export interface BlogState {
  blogs: Blog[];
  selectedBlog: Blog | null;
  isLoading: boolean;
  error: string | null;
  filters: {
    search?: string;
    categoryId?: number;
    authorId?: number;
    status?: string;
    sort?: string;
  };
}

export interface CategoryState {
  categories: Category[];
  subcategories: Subcategory[];
  isLoading: boolean;
  error: string | null;
}

export interface ComparisonState {
  toolIds: number[];
  tools: Tool[];
  isLoading: boolean;
  error: string | null;
}

export interface UIState {
  theme: 'light' | 'dark' | 'system';
  isSidebarOpen: boolean;
  notifications: Notification[];
  isLoading: boolean;
}

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
  timeout?: number;
}

export interface RootState {
  auth: AuthState;
  tools: ToolState;
  blogs: BlogState;
  categories: CategoryState;
  comparison: ComparisonState;
  ui: UIState;
}

// Application Configuration
export interface AppConfig {
  appName: string;
  defaultTheme: 'dark' | 'light' | 'system';
  maxToolsComparison: number;
}

// Form Types
export interface LoginFormValues {
  email: string;
  password: string;
}

export interface SignupFormValues {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export interface VerifyEmailFormValues {
  code: string;
}

export interface ToolFormValues {
  name: string;
  description: string;
  website?: string;
  categoryId: number;
  subcategoryId?: number;
  priceModel: string;
  priceDescription?: string;
  features: string[];
  imageUrl?: string;
}

export interface BlogFormValues {
  title: string;
  content: string;
  excerpt?: string;
  status: string;
  categoryId?: number;
  tags?: string[];
  featuredImageUrl?: string;
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string[];
}

export interface CategoryFormValues {
  name: string;
  description?: string;
  imageUrl?: string;
}

export interface SubcategoryFormValues {
  name: string;
  description?: string;
  categoryId: number;
}

export interface UserFormValues {
  username: string;
  email: string;
  firstName?: string;
  lastName?: string;
  role: string;
  password?: string;
  confirmPassword?: string;
}

export interface CommentFormValues {
  content: string;
  entityId: number;
  entityType: string;
}

export interface ReviewFormValues {
  content: string;
  rating: number;
  toolId: number;
}

export interface SEOFormValues {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
}
