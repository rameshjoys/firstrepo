import * as z from "zod";

// Auth validations
export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters")
});

export const signupSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string()
    .min(6, "Password must be at least 6 characters")
    .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, "Password must contain at least one uppercase letter, one lowercase letter, and one number"),
  confirmPassword: z.string()
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"]
});

export const verifyEmailSchema = z.object({
  code: z.string().min(1, "Verification code is required")
});

// Tool validations
export const toolSchema = z.object({
  name: z.string().min(3, "Tool name must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  website: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
  categoryId: z.number({
    required_error: "Category is required",
    invalid_type_error: "Category must be a number"
  }),
  subcategoryId: z.number().optional(),
  priceModel: z.string({
    required_error: "Price model is required"
  }),
  priceDescription: z.string().optional(),
  features: z.array(z.string()).min(1, "At least one feature is required"),
  imageUrl: z.string().url("Please enter a valid URL").optional().or(z.literal(""))
});

// Blog validations
export const blogSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  content: z.string().min(50, "Content must be at least 50 characters"),
  excerpt: z.string().max(160, "Excerpt must be less than 160 characters").optional(),
  status: z.string({
    required_error: "Status is required"
  }),
  categoryId: z.number().optional(),
  tags: z.array(z.string()).optional(),
  featuredImageUrl: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
  seoTitle: z.string().max(60, "SEO title must be less than 60 characters").optional(),
  seoDescription: z.string().max(160, "SEO description must be less than 160 characters").optional(),
  seoKeywords: z.array(z.string()).optional()
});

// Category validations
export const categorySchema = z.object({
  name: z.string().min(3, "Category name must be at least 3 characters"),
  description: z.string().optional(),
  imageUrl: z.string().url("Please enter a valid URL").optional().or(z.literal(""))
});

export const subcategorySchema = z.object({
  name: z.string().min(3, "Subcategory name must be at least 3 characters"),
  description: z.string().optional(),
  categoryId: z.number({
    required_error: "Parent category is required",
    invalid_type_error: "Parent category must be a number"
  })
});

// User validations
export const userSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  role: z.string({
    required_error: "Role is required"
  }),
  password: z.string().min(6, "Password must be at least 6 characters").optional(),
  confirmPassword: z.string().optional()
}).refine(data => {
  if (data.password && !data.confirmPassword) return false;
  if (!data.password && data.confirmPassword) return false;
  if (data.password && data.confirmPassword) return data.password === data.confirmPassword;
  return true;
}, {
  message: "Passwords don't match",
  path: ["confirmPassword"]
});

// Comment validations
export const commentSchema = z.object({
  content: z.string().min(1, "Comment cannot be empty"),
  entityId: z.number({
    required_error: "Entity ID is required",
    invalid_type_error: "Entity ID must be a number"
  }),
  entityType: z.string({
    required_error: "Entity type is required"
  })
});

// Review validations
export const reviewSchema = z.object({
  content: z.string().min(1, "Review cannot be empty"),
  rating: z.number({
    required_error: "Rating is required",
    invalid_type_error: "Rating must be a number"
  }).min(1, "Rating must be at least 1").max(5, "Rating must be at most 5"),
  toolId: z.number({
    required_error: "Tool ID is required",
    invalid_type_error: "Tool ID must be a number"
  })
});

// SEO validations
export const seoSchema = z.object({
  seoTitle: z.string().max(60, "SEO title must be less than 60 characters"),
  seoDescription: z.string().max(160, "SEO description must be less than 160 characters"),
  seoKeywords: z.array(z.string())
});
