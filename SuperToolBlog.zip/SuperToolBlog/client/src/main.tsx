import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import App from "./App";
import "./index.css";
import { ThemeProvider } from "./components/ThemeProvider";
import { store } from "./lib/store";

createRoot(document.getElementById("root")!).render(
  <Provider store={store}>
    <ThemeProvider defaultTheme="system">
      <App />
    </ThemeProvider>
  </Provider>
);
