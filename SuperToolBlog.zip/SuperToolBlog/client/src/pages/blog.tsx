import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useSelector } from "react-redux";
import { RootState } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { CalendarDays, Edit, ArrowLeft, Eye, Share2, MessageSquare, BookOpen } from "lucide-react";

export default function BlogDetail() {
  const [, navigate] = useLocation();
  const [match, params] = useRoute("/blog/:id");
  const { user } = useSelector((state: RootState) => state.auth);
  const [blog, setBlog] = useState<any>(null);
  const [author, setAuthor] = useState<any>(null);
  const [category, setCategory] = useState<any>(null);
  const [comments, setComments] = useState<any[]>([]);
  const [relatedBlogs, setRelatedBlogs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Fetch blog data
  useEffect(() => {
    if (!match || !params?.id) return;

    const fetchBlogData = async () => {
      setIsLoading(true);
      setError(null);
      
      try {
        // Fetch blog
        const blogResponse = await fetch(`/api/blogs/${params.id}`);
        if (!blogResponse.ok) {
          throw new Error("Blog not found");
        }
        
        const blogData = await blogResponse.json();
        setBlog(blogData);
        
        // Fetch author details
        if (blogData.authorId) {
          const authorResponse = await fetch(`/api/users/${blogData.authorId}`);
          if (authorResponse.ok) {
            const authorData = await authorResponse.json();
            setAuthor(authorData);
          }
        }
        
        // Fetch category details
        if (blogData.categoryId) {
          const categoryResponse = await fetch(`/api/categories/${blogData.categoryId}`);
          if (categoryResponse.ok) {
            const categoryData = await categoryResponse.json();
            setCategory(categoryData);
          }
        }
        
        // Fetch comments
        const commentsResponse = await fetch(`/api/comments?entityId=${params.id}&entityType=blog`);
        if (commentsResponse.ok) {
          const commentsData = await commentsResponse.json();
          setComments(commentsData);
        }
        
        // Fetch related blogs in the same category
        if (blogData.categoryId) {
          const relatedResponse = await fetch(`/api/blogs?categoryId=${blogData.categoryId}&limit=3`);
          if (relatedResponse.ok) {
            const relatedData = await relatedResponse.json();
            // Filter out the current blog
            setRelatedBlogs(relatedData.filter((b: any) => b.id !== blogData.id));
          }
        }
        
      } catch (err: any) {
        console.error("Error fetching blog:", err);
        setError(err.message || "Failed to load blog");
      } finally {
        setIsLoading(false);
      }
    };

    fetchBlogData();
  }, [match, params?.id]);

  // Format date for display
  const formatDate = (dateString: string) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Get user initials for avatar
  const getUserInitials = (user: any) => {
    if (!user) return "?";
    
    const firstNameInitial = user.firstName ? user.firstName.charAt(0) : "";
    const lastNameInitial = user.lastName ? user.lastName.charAt(0) : "";
    
    if (firstNameInitial || lastNameInitial) {
      return `${firstNameInitial}${lastNameInitial}`.toUpperCase();
    }
    
    return user.username ? user.username.charAt(0).toUpperCase() : "?";
  };

  // Check if user can edit the blog
  const canEditBlog = user && (
    user.id === blog?.authorId || 
    user.role === 'admin' || 
    user.role === 'superadmin'
  );

  // Handle share button click
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: blog?.title,
        text: blog?.excerpt || 'Check out this blog post',
        url: window.location.href,
      })
      .catch((error) => console.log('Error sharing', error));
    } else {
      // Fallback for browsers that don't support navigator.share
      navigator.clipboard.writeText(window.location.href)
        .then(() => alert('Link copied to clipboard!'))
        .catch((error) => console.log('Error copying to clipboard', error));
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="space-y-4">
          <Skeleton className="h-12 w-3/4" />
          <div className="flex items-center space-x-4">
            <Skeleton className="h-12 w-12 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-40" />
            </div>
          </div>
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-2/3" />
        </div>
        <div className="space-y-4">
          <Skeleton className="h-64 w-full" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !blog) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <BookOpen className="h-16 w-16 text-muted-foreground mb-4" />
        <h2 className="text-2xl font-bold mb-2">Blog Not Found</h2>
        <p className="text-muted-foreground max-w-md mb-6">
          {error || "The blog post you're looking for doesn't exist or may have been removed."}
        </p>
        <Button onClick={() => navigate('/blogs')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Blogs
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate('/blogs')}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Blogs
        </Button>
        
        <div className="flex items-center justify-between">
          <div className="flex gap-2 flex-wrap">
            {category && (
              <Badge variant="outline" className="rounded-full">
                {category.name}
              </Badge>
            )}
            {blog.status === 'published' ? (
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Published</Badge>
            ) : blog.status === 'draft' ? (
              <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">Draft</Badge>
            ) : blog.status === 'scheduled' ? (
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Scheduled</Badge>
            ) : null}
          </div>
          
          {canEditBlog && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate(`/blog/edit/${blog.id}`)}
            >
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </Button>
          )}
        </div>
        
        <h1 className="text-4xl font-bold mt-4 mb-6">{blog.title}</h1>
        
        <div className="flex flex-wrap items-center gap-6 text-sm text-muted-foreground mb-8">
          {author && (
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src={author.avatar} alt={author.username} />
                <AvatarFallback>{getUserInitials(author)}</AvatarFallback>
              </Avatar>
              <div>
                <span className="font-medium text-foreground">{author.username}</span>
                {author.firstName && author.lastName && (
                  <p className="text-xs">{author.firstName} {author.lastName}</p>
                )}
              </div>
            </div>
          )}
          
          <div className="flex items-center gap-1">
            <CalendarDays className="h-4 w-4" />
            {formatDate(blog.publishedAt || blog.createdAt)}
          </div>
          
          <div className="flex items-center gap-1">
            <Eye className="h-4 w-4" />
            {blog.viewCount || 0} views
          </div>
          
          <div className="flex items-center gap-1">
            <MessageSquare className="h-4 w-4" />
            {comments.length} comments
          </div>
        </div>
      </div>
      
      {/* Featured image */}
      {blog.featuredImage && (
        <div className="mb-8 rounded-lg overflow-hidden">
          <img 
            src={blog.featuredImage} 
            alt={blog.title}
            className="w-full h-auto"
          />
        </div>
      )}
      
      {/* Blog content */}
      <div className="prose prose-lg max-w-none dark:prose-invert mb-10">
        <div dangerouslySetInnerHTML={{ __html: blog.content }} />
      </div>
      
      {/* Tags */}
      {blog.tags && blog.tags.length > 0 && (
        <div className="mb-10">
          <h3 className="text-lg font-medium mb-2">Tags</h3>
          <div className="flex flex-wrap gap-2">
            {blog.tags.map((tag: string, index: number) => (
              <Badge key={index} variant="secondary">
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      )}
      
      {/* Share button */}
      <div className="mb-10">
        <Button variant="outline" onClick={handleShare}>
          <Share2 className="h-4 w-4 mr-2" />
          Share this article
        </Button>
      </div>
      
      <Separator className="my-10" />
      
      {/* Author info */}
      {author && (
        <div className="mb-10">
          <h3 className="text-lg font-medium mb-4">About the author</h3>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={author.avatar} alt={author.username} />
                  <AvatarFallback>{getUserInitials(author)}</AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="text-lg font-medium">
                    {author.firstName && author.lastName 
                      ? `${author.firstName} ${author.lastName}` 
                      : author.username}
                  </h4>
                  {author.bio && <p className="text-muted-foreground mt-1">{author.bio}</p>}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      {/* Related blogs */}
      {relatedBlogs.length > 0 && (
        <div className="mb-10">
          <h3 className="text-lg font-medium mb-4">Related articles</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {relatedBlogs.map((relatedBlog) => (
              <Card key={relatedBlog.id} className="overflow-hidden">
                <CardContent className="p-4">
                  <h4 
                    className="font-medium mb-1 line-clamp-2 cursor-pointer hover:text-primary"
                    onClick={() => navigate(`/blog/${relatedBlog.id}`)}
                  >
                    {relatedBlog.title}
                  </h4>
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                    {relatedBlog.excerpt || truncateText(relatedBlog.content)}
                  </p>
                  <div className="text-xs text-muted-foreground">
                    {formatDate(relatedBlog.publishedAt || relatedBlog.createdAt)}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
      
      {/* Comments section */}
      <div className="mb-10">
        <h3 className="text-lg font-medium mb-4">Comments ({comments.length})</h3>
        {comments.length === 0 ? (
          <p className="text-muted-foreground">No comments yet. Be the first to comment!</p>
        ) : (
          <div className="space-y-4">
            {comments.map((comment) => (
              <Card key={comment.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3 mb-2">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>
                        {comment.user ? getUserInitials(comment.user) : "?"}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{comment.user?.username || "Anonymous"}</div>
                      <div className="text-xs text-muted-foreground">
                        {formatDate(comment.createdAt)}
                      </div>
                    </div>
                  </div>
                  <p className="text-sm">{comment.content}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Helper function to truncate text
function truncateText(text: string, maxLength: number = 150) {
  if (!text) return "";
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + "...";
}