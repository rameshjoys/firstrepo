import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useSelector } from "react-redux";
import { RootState } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Search, Plus, Filter, Calendar, Edit, Eye, Bookmark, CalendarDays, BookOpen } from "lucide-react";

export default function Blogs() {
  const [, navigate] = useLocation();
  const { user } = useSelector((state: RootState) => state.auth);
  const [blogs, setBlogs] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedSort, setSelectedSort] = useState<string>("newest");
  
  // Check if user is authenticated and has permission to create blogs
  const isAuthenticated = !!user;
  const canCreateBlog = isAuthenticated;

  // Fetch blogs and categories
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Fetch blogs
        const blogsResponse = await fetch('/api/blogs');
        if (blogsResponse.ok) {
          const blogsData = await blogsResponse.json();
          setBlogs(blogsData);
        }

        // Fetch categories
        const categoriesResponse = await fetch('/api/categories');
        if (categoriesResponse.ok) {
          const categoriesData = await categoriesResponse.json();
          setCategories(categoriesData);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  // Format date for display
  const formatDate = (dateString: string) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Get category name by ID
  const getCategoryName = (categoryId: number) => {
    const category = categories.find(c => c.id === categoryId);
    return category ? category.name : 'Uncategorized';
  };

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // If needed, you can fetch filtered blogs from API
  };

  // Filter blogs based on search, category, and tab
  const filteredBlogs = blogs.filter(blog => {
    // Search filter
    const matchesSearch = searchQuery === "" || 
      blog.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (blog.content && blog.content.toLowerCase().includes(searchQuery.toLowerCase()));
    
    // Category filter
    const matchesCategory = selectedCategory === "" || 
      blog.categoryId === parseInt(selectedCategory);
    
    // Tab filter (published, draft, etc.)
    const matchesTab = activeTab === "all" || 
      (activeTab === "published" && blog.status === "published") ||
      (activeTab === "draft" && blog.status === "draft") ||
      (activeTab === "scheduled" && blog.status === "scheduled") ||
      (activeTab === "my" && blog.authorId === user?.id);
    
    return matchesSearch && matchesCategory && matchesTab;
  }).sort((a, b) => {
    // Sort blogs
    switch (selectedSort) {
      case "newest":
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      case "oldest":
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      case "title_asc":
        return a.title.localeCompare(b.title);
      case "title_desc":
        return b.title.localeCompare(a.title);
      case "popular":
        return b.viewCount - a.viewCount;
      default:
        return 0;
    }
  });

  // Get status badge variant
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "published":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Published</Badge>;
      case "draft":
        return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">Draft</Badge>;
      case "scheduled":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Scheduled</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Truncate text for previews
  const truncateText = (text: string, maxLength: number = 150) => {
    if (!text) return "";
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + "...";
  };

  // Get excerpt from content
  const getExcerpt = (blog: any) => {
    if (blog.excerpt) return blog.excerpt;
    return truncateText(blog.content);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Blog</h1>
          <p className="text-muted-foreground">
            Insights, guides, and news about tools and trends
          </p>
        </div>
        
        {canCreateBlog && (
          <Button onClick={() => navigate('/blog/new')}>
            <Plus className="h-4 w-4 mr-2" />
            Create Blog
          </Button>
        )}
      </div>

      {/* Filters and search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Tabs 
          defaultValue="all" 
          value={activeTab} 
          onValueChange={setActiveTab}
          className="flex-1"
        >
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="published">Published</TabsTrigger>
            <TabsTrigger value="draft">Drafts</TabsTrigger>
            <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
            {isAuthenticated && (
              <TabsTrigger value="my">My Blogs</TabsTrigger>
            )}
          </TabsList>
        </Tabs>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-[1fr_250px] gap-6">
        <div className="space-y-6">
          {/* Search */}
          <form onSubmit={handleSearch} className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search blogs..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </form>

          {/* Blogs list */}
          {isLoading ? (
            <div className="flex justify-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : filteredBlogs.length === 0 ? (
            <Card className="py-12">
              <CardContent className="flex flex-col items-center text-center px-4">
                <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">No blogs found</h3>
                <p className="text-muted-foreground mb-6 max-w-md">
                  {searchQuery || selectedCategory 
                    ? "We couldn't find any blogs matching your criteria. Try adjusting your search filters."
                    : "There are no blogs available yet. Be the first to create content!"}
                </p>
                {canCreateBlog && (
                  <Button onClick={() => navigate('/blog/new')}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Blog
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {filteredBlogs.map((blog) => (
                <Card key={blog.id}>
                  <CardContent className="p-6">
                    <div className="flex flex-wrap gap-3 mb-3">
                      <Badge variant="outline" className="rounded-full">
                        {getCategoryName(blog.categoryId)}
                      </Badge>
                      {getStatusBadge(blog.status)}
                    </div>
                    
                    <h2 
                      className="text-2xl font-bold mb-2 cursor-pointer hover:text-primary transition-colors"
                      onClick={() => navigate(`/blog/${blog.id}`)}
                    >
                      {blog.title}
                    </h2>
                    
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                      <div className="flex items-center gap-1">
                        <CalendarDays className="h-4 w-4" />
                        {formatDate(blog.publishedAt || blog.createdAt)}
                      </div>
                      <div className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        {blog.viewCount || 0} views
                      </div>
                    </div>
                    
                    <p className="mb-4 text-muted-foreground">
                      {getExcerpt(blog)}
                    </p>
                    
                    <div className="flex justify-between items-center">
                      <Button 
                        variant="outline" 
                        onClick={() => navigate(`/blog/${blog.id}`)}
                      >
                        Read More
                      </Button>
                      
                      {(user?.id === blog.authorId || user?.role === 'admin' || user?.role === 'superadmin') && (
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => navigate(`/blog/edit/${blog.id}`)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
        
        {/* Sidebar */}
        <div className="space-y-6">
          {/* Categories */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div 
                  className={`flex justify-between items-center p-2 cursor-pointer rounded-md transition-colors ${selectedCategory === "" ? "bg-secondary" : "hover:bg-secondary/50"}`}
                  onClick={() => setSelectedCategory("")}
                >
                  <span>All Categories</span>
                  <Badge variant="outline">
                    {blogs.length}
                  </Badge>
                </div>
                
                {categories.map((category) => {
                  const count = blogs.filter(blog => blog.categoryId === category.id).length;
                  return count > 0 ? (
                    <div 
                      key={category.id}
                      className={`flex justify-between items-center p-2 cursor-pointer rounded-md transition-colors ${selectedCategory === category.id.toString() ? "bg-secondary" : "hover:bg-secondary/50"}`}
                      onClick={() => setSelectedCategory(category.id.toString())}
                    >
                      <span>{category.name}</span>
                      <Badge variant="outline">
                        {count}
                      </Badge>
                    </div>
                  ) : null;
                })}
              </div>
            </CardContent>
          </Card>
          
          {/* Sort */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Sort By</CardTitle>
            </CardHeader>
            <CardContent>
              <Select 
                value={selectedSort} 
                onValueChange={setSelectedSort}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sort articles by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="title_asc">Title (A-Z)</SelectItem>
                  <SelectItem value="title_desc">Title (Z-A)</SelectItem>
                  <SelectItem value="popular">Most Popular</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}