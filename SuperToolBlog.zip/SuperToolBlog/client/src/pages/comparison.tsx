import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useSelector } from "react-redux";
import { RootState } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, BarChart2, Star, Check, X, ExternalLink, ArrowLeftRight, Info, DollarSign, Plus } from "lucide-react";

export default function Comparison() {
  const [, navigate] = useLocation();
  const { user } = useSelector((state: RootState) => state.auth);
  const [comparisonId, setComparisonId] = useState<number | null>(null);
  const [tools, setTools] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([
    "description",
    "features",
    "pricing",
    "pros",
    "cons",
    "ratings"
  ]);
  
  // Check if user is authenticated
  const isAuthenticated = !!user;
  const maxToolsComparison = 5; // Maximum number of tools that can be compared
  
  // Fetch comparison data
  useEffect(() => {
    const fetchComparisonData = async () => {
      if (!isAuthenticated) {
        setIsLoading(false);
        return;
      }
      
      setIsLoading(true);
      setError(null);
      
      try {
        // Fetch user's comparison
        const comparisonResponse = await fetch('/api/tool-comparisons/current');
        if (!comparisonResponse.ok) {
          throw new Error("Failed to fetch comparison data");
        }
        
        const comparisonData = await comparisonResponse.json();
        if (!comparisonData || !comparisonData.toolIds || comparisonData.toolIds.length === 0) {
          setTools([]);
          setIsLoading(false);
          return;
        }
        
        setComparisonId(comparisonData.id);
        
        // Fetch all tools in the comparison
        const toolsData = [];
        for (const toolId of comparisonData.toolIds) {
          const toolResponse = await fetch(`/api/tools/${toolId}`);
          if (toolResponse.ok) {
            const toolData = await toolResponse.json();
            toolsData.push(toolData);
          }
        }
        
        setTools(toolsData);
      } catch (err: any) {
        console.error("Error fetching comparison data:", err);
        setError(err.message || "Failed to load comparison data");
      } finally {
        setIsLoading(false);
      }
    };

    fetchComparisonData();
  }, [isAuthenticated]);

  // Toggle feature selection
  const toggleFeature = (feature: string) => {
    if (selectedFeatures.includes(feature)) {
      setSelectedFeatures(selectedFeatures.filter(f => f !== feature));
    } else {
      setSelectedFeatures([...selectedFeatures, feature]);
    }
  };
  
  // Remove tool from comparison
  const removeTool = async (toolId: number) => {
    try {
      const response = await fetch('/api/tool-comparisons/remove', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ toolId }),
      });
      
      if (response.ok) {
        setTools(tools.filter(tool => tool.id !== toolId));
      }
    } catch (error) {
      console.error("Error removing tool from comparison:", error);
    }
  };
  
  // Clear all tools from comparison
  const clearComparison = async () => {
    if (!comparisonId) return;
    
    try {
      const response = await fetch(`/api/tool-comparisons/${comparisonId}`, {
        method: 'DELETE',
      });
      
      if (response.ok) {
        setTools([]);
      }
    } catch (error) {
      console.error("Error clearing comparison:", error);
    }
  };
  
  // Format price model
  const formatPriceModel = (priceModel: string) => {
    switch (priceModel) {
      case 'free': return 'Free';
      case 'freemium': return 'Freemium';
      case 'paid': return 'Paid';
      case 'enterprise': return 'Enterprise';
      default: return priceModel;
    }
  };
  
  // Get price model color
  const getPriceModelColor = (priceModel: string) => {
    switch (priceModel) {
      case 'free': return 'bg-green-100 text-green-800 hover:bg-green-100';
      case 'freemium': return 'bg-blue-100 text-blue-800 hover:bg-blue-100';
      case 'paid': return 'bg-amber-100 text-amber-800 hover:bg-amber-100';
      case 'enterprise': return 'bg-purple-100 text-purple-800 hover:bg-purple-100';
      default: return '';
    }
  };
  
  // Render star rating
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    
    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(
          <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
        );
      } else if (i === fullStars + 1 && halfStar) {
        stars.push(
          <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400 fill-[50%]" />
        );
      } else {
        stars.push(
          <Star key={i} className="h-4 w-4 text-muted-foreground" />
        );
      }
    }
    
    return (
      <div className="flex">{stars}</div>
    );
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <Info className="h-16 w-16 text-muted-foreground mb-4" />
        <h2 className="text-2xl font-bold mb-2">Authentication Required</h2>
        <p className="text-muted-foreground max-w-md mb-6">
          You need to be logged in to compare tools.
        </p>
        <Button onClick={() => navigate('/login')}>
          Go to Login
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate('/tools')}
            className="mb-2"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Tools
          </Button>
          
          <h1 className="text-3xl font-bold mb-2">Tool Comparison</h1>
          <p className="text-muted-foreground">
            Compare different tools side by side to find the best option for your needs
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => navigate('/tools')}
            className="gap-2"
          >
            <Plus className="h-4 w-4" />
            Add More Tools
          </Button>
          
          {tools.length > 0 && (
            <Button
              variant="outline"
              onClick={clearComparison}
              className="gap-2"
            >
              <X className="h-4 w-4" />
              Clear All
            </Button>
          )}
        </div>
      </div>
      
      {error && (
        <Card className="mb-6 border-destructive">
          <CardContent className="pt-6">
            <p className="text-destructive">{error}</p>
          </CardContent>
        </Card>
      )}
      
      {tools.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <BarChart2 className="h-16 w-16 text-muted-foreground mb-4 opacity-20" />
            <h2 className="text-2xl font-bold mb-2">No Tools to Compare</h2>
            <p className="text-muted-foreground max-w-md mb-6">
              You haven't added any tools to your comparison yet. Browse tools and add them to your comparison list.
            </p>
            <Button onClick={() => navigate('/tools')}>
              Browse Tools
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Feature selection */}
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-lg font-medium mb-4">Select Features to Compare</h2>
              <div className="flex flex-wrap gap-3">
                <div className="flex items-center space-x-2">
                  <Input
                    type="checkbox"
                    id="feature-description"
                    checked={selectedFeatures.includes('description')}
                    onChange={() => toggleFeature('description')}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="feature-description">Description</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Input
                    type="checkbox"
                    id="feature-features"
                    checked={selectedFeatures.includes('features')}
                    onChange={() => toggleFeature('features')}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="feature-features">Features</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Input
                    type="checkbox"
                    id="feature-pricing"
                    checked={selectedFeatures.includes('pricing')}
                    onChange={() => toggleFeature('pricing')}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="feature-pricing">Pricing</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Input
                    type="checkbox"
                    id="feature-pros"
                    checked={selectedFeatures.includes('pros')}
                    onChange={() => toggleFeature('pros')}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="feature-pros">Pros</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Input
                    type="checkbox"
                    id="feature-cons"
                    checked={selectedFeatures.includes('cons')}
                    onChange={() => toggleFeature('cons')}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="feature-cons">Cons</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Input
                    type="checkbox"
                    id="feature-ratings"
                    checked={selectedFeatures.includes('ratings')}
                    onChange={() => toggleFeature('ratings')}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="feature-ratings">Ratings</Label>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Comparison table */}
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="w-48 sticky left-0 bg-background z-10 p-4 text-left border-b"></th>
                  {tools.map((tool) => (
                    <th key={tool.id} className="p-4 min-w-[250px] border-b">
                      <div className="flex flex-col items-center gap-2">
                        {tool.imageUrl && (
                          <div className="h-28 w-28 relative mb-2 overflow-hidden rounded-lg">
                            <img
                              src={tool.imageUrl}
                              alt={tool.name}
                              className="h-full w-full object-cover"
                            />
                          </div>
                        )}
                        
                        <h3 className="text-lg font-bold text-center">{tool.name}</h3>
                        
                        <div className="flex items-center gap-2">
                          <Badge className={getPriceModelColor(tool.priceModel)}>
                            <DollarSign className="h-3 w-3 mr-1" />
                            {formatPriceModel(tool.priceModel)}
                          </Badge>
                        </div>
                        
                        <div className="flex mt-2 gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => navigate(`/tool/${tool.id}`)}
                          >
                            View
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeTool(tool.id)}
                          >
                            Remove
                          </Button>
                        </div>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* Description row */}
                {selectedFeatures.includes('description') && (
                  <tr>
                    <td className="sticky left-0 bg-background z-10 p-4 font-medium border-b">
                      Description
                    </td>
                    {tools.map((tool) => (
                      <td key={tool.id} className="p-4 border-b">
                        <p className="text-sm">{tool.description}</p>
                      </td>
                    ))}
                  </tr>
                )}
                
                {/* Features row */}
                {selectedFeatures.includes('features') && (
                  <tr>
                    <td className="sticky left-0 bg-background z-10 p-4 font-medium border-b">
                      Features
                    </td>
                    {tools.map((tool) => (
                      <td key={tool.id} className="p-4 border-b">
                        {tool.features && tool.features.length > 0 ? (
                          <ul className="list-disc pl-5 space-y-1 text-sm">
                            {tool.features.map((feature: string, index: number) => (
                              <li key={index}>{feature}</li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-muted-foreground text-sm">No features listed</p>
                        )}
                      </td>
                    ))}
                  </tr>
                )}
                
                {/* Pricing row */}
                {selectedFeatures.includes('pricing') && (
                  <tr>
                    <td className="sticky left-0 bg-background z-10 p-4 font-medium border-b">
                      Pricing
                    </td>
                    {tools.map((tool) => (
                      <td key={tool.id} className="p-4 border-b">
                        {tool.pricing && tool.pricing.length > 0 ? (
                          <ul className="list-disc pl-5 space-y-1 text-sm">
                            {tool.pricing.map((price: string, index: number) => (
                              <li key={index}>{price}</li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-muted-foreground text-sm">No pricing information</p>
                        )}
                      </td>
                    ))}
                  </tr>
                )}
                
                {/* Pros row */}
                {selectedFeatures.includes('pros') && (
                  <tr>
                    <td className="sticky left-0 bg-background z-10 p-4 font-medium border-b">
                      Pros
                    </td>
                    {tools.map((tool) => (
                      <td key={tool.id} className="p-4 border-b">
                        {tool.pros && tool.pros.length > 0 ? (
                          <ul className="space-y-1 text-sm">
                            {tool.pros.map((pro: string, index: number) => (
                              <li key={index} className="flex items-start gap-2">
                                <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                                <span>{pro}</span>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-muted-foreground text-sm">No pros listed</p>
                        )}
                      </td>
                    ))}
                  </tr>
                )}
                
                {/* Cons row */}
                {selectedFeatures.includes('cons') && (
                  <tr>
                    <td className="sticky left-0 bg-background z-10 p-4 font-medium border-b">
                      Cons
                    </td>
                    {tools.map((tool) => (
                      <td key={tool.id} className="p-4 border-b">
                        {tool.cons && tool.cons.length > 0 ? (
                          <ul className="space-y-1 text-sm">
                            {tool.cons.map((con: string, index: number) => (
                              <li key={index} className="flex items-start gap-2">
                                <X className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                                <span>{con}</span>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-muted-foreground text-sm">No cons listed</p>
                        )}
                      </td>
                    ))}
                  </tr>
                )}
                
                {/* Ratings row */}
                {selectedFeatures.includes('ratings') && (
                  <tr>
                    <td className="sticky left-0 bg-background z-10 p-4 font-medium border-b">
                      Ratings
                    </td>
                    {tools.map((tool) => (
                      <td key={tool.id} className="p-4 border-b">
                        <div className="flex items-center gap-2">
                          {renderStars(tool.averageRating || 0)}
                          <span className="text-sm font-medium">
                            {tool.averageRating ? tool.averageRating.toFixed(1) : "0.0"}
                          </span>
                        </div>
                      </td>
                    ))}
                  </tr>
                )}
                
                {/* Website row */}
                <tr>
                  <td className="sticky left-0 bg-background z-10 p-4 font-medium border-b">
                    Website
                  </td>
                  {tools.map((tool) => (
                    <td key={tool.id} className="p-4 border-b">
                      {tool.website ? (
                        <Button
                          variant="link"
                          className="p-0 h-auto"
                          onClick={() => window.open(tool.website, '_blank')}
                        >
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Visit Website
                        </Button>
                      ) : (
                        <p className="text-muted-foreground text-sm">No website available</p>
                      )}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}