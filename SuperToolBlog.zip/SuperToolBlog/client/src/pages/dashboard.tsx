import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useSelector } from "react-redux";
import { RootState } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { CalendarIcon, Package, BookOpen, BarChart3, TrendingUp, Users, Star } from "lucide-react";

export default function Dashboard() {
  const [_, navigate] = useLocation();
  const { user, isAuthenticated } = useSelector((state: RootState) => state.auth);
  const [latestTools, setLatestTools] = useState<any[]>([]);
  const [trendingTools, setTrendingTools] = useState<any[]>([]);
  const [latestBlogs, setLatestBlogs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      setIsLoading(true);
      try {
        // Fetch latest tools
        const latestToolsResponse = await fetch('/api/tools?sort=latest&limit=3');
        if (latestToolsResponse.ok) {
          const latestToolsData = await latestToolsResponse.json();
          setLatestTools(latestToolsData);
        }

        // Fetch trending tools
        const trendingToolsResponse = await fetch('/api/tools?sort=trending&limit=3');
        if (trendingToolsResponse.ok) {
          const trendingToolsData = await trendingToolsResponse.json();
          setTrendingTools(trendingToolsData);
        }

        // Fetch latest blogs
        const latestBlogsResponse = await fetch('/api/blogs?sort=latest&limit=3');
        if (latestBlogsResponse.ok) {
          const latestBlogsData = await latestBlogsResponse.json();
          setLatestBlogs(latestBlogsData);
        }
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  // Format date for display
  const formatDate = (dateString: string) => {
    if (!dateString) return "";
    
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Dashboard greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };

  // User-specific welcome message
  const WelcomeMessage = () => {
    if (!isAuthenticated) {
      return (
        <div className="space-y-4">
          <h2 className="text-3xl font-bold tracking-tight">Welcome to ToolBlogHub!</h2>
          <p className="text-muted-foreground">
            Discover and compare the latest B2B tools, read expert blogs, and find the best solutions for your business.
          </p>
          <div className="flex gap-3">
            <Button onClick={() => navigate("/login")}>Sign In</Button>
            <Button variant="outline" onClick={() => navigate("/signup")}>Create Account</Button>
          </div>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        <h2 className="text-3xl font-bold tracking-tight">
          {getGreeting()}, {user?.username || 'there'}!
        </h2>
        <p className="text-muted-foreground">
          {user?.role === 'admin' || user?.role === 'superadmin' 
            ? "Welcome to your admin dashboard. Manage content, users, and platform settings."
            : "Welcome to your dashboard. Explore tools, read blogs, and manage your account."}
        </p>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <WelcomeMessage />

      {/* Stats Cards (admin only) */}
      {isAuthenticated && (user?.role === 'admin' || user?.role === 'superadmin') && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Tools</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">150+</div>
              <p className="text-xs text-muted-foreground">
                +12 added this month
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Blogs</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">75+</div>
              <p className="text-xs text-muted-foreground">
                +8 published this month
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">420+</div>
              <p className="text-xs text-muted-foreground">
                +32 new this month
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tool Comparisons</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">68</div>
              <p className="text-xs text-muted-foreground">
                +15 this month
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Quick Actions (if logged in) */}
      {isAuthenticated && (
        <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4">
          <Button 
            variant="outline" 
            className="h-auto py-4 flex flex-col items-center justify-center gap-2"
            onClick={() => navigate("/tools")}
          >
            <Package className="h-6 w-6" />
            <span>Explore Tools</span>
          </Button>
          <Button 
            variant="outline" 
            className="h-auto py-4 flex flex-col items-center justify-center gap-2"
            onClick={() => navigate("/blogs")}
          >
            <BookOpen className="h-6 w-6" />
            <span>Read Blogs</span>
          </Button>
          <Button 
            variant="outline" 
            className="h-auto py-4 flex flex-col items-center justify-center gap-2"
            onClick={() => navigate("/comparison")}
          >
            <BarChart3 className="h-6 w-6" />
            <span>Compare Tools</span>
          </Button>
          {(user?.role === 'admin' || user?.role === 'superadmin') && (
            <Button 
              variant="outline" 
              className="h-auto py-4 flex flex-col items-center justify-center gap-2"
              onClick={() => navigate("/users")}
            >
              <Users className="h-6 w-6" />
              <span>Manage Users</span>
            </Button>
          )}
        </div>
      )}

      {/* Content Tabs */}
      <Tabs defaultValue="latest-tools" className="space-y-4">
        <TabsList>
          <TabsTrigger value="latest-tools">Latest Tools</TabsTrigger>
          <TabsTrigger value="trending-tools">Trending Tools</TabsTrigger>
          <TabsTrigger value="latest-blogs">Latest Blogs</TabsTrigger>
        </TabsList>
        
        {/* Latest Tools Tab */}
        <TabsContent value="latest-tools" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            {isLoading ? (
              Array(3).fill(0).map((_, index) => (
                <Card key={index} className="overflow-hidden">
                  <div className="h-48 bg-muted animate-pulse" />
                  <CardContent className="p-4">
                    <div className="h-4 w-3/4 bg-muted animate-pulse rounded mb-2" />
                    <div className="h-4 w-1/2 bg-muted animate-pulse rounded" />
                  </CardContent>
                </Card>
              ))
            ) : latestTools.length === 0 ? (
              <Card className="col-span-3">
                <CardContent className="p-6 text-center">
                  <Package className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                  <h3 className="text-lg font-medium mb-1">No tools found</h3>
                  <p className="text-muted-foreground">The tools list will appear here once available.</p>
                </CardContent>
              </Card>
            ) : (
              latestTools.map((tool) => (
                <Card 
                  key={tool.id} 
                  className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => navigate(`/tools/${tool.id}`)}
                >
                  <div className="h-48 bg-muted flex items-center justify-center">
                    {tool.imageUrl ? (
                      <img 
                        src={tool.imageUrl} 
                        alt={tool.name} 
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <Package className="h-12 w-12 text-muted-foreground" />
                    )}
                  </div>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-bold">{tool.name}</h3>
                      <Badge 
                        className={
                          tool.priceModel === 'free' ? 'bg-green-100 text-green-800 hover:bg-green-100' : 
                          tool.priceModel === 'freemium' ? 'bg-blue-100 text-blue-800 hover:bg-blue-100' : 
                          tool.priceModel === 'paid' ? 'bg-amber-100 text-amber-800 hover:bg-amber-100' : 
                          'bg-purple-100 text-purple-800 hover:bg-purple-100'
                        }
                      >
                        {tool.priceModel.charAt(0).toUpperCase() + tool.priceModel.slice(1)}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{tool.description}</p>
                    <div className="flex items-center text-sm">
                      <Star className="h-4 w-4 text-yellow-500 mr-1" />
                      <span>{tool.averageRating > 0 ? tool.averageRating.toFixed(1) : 'No ratings'}</span>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
          <div className="flex justify-center">
            <Button variant="ghost" onClick={() => navigate("/tools")}>
              View All Tools
            </Button>
          </div>
        </TabsContent>
        
        {/* Trending Tools Tab */}
        <TabsContent value="trending-tools" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            {isLoading ? (
              Array(3).fill(0).map((_, index) => (
                <Card key={index} className="overflow-hidden">
                  <div className="h-48 bg-muted animate-pulse" />
                  <CardContent className="p-4">
                    <div className="h-4 w-3/4 bg-muted animate-pulse rounded mb-2" />
                    <div className="h-4 w-1/2 bg-muted animate-pulse rounded" />
                  </CardContent>
                </Card>
              ))
            ) : trendingTools.length === 0 ? (
              <Card className="col-span-3">
                <CardContent className="p-6 text-center">
                  <TrendingUp className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                  <h3 className="text-lg font-medium mb-1">No trending tools</h3>
                  <p className="text-muted-foreground">Trending tools will appear here once available.</p>
                </CardContent>
              </Card>
            ) : (
              trendingTools.map((tool) => (
                <Card 
                  key={tool.id} 
                  className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => navigate(`/tools/${tool.id}`)}
                >
                  <div className="h-48 bg-muted flex items-center justify-center">
                    {tool.imageUrl ? (
                      <img 
                        src={tool.imageUrl} 
                        alt={tool.name} 
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <Package className="h-12 w-12 text-muted-foreground" />
                    )}
                  </div>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-bold">{tool.name}</h3>
                      <Badge 
                        className={
                          tool.priceModel === 'free' ? 'bg-green-100 text-green-800 hover:bg-green-100' : 
                          tool.priceModel === 'freemium' ? 'bg-blue-100 text-blue-800 hover:bg-blue-100' : 
                          tool.priceModel === 'paid' ? 'bg-amber-100 text-amber-800 hover:bg-amber-100' : 
                          'bg-purple-100 text-purple-800 hover:bg-purple-100'
                        }
                      >
                        {tool.priceModel.charAt(0).toUpperCase() + tool.priceModel.slice(1)}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{tool.description}</p>
                    <div className="flex items-center text-sm">
                      <Star className="h-4 w-4 text-yellow-500 mr-1" />
                      <span>{tool.averageRating > 0 ? tool.averageRating.toFixed(1) : 'No ratings'}</span>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
          <div className="flex justify-center">
            <Button variant="ghost" onClick={() => navigate("/tools")}>
              View All Tools
            </Button>
          </div>
        </TabsContent>
        
        {/* Latest Blogs Tab */}
        <TabsContent value="latest-blogs" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            {isLoading ? (
              Array(3).fill(0).map((_, index) => (
                <Card key={index} className="overflow-hidden">
                  <div className="h-48 bg-muted animate-pulse" />
                  <CardContent className="p-4">
                    <div className="h-4 w-3/4 bg-muted animate-pulse rounded mb-2" />
                    <div className="h-4 w-1/2 bg-muted animate-pulse rounded" />
                  </CardContent>
                </Card>
              ))
            ) : latestBlogs.length === 0 ? (
              <Card className="col-span-3">
                <CardContent className="p-6 text-center">
                  <BookOpen className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                  <h3 className="text-lg font-medium mb-1">No blogs found</h3>
                  <p className="text-muted-foreground">The blogs list will appear here once available.</p>
                </CardContent>
              </Card>
            ) : (
              latestBlogs.map((blog) => (
                <Card 
                  key={blog.id} 
                  className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => navigate(`/blogs/${blog.id}`)}
                >
                  <div className="h-48 bg-muted flex items-center justify-center">
                    {blog.coverImageUrl ? (
                      <img 
                        src={blog.coverImageUrl} 
                        alt={blog.title} 
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <BookOpen className="h-12 w-12 text-muted-foreground" />
                    )}
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-bold line-clamp-2 mb-2">{blog.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-3 mb-2">
                      {blog.excerpt || blog.content.substring(0, 150) + '...'}
                    </p>
                    <div className="flex items-center text-sm">
                      <CalendarIcon className="h-4 w-4 text-muted-foreground mr-1" />
                      <span className="text-muted-foreground">{formatDate(blog.createdAt)}</span>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
          <div className="flex justify-center">
            <Button variant="ghost" onClick={() => navigate("/blogs")}>
              View All Blogs
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}