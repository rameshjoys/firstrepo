import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useSelector } from "react-redux";
import { RootState } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, Mail, Link as LinkIcon, MapPin, UserCheck, Info, Edit, PenSquare, CircleDot } from "lucide-react";

export default function Profile() {
  const [, navigate] = useLocation();
  const [match, params] = useRoute("/profile/:username");
  const { user: currentUser } = useSelector((state: RootState) => state.auth);
  const [user, setUser] = useState<any>(null);
  const [blogs, setBlogs] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState("blogs");
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Fetch user data - either current user or specified user
  useEffect(() => {
    const fetchUserData = async () => {
      setIsLoading(true);
      setError(null);
      
      try {
        let userData;
        
        if (match && params?.username) {
          // Fetch specified user by username
          const response = await fetch(`/api/users/by-username/${params.username}`);
          if (!response.ok) {
            throw new Error("User not found");
          }
          userData = await response.json();
        } else if (currentUser) {
          // Use current logged-in user
          userData = currentUser;
        } else {
          throw new Error("You need to be logged in to view your profile");
        }
        
        setUser(userData);
        
        // Fetch user's blogs
        if (userData.id) {
          const blogsResponse = await fetch(`/api/blogs?authorId=${userData.id}`);
          if (blogsResponse.ok) {
            const blogsData = await blogsResponse.json();
            setBlogs(blogsData);
          }
          
          // Fetch user's reviews
          const reviewsResponse = await fetch(`/api/reviews?userId=${userData.id}`);
          if (reviewsResponse.ok) {
            const reviewsData = await reviewsResponse.json();
            setReviews(reviewsData);
          }
        }
        
      } catch (err: any) {
        console.error("Error fetching user data:", err);
        setError(err.message || "An error occurred while loading the profile");
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserData();
  }, [match, params?.username, currentUser]);

  // Format date for display
  const formatDate = (dateString: string) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Check if profile belongs to current user
  const isOwnProfile = currentUser && user && currentUser.id === user.id;
  
  // Get user's role badge
  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'superadmin':
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">Super Admin</Badge>;
      case 'admin':
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Admin</Badge>;
      default:
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">User</Badge>;
    }
  };
  
  // Get user initials for avatar
  const getUserInitials = (user: any) => {
    if (!user) return "?";
    
    const firstNameInitial = user.firstName ? user.firstName.charAt(0) : "";
    const lastNameInitial = user.lastName ? user.lastName.charAt(0) : "";
    
    if (firstNameInitial || lastNameInitial) {
      return `${firstNameInitial}${lastNameInitial}`.toUpperCase();
    }
    
    return user.username ? user.username.charAt(0).toUpperCase() : "?";
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error || !user) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <Info className="h-16 w-16 text-muted-foreground mb-4" />
        <h2 className="text-2xl font-bold mb-2">Profile Not Found</h2>
        <p className="text-muted-foreground max-w-md mb-6">
          {error || "The user profile you're looking for doesn't exist or you need to be logged in."}
        </p>
        <Button onClick={() => navigate('/')}>
          Go to Homepage
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
            <Avatar className="h-24 w-24">
              <AvatarImage src={user.avatar} alt={user.username} />
              <AvatarFallback className="text-2xl">{getUserInitials(user)}</AvatarFallback>
            </Avatar>
            
            <div className="flex-1 text-center md:text-left">
              <div className="flex flex-col md:flex-row md:items-center gap-2 mb-2">
                <h1 className="text-2xl font-bold">
                  {user.firstName && user.lastName 
                    ? `${user.firstName} ${user.lastName}` 
                    : user.username}
                </h1>
                <div>{getRoleBadge(user.role)}</div>
              </div>
              
              <div className="text-muted-foreground mb-4">@{user.username}</div>
              
              {user.bio && (
                <p className="mb-4">{user.bio}</p>
              )}
              
              <div className="flex flex-wrap gap-4 justify-center md:justify-start text-sm text-muted-foreground">
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-1" />
                  {user.email}
                </div>
                
                <div className="flex items-center">
                  <UserCheck className="h-4 w-4 mr-1" />
                  {user.isVerified ? 'Verified account' : 'Unverified account'}
                </div>
                
                <div className="flex items-center">
                  <CalendarDays className="h-4 w-4 mr-1" />
                  Joined {formatDate(user.createdAt)}
                </div>
              </div>
            </div>
            
            {isOwnProfile && (
              <div>
                <Button variant="outline" onClick={() => navigate('/settings')}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="blogs" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="blogs">
            <PenSquare className="h-4 w-4 mr-2" />
            Blogs ({blogs.length})
          </TabsTrigger>
          <TabsTrigger value="reviews">
            <CircleDot className="h-4 w-4 mr-2" />
            Reviews ({reviews.length})
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="blogs">
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Published Blogs</h2>
            
            {blogs.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <PenSquare className="h-12 w-12 text-muted-foreground mb-4 opacity-20" />
                  <h3 className="text-lg font-medium mb-1">No blogs yet</h3>
                  <p className="text-muted-foreground max-w-md mb-4">
                    {isOwnProfile 
                      ? "You haven't published any blogs yet. Start creating content to share with the community."
                      : `${user.username} hasn't published any blogs yet.`}
                  </p>
                  
                  {isOwnProfile && (
                    <Button onClick={() => navigate('/blog/new')}>
                      Create Blog
                    </Button>
                  )}
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6">
                {blogs.map((blog) => (
                  <Card key={blog.id} className="overflow-hidden">
                    <CardContent className="p-6">
                      <div className="flex flex-wrap gap-2 mb-2">
                        {blog.status === 'published' ? (
                          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Published</Badge>
                        ) : blog.status === 'draft' ? (
                          <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">Draft</Badge>
                        ) : blog.status === 'scheduled' ? (
                          <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Scheduled</Badge>
                        ) : null}
                      </div>
                      
                      <h3 
                        className="text-xl font-bold mb-2 cursor-pointer hover:text-primary"
                        onClick={() => navigate(`/blog/${blog.id}`)}
                      >
                        {blog.title}
                      </h3>
                      
                      <div className="text-sm text-muted-foreground mb-3">
                        {formatDate(blog.publishedAt || blog.createdAt)}
                      </div>
                      
                      <p className="text-muted-foreground mb-4 line-clamp-2">
                        {blog.excerpt || blog.content}
                      </p>
                      
                      <Button 
                        variant="outline" 
                        onClick={() => navigate(`/blog/${blog.id}`)}
                      >
                        Read More
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="reviews">
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Tool Reviews</h2>
            
            {reviews.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <CircleDot className="h-12 w-12 text-muted-foreground mb-4 opacity-20" />
                  <h3 className="text-lg font-medium mb-1">No reviews yet</h3>
                  <p className="text-muted-foreground max-w-md">
                    {isOwnProfile 
                      ? "You haven't written any tool reviews yet."
                      : `${user.username} hasn't written any tool reviews yet.`}
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {reviews.map((review) => (
                  <Card key={review.id}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 
                            className="text-lg font-medium mb-1 cursor-pointer hover:text-primary"
                            onClick={() => navigate(`/tool/${review.toolId}`)}
                          >
                            {review.tool?.name || `Tool #${review.toolId}`}
                          </h3>
                          <div className="text-sm text-muted-foreground">
                            {formatDate(review.createdAt)}
                          </div>
                        </div>
                        <div className="flex items-center">
                          {Array(5).fill(0).map((_, index) => (
                            <svg 
                              key={index} 
                              className={`h-5 w-5 ${index < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-muted-foreground'}`}
                              xmlns="http://www.w3.org/2000/svg" 
                              viewBox="0 0 24 24"
                            >
                              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                            </svg>
                          ))}
                        </div>
                      </div>
                      <p>{review.content}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}