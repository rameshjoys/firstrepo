import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useSelector } from "react-redux";
import { RootState } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  ArrowLeft, 
  Edit, 
  ExternalLink, 
  Star, 
  Bookmark, 
  Share2, 
  Heart, 
  Laptop, 
  BarChart3, 
  Check,
  DollarSign,
  CalendarDays,
  MessageSquare,
  Eye,
  X
} from "lucide-react";

export default function ToolDetail() {
  const [, navigate] = useLocation();
  const [match, params] = useRoute("/tool/:id");
  const { user } = useSelector((state: RootState) => state.auth);
  const [tool, setTool] = useState<any>(null);
  const [category, setCategory] = useState<any>(null);
  const [subcategories, setSubcategories] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [relatedTools, setRelatedTools] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState("overview");
  const [reviewContent, setReviewContent] = useState("");
  const [selectedRating, setSelectedRating] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isInCompareList, setIsInCompareList] = useState(false);
  
  // Check if user is authenticated and admin
  const isAuthenticated = !!user;
  const isAdmin = user?.role === 'admin' || user?.role === 'superadmin';

  // Fetch tool data
  useEffect(() => {
    if (!match || !params?.id) return;

    const fetchToolData = async () => {
      setIsLoading(true);
      setError(null);
      
      try {
        // Fetch tool
        const toolResponse = await fetch(`/api/tools/${params.id}`);
        if (!toolResponse.ok) {
          throw new Error("Tool not found");
        }
        
        const toolData = await toolResponse.json();
        setTool(toolData);
        
        // Fetch category
        if (toolData.categoryId) {
          const categoryResponse = await fetch(`/api/categories/${toolData.categoryId}`);
          if (categoryResponse.ok) {
            const categoryData = await categoryResponse.json();
            setCategory(categoryData);
          }
        }
        
        // Fetch subcategories
        if (toolData.subcategoryIds && toolData.subcategoryIds.length > 0) {
          const subcategoriesData = [];
          for (const subcatId of toolData.subcategoryIds) {
            const subcatResponse = await fetch(`/api/subcategories/${subcatId}`);
            if (subcatResponse.ok) {
              const subcatData = await subcatResponse.json();
              subcategoriesData.push(subcatData);
            }
          }
          setSubcategories(subcategoriesData);
        }
        
        // Fetch reviews
        const reviewsResponse = await fetch(`/api/reviews?toolId=${params.id}`);
        if (reviewsResponse.ok) {
          const reviewsData = await reviewsResponse.json();
          setReviews(reviewsData);
        }
        
        // Fetch related tools in the same category
        if (toolData.categoryId) {
          const relatedResponse = await fetch(`/api/tools?categoryId=${toolData.categoryId}&limit=3`);
          if (relatedResponse.ok) {
            const relatedData = await relatedResponse.json();
            // Filter out the current tool
            setRelatedTools(relatedData.filter((t: any) => t.id !== toolData.id));
          }
        }
        
        // Check if tool is in comparison list
        try {
          if (isAuthenticated) {
            const compareResponse = await fetch('/api/tool-comparisons/current');
            if (compareResponse.ok) {
              const compareData = await compareResponse.json();
              if (compareData && compareData.toolIds) {
                setIsInCompareList(compareData.toolIds.includes(parseInt(params.id)));
              }
            }
          }
        } catch (error) {
          console.error("Error checking comparison list:", error);
        }
        
      } catch (err: any) {
        console.error("Error fetching tool:", err);
        setError(err.message || "Failed to load tool");
      } finally {
        setIsLoading(false);
      }
    };

    fetchToolData();
  }, [match, params?.id, isAuthenticated]);

  // Format date for display
  const formatDate = (dateString: string) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Format price model
  const formatPriceModel = (priceModel: string) => {
    switch (priceModel) {
      case 'free': return 'Free';
      case 'freemium': return 'Freemium';
      case 'paid': return 'Paid';
      case 'enterprise': return 'Enterprise';
      default: return priceModel;
    }
  };

  // Get price model color
  const getPriceModelColor = (priceModel: string) => {
    switch (priceModel) {
      case 'free': return 'bg-green-100 text-green-800 hover:bg-green-100';
      case 'freemium': return 'bg-blue-100 text-blue-800 hover:bg-blue-100';
      case 'paid': return 'bg-amber-100 text-amber-800 hover:bg-amber-100';
      case 'enterprise': return 'bg-purple-100 text-purple-800 hover:bg-purple-100';
      default: return '';
    }
  };

  // Get user initials for avatar
  const getUserInitials = (user: any) => {
    if (!user) return "?";
    
    const firstNameInitial = user.firstName ? user.firstName.charAt(0) : "";
    const lastNameInitial = user.lastName ? user.lastName.charAt(0) : "";
    
    if (firstNameInitial || lastNameInitial) {
      return `${firstNameInitial}${lastNameInitial}`.toUpperCase();
    }
    
    return user.username ? user.username.charAt(0).toUpperCase() : "?";
  };

  // Handle toggle comparison list
  const handleToggleCompare = async () => {
    if (!isAuthenticated) {
      // Redirect to login if not authenticated
      navigate('/login');
      return;
    }
    
    try {
      if (isInCompareList) {
        // Remove from comparison
        const response = await fetch(`/api/tool-comparisons/remove`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ toolId: parseInt(params?.id || '0') }),
        });
        
        if (response.ok) {
          setIsInCompareList(false);
        }
      } else {
        // Add to comparison
        const response = await fetch(`/api/tool-comparisons/add`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ toolId: parseInt(params?.id || '0') }),
        });
        
        if (response.ok) {
          setIsInCompareList(true);
        }
      }
    } catch (error) {
      console.error("Error updating comparison list:", error);
    }
  };

  // Handle share button click
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: tool?.name,
        text: tool?.description || 'Check out this tool',
        url: window.location.href,
      })
      .catch((error) => console.log('Error sharing', error));
    } else {
      // Fallback for browsers that don't support navigator.share
      navigator.clipboard.writeText(window.location.href)
        .then(() => alert('Link copied to clipboard!'))
        .catch((error) => console.log('Error copying to clipboard', error));
    }
  };

  // Handle review submission
  const handleSubmitReview = async () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    if (selectedRating === 0) {
      alert("Please select a rating");
      return;
    }
    
    try {
      const response = await fetch('/api/reviews', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          toolId: parseInt(params?.id || '0'),
          content: reviewContent,
          rating: selectedRating,
        }),
      });
      
      if (response.ok) {
        const newReview = await response.json();
        setReviews([newReview, ...reviews]);
        setReviewContent("");
        setSelectedRating(0);
        
        // Update tool rating in our state
        if (tool) {
          // Recalculate average
          const totalRating = reviews.reduce((sum, r) => sum + r.rating, 0) + selectedRating;
          const newAverage = totalRating / (reviews.length + 1);
          setTool({
            ...tool,
            averageRating: newAverage
          });
        }
      }
    } catch (error) {
      console.error("Error submitting review:", error);
    }
  };

  // Calculate rating distribution
  const getRatingDistribution = () => {
    const distribution = [0, 0, 0, 0, 0]; // 5 stars to 1 star
    
    if (reviews.length === 0) return distribution;
    
    reviews.forEach(review => {
      const ratingIndex = Math.floor(review.rating) - 1;
      if (ratingIndex >= 0 && ratingIndex < 5) {
        distribution[ratingIndex]++;
      }
    });
    
    return distribution.reverse(); // Return as 1 star to 5 stars
  };

  // Calculate rating percentage
  const getRatingPercentage = (count: number) => {
    if (reviews.length === 0) return 0;
    return (count / reviews.length) * 100;
  };

  // Render star rating
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    
    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(
          <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
        );
      } else if (i === fullStars + 1 && halfStar) {
        stars.push(
          <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400 fill-[50%]" />
        );
      } else {
        stars.push(
          <Star key={i} className="h-5 w-5 text-muted-foreground" />
        );
      }
    }
    
    return (
      <div className="flex">{stars}</div>
    );
  };

  // Render selectable stars for review
  const renderSelectableStars = () => {
    const stars = [];
    
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <button
          key={i}
          type="button"
          onClick={() => setSelectedRating(i)}
          className="group"
        >
          <Star 
            className={`h-8 w-8 ${i <= selectedRating ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground group-hover:text-yellow-400'}`}
          />
          <span className="sr-only">Rate {i} stars</span>
        </button>
      );
    }
    
    return (
      <div className="flex gap-1">{stars}</div>
    );
  };

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="space-y-4">
          <Skeleton className="h-12 w-3/4" />
          <div className="flex items-center space-x-4">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-4 w-24" />
          </div>
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-2/3" />
        </div>
        <div className="space-y-4">
          <Skeleton className="h-64 w-full" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !tool) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <Laptop className="h-16 w-16 text-muted-foreground mb-4" />
        <h2 className="text-2xl font-bold mb-2">Tool Not Found</h2>
        <p className="text-muted-foreground max-w-md mb-6">
          {error || "The tool you're looking for doesn't exist or may have been removed."}
        </p>
        <Button onClick={() => navigate('/tools')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Tools
        </Button>
      </div>
    );
  }

  const ratingDistribution = getRatingDistribution();

  return (
    <div>
      <div className="mb-8">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate('/tools')}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Tools
        </Button>
        
        <div className="flex flex-col md:flex-row justify-between gap-4 mb-6">
          <div>
            {/* Categories and pricing */}
            <div className="flex flex-wrap gap-2 mb-3">
              {category && (
                <Badge variant="outline" className="rounded-full">
                  {category.name}
                </Badge>
              )}
              {subcategories.map((subcat) => (
                <Badge key={subcat.id} variant="outline" className="rounded-full">
                  {subcat.name}
                </Badge>
              ))}
              <Badge className={getPriceModelColor(tool.priceModel)}>
                <DollarSign className="h-3 w-3 mr-1" />
                {formatPriceModel(tool.priceModel)}
              </Badge>
            </div>
            
            <h1 className="text-3xl font-bold mb-2">{tool.name}</h1>
            
            <div className="flex flex-wrap items-center gap-4 mt-3">
              <div className="flex items-center gap-1">
                {renderStars(tool.averageRating || 0)}
                <span className="text-lg ml-2 font-medium">
                  {tool.averageRating ? tool.averageRating.toFixed(1) : "0.0"}
                </span>
                <span className="text-sm text-muted-foreground ml-1">
                  ({reviews.length} reviews)
                </span>
              </div>
              
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <CalendarDays className="h-4 w-4" />
                Added on {formatDate(tool.createdAt)}
              </div>
              
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <Eye className="h-4 w-4" />
                {tool.viewCount || 0} views
              </div>
            </div>
          </div>
          
          {/* Action buttons */}
          <div className="flex flex-wrap gap-2">
            {tool.website && (
              <Button 
                onClick={() => window.open(tool.website, '_blank')}
                className="gap-2"
              >
                <ExternalLink className="h-4 w-4" />
                Visit Website
              </Button>
            )}
            
            <Button 
              variant="outline" 
              onClick={handleToggleCompare}
              className="gap-2"
            >
              <BarChart3 className="h-4 w-4" />
              {isInCompareList ? "Remove from Compare" : "Add to Compare"}
            </Button>
            
            <Button 
              variant="outline" 
              onClick={handleShare}
              className="gap-2"
            >
              <Share2 className="h-4 w-4" />
              Share
            </Button>
            
            {isAdmin && (
              <Button 
                variant="outline" 
                onClick={() => navigate(`/tool/edit/${tool.id}`)}
                className="gap-2"
              >
                <Edit className="h-4 w-4" />
                Edit
              </Button>
            )}
          </div>
        </div>
        
        {/* Tool image */}
        {tool.imageUrl && (
          <div className="rounded-lg overflow-hidden mb-8">
            <img 
              src={tool.imageUrl} 
              alt={tool.name}
              className="w-full h-auto"
            />
          </div>
        )}
        
        {/* Tabs for tool details */}
        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-1 md:grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="reviews">
              Reviews ({reviews.length})
            </TabsTrigger>
            <TabsTrigger value="alternatives">Alternatives</TabsTrigger>
          </TabsList>
          
          {/* Overview tab */}
          <TabsContent value="overview" className="space-y-6 py-4">
            <div className="prose prose-lg max-w-none dark:prose-invert">
              <h2 className="text-2xl font-bold mb-4">About {tool.name}</h2>
              <p>{tool.description}</p>
              
              {/* Additional details */}
              {(tool.features || tool.useCases || tool.pricing) && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                  {tool.features && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg">Key Features</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="list-disc pl-5 space-y-1">
                          {tool.features.map((feature: string, index: number) => (
                            <li key={index} className="text-sm">{feature}</li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  )}
                  
                  {tool.useCases && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg">Use Cases</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="list-disc pl-5 space-y-1">
                          {tool.useCases.map((useCase: string, index: number) => (
                            <li key={index} className="text-sm">{useCase}</li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  )}
                  
                  {tool.pricing && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg">Pricing Plans</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="list-disc pl-5 space-y-1">
                          {tool.pricing.map((plan: string, index: number) => (
                            <li key={index} className="text-sm">{plan}</li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
              
              {/* Pro/Cons */}
              {(tool.pros || tool.cons) && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                  {tool.pros && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg text-green-600">Pros</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {tool.pros.map((pro: string, index: number) => (
                            <li key={index} className="flex items-start gap-2">
                              <Check className="h-5 w-5 text-green-500 mt-0.5" />
                              <span>{pro}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  )}
                  
                  {tool.cons && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg text-red-600">Cons</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {tool.cons.map((con: string, index: number) => (
                            <li key={index} className="flex items-start gap-2">
                              <X className="h-5 w-5 text-red-500 mt-0.5" />
                              <span>{con}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
              
              {tool.website && (
                <div className="mt-8">
                  <Button 
                    onClick={() => window.open(tool.website, '_blank')}
                    size="lg"
                    className="gap-2"
                  >
                    <ExternalLink className="h-4 w-4" />
                    Visit {tool.name} Website
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>
          
          {/* Reviews tab */}
          <TabsContent value="reviews" className="space-y-6 py-4">
            <div className="grid grid-cols-1 md:grid-cols-[1fr_300px] gap-8">
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">User Reviews</h2>
                
                {/* Write review section */}
                {isAuthenticated ? (
                  <Card>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <h3 className="text-lg font-medium mb-2">Write a review</h3>
                          <div className="mb-4">{renderSelectableStars()}</div>
                          <Textarea 
                            placeholder="Share your experience with this tool..." 
                            value={reviewContent}
                            onChange={(e) => setReviewContent(e.target.value)}
                            className="min-h-[100px]"
                          />
                        </div>
                        <Button 
                          onClick={handleSubmitReview} 
                          disabled={selectedRating === 0 || !reviewContent}
                        >
                          Submit Review
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <Card>
                    <CardContent className="py-6">
                      <p className="text-center text-muted-foreground mb-4">
                        Please sign in to write a review
                      </p>
                      <Button 
                        onClick={() => navigate('/login')}
                        className="w-full"
                      >
                        Sign in to Review
                      </Button>
                    </CardContent>
                  </Card>
                )}
                
                {/* Reviews list */}
                {reviews.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <MessageSquare className="h-12 w-12 mx-auto opacity-20 mb-2" />
                    <p>No reviews yet. Be the first to share your experience!</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {reviews.map((review) => (
                      <Card key={review.id}>
                        <CardContent className="p-6">
                          <div className="flex justify-between items-start">
                            <div className="flex items-center gap-3">
                              <Avatar>
                                <AvatarFallback>
                                  {review.user ? getUserInitials(review.user) : "?"}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">
                                  {review.user?.username || "Anonymous User"}
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  {formatDate(review.createdAt)}
                                </div>
                              </div>
                            </div>
                            <div className="flex">{renderStars(review.rating)}</div>
                          </div>
                          <p className="mt-4">{review.content}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Rating summary */}
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Rating Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between mb-6">
                      <div className="text-4xl font-bold">
                        {tool.averageRating ? tool.averageRating.toFixed(1) : "0.0"}
                      </div>
                      <div>{renderStars(tool.averageRating || 0)}</div>
                    </div>
                    
                    <div className="space-y-3">
                      {ratingDistribution.map((count, index) => (
                        <div key={5 - index} className="flex items-center gap-2">
                          <div className="w-16 text-sm">{5 - index} stars</div>
                          <Progress value={getRatingPercentage(count)} className="h-2 flex-1" />
                          <div className="w-10 text-xs text-right">
                            {count}
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="text-sm text-muted-foreground mt-4 text-center">
                      Based on {reviews.length} reviews
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
          
          {/* Alternatives tab */}
          <TabsContent value="alternatives" className="py-4">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Alternatives to {tool.name}</h2>
              
              {relatedTools.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No alternatives found in this category.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {relatedTools.map((relatedTool) => (
                    <Card key={relatedTool.id} className="overflow-hidden">
                      <div className="aspect-video relative overflow-hidden">
                        <img 
                          src={relatedTool.imageUrl || "https://placehold.co/600x400/f5f5f5/666666?text=No+Image"} 
                          alt={relatedTool.name}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-2 right-2">
                          <Badge className={getPriceModelColor(relatedTool.priceModel)}>
                            {formatPriceModel(relatedTool.priceModel)}
                          </Badge>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h3 
                          className="text-lg font-medium mb-1 cursor-pointer hover:underline"
                          onClick={() => navigate(`/tool/${relatedTool.id}`)}
                        >
                          {relatedTool.name}
                        </h3>
                        <div className="flex items-center gap-1 mb-2">
                          {renderStars(relatedTool.averageRating || 0)}
                          <span className="text-sm ml-1">
                            ({relatedTool.averageRating?.toFixed(1) || "0.0"})
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-3 mb-3">
                          {relatedTool.description}
                        </p>
                        <Button 
                          size="sm" 
                          className="w-full"
                          onClick={() => navigate(`/tool/${relatedTool.id}`)}
                        >
                          View Details
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
              
              {category && (
                <div className="mt-4 text-center">
                  <Button 
                    variant="outline"
                    onClick={() => navigate(`/tools?category=${category.id}`)}
                  >
                    See all {category.name} tools
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}