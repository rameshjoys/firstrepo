import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useSelector } from "react-redux";
import { RootState } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Separator } from "@/components/ui/separator";
import { Star, Plus, Filter, Search, Grid, List, BarChart3, Check, ExternalLink, Heart, Share2, BarChart2, DollarSign, Tag, Laptop, X } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function Tools() {
  const [, navigate] = useLocation();
  const { user } = useSelector((state: RootState) => state.auth);
  const [tools, setTools] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [subcategories, setSubcategories] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [sortBy, setSortBy] = useState("newest");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedSubcategories, setSelectedSubcategories] = useState<number[]>([]);
  const [priceFilters, setPriceFilters] = useState<string[]>([]);
  const [minRating, setMinRating] = useState(0);
  const [compareList, setCompareList] = useState<number[]>([]);
  const [showFilters, setShowFilters] = useState(false);

  // Check if user is admin
  const isAdmin = user?.role === 'admin' || user?.role === 'superadmin';
  const MAX_COMPARE = 5; // Maximum number of tools to compare

  // Fetch tools, categories, and subcategories
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Fetch tools
        const toolsResponse = await fetch('/api/tools');
        if (toolsResponse.ok) {
          const toolsData = await toolsResponse.json();
          setTools(toolsData);
        }

        // Fetch categories
        const categoriesResponse = await fetch('/api/categories');
        if (categoriesResponse.ok) {
          const categoriesData = await categoriesResponse.json();
          setCategories(categoriesData);
        }

        // Fetch subcategories
        const subcategoriesResponse = await fetch('/api/subcategories');
        if (subcategoriesResponse.ok) {
          const subcategoriesData = await subcategoriesResponse.json();
          setSubcategories(subcategoriesData);
        }

      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // If needed, you can fetch filtered tools from API
  };

  // Handle category selection
  const handleCategoryChange = (value: string) => {
    const categoryId = value ? parseInt(value) : null;
    setSelectedCategory(categoryId);
    // Reset subcategories if category changes
    setSelectedSubcategories([]);
  };

  // Handle subcategory selection
  const handleSubcategoryChange = (value: string) => {
    const subcategoryId = parseInt(value);
    setSelectedSubcategories(prev => 
      prev.includes(subcategoryId)
        ? prev.filter(id => id !== subcategoryId)
        : [...prev, subcategoryId]
    );
  };

  // Handle price filter selection
  const handlePriceFilterChange = (value: string) => {
    setPriceFilters(prev => 
      prev.includes(value)
        ? prev.filter(filter => filter !== value)
        : [...prev, value]
    );
  };

  // Add or remove tool from comparison list
  const handleCompareToggle = (toolId: number) => {
    setCompareList(prev => 
      prev.includes(toolId)
        ? prev.filter(id => id !== toolId)
        : prev.length < MAX_COMPARE 
          ? [...prev, toolId] 
          : prev
    );
  };

  // Navigate to comparison page
  const goToComparison = () => {
    if (compareList.length > 1) {
      navigate(`/compare?tools=${compareList.join(',')}`);
    }
  };

  // Reset all filters
  const resetFilters = () => {
    setSearchQuery("");
    setSelectedCategory(null);
    setSelectedSubcategories([]);
    setPriceFilters([]);
    setMinRating(0);
    setSortBy("newest");
  };

  // Get subcategories for selected category
  const filteredSubcategories = selectedCategory
    ? subcategories.filter(subcat => subcat.categoryId === selectedCategory)
    : subcategories;

  // Format a price model string
  const formatPriceModel = (priceModel: string) => {
    switch (priceModel) {
      case 'free': return 'Free';
      case 'freemium': return 'Freemium';
      case 'paid': return 'Paid';
      case 'enterprise': return 'Enterprise';
      default: return priceModel;
    }
  };

  // Filter and sort tools
  const filteredTools = tools
    .filter(tool => {
      // Search query filter
      const matchesSearch = searchQuery === "" || 
        tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (tool.description && tool.description.toLowerCase().includes(searchQuery.toLowerCase()));
      
      // Category filter
      const matchesCategory = selectedCategory === null || tool.categoryId === selectedCategory;
      
      // Subcategory filter
      const matchesSubcategory = selectedSubcategories.length === 0 || 
        (tool.subcategoryIds && tool.subcategoryIds.some((id: number) => selectedSubcategories.includes(id)));
      
      // Price filter
      const matchesPrice = priceFilters.length === 0 || 
        priceFilters.includes(tool.priceModel);
      
      // Rating filter
      const matchesRating = tool.averageRating >= minRating;
      
      return matchesSearch && matchesCategory && matchesSubcategory && matchesPrice && matchesRating;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case 'oldest':
          return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        case 'name_asc':
          return a.name.localeCompare(b.name);
        case 'name_desc':
          return b.name.localeCompare(a.name);
        case 'rating_desc':
          return b.averageRating - a.averageRating;
        case 'popular':
          return b.viewCount - a.viewCount;
        default:
          return 0;
      }
    });

  // Get category name by ID
  const getCategoryName = (categoryId: number) => {
    const category = categories.find(c => c.id === categoryId);
    return category ? category.name : '';
  };

  // Render star rating
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    
    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(<Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />);
      } else if (i === fullStars + 1 && halfStar) {
        stars.push(<Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400 fill-[50%]" />);
      } else {
        stars.push(<Star key={i} className="h-4 w-4 text-muted-foreground" />);
      }
    }
    
    return (
      <div className="flex items-center">
        <div className="flex mr-1">{stars}</div>
        <span className="text-sm text-muted-foreground">({rating.toFixed(1)})</span>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tools Directory</h1>
          <p className="text-muted-foreground">
            Discover and compare the best tools for your business
          </p>
        </div>
        
        {isAdmin && (
          <Button onClick={() => navigate('/tool/new')}>
            <Plus className="h-4 w-4 mr-2" />
            Add Tool
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6">
        {/* Filters Sidebar (Desktop) */}
        <div className="hidden lg:block space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium">Filters</CardTitle>
              <CardDescription>
                Narrow down your search
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="space-y-1.5">
                <Label className="text-base">Category</Label>
                <Select
                  value={selectedCategory?.toString() || ""}
                  onValueChange={handleCategoryChange}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem 
                        key={category.id} 
                        value={category.id.toString()}
                      >
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {filteredSubcategories.length > 0 && (
                <div className="space-y-3">
                  <Label className="text-base">Subcategories</Label>
                  <ScrollArea className="h-[180px] rounded-md border p-2">
                    <div className="space-y-2">
                      {filteredSubcategories.map((subcategory) => (
                        <div key={subcategory.id} className="flex items-center space-x-2">
                          <Checkbox 
                            id={`subcat-${subcategory.id}`}
                            checked={selectedSubcategories.includes(subcategory.id)}
                            onCheckedChange={() => handleSubcategoryChange(subcategory.id.toString())}
                          />
                          <Label 
                            htmlFor={`subcat-${subcategory.id}`}
                            className="text-sm font-normal"
                          >
                            {subcategory.name}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              )}
              
              <div className="space-y-3">
                <Label className="text-base">Price</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="price-free"
                      checked={priceFilters.includes('free')}
                      onCheckedChange={() => handlePriceFilterChange('free')}
                    />
                    <Label 
                      htmlFor="price-free"
                      className="text-sm font-normal"
                    >
                      Free
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="price-freemium"
                      checked={priceFilters.includes('freemium')}
                      onCheckedChange={() => handlePriceFilterChange('freemium')}
                    />
                    <Label 
                      htmlFor="price-freemium"
                      className="text-sm font-normal"
                    >
                      Freemium
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="price-paid"
                      checked={priceFilters.includes('paid')}
                      onCheckedChange={() => handlePriceFilterChange('paid')}
                    />
                    <Label 
                      htmlFor="price-paid"
                      className="text-sm font-normal"
                    >
                      Paid
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="price-enterprise"
                      checked={priceFilters.includes('enterprise')}
                      onCheckedChange={() => handlePriceFilterChange('enterprise')}
                    />
                    <Label 
                      htmlFor="price-enterprise"
                      className="text-sm font-normal"
                    >
                      Enterprise
                    </Label>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between">
                  <Label className="text-base">Minimum Rating</Label>
                  <span className="text-sm text-muted-foreground">{minRating}/5</span>
                </div>
                <Slider
                  value={[minRating]}
                  min={0}
                  max={5}
                  step={0.5}
                  onValueChange={(value) => setMinRating(value[0])}
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>0</span>
                  <span>1</span>
                  <span>2</span>
                  <span>3</span>
                  <span>4</span>
                  <span>5</span>
                </div>
              </div>
              
              <Button 
                variant="outline" 
                className="w-full"
                onClick={resetFilters}
              >
                Reset Filters
              </Button>
            </CardContent>
          </Card>
          
          {compareList.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Comparison</CardTitle>
                <CardDescription>
                  {compareList.length} of {MAX_COMPARE} tools selected
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {compareList.map(toolId => {
                  const tool = tools.find(t => t.id === toolId);
                  return tool ? (
                    <div key={tool.id} className="flex justify-between items-center">
                      <span className="text-sm truncate max-w-[180px]">{tool.name}</span>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => handleCompareToggle(tool.id)}
                      >
                        <X className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </div>
                  ) : null;
                })}
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full" 
                  disabled={compareList.length < 2}
                  onClick={goToComparison}
                >
                  <BarChart2 className="h-4 w-4 mr-2" />
                  Compare Tools
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
        
        {/* Main Content */}
        <div className="space-y-4">
          {/* Search and Controls */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <form onSubmit={handleSearch} className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search tools..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </form>
            </div>
            
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="icon"
                className="lg:hidden"
                onClick={() => setShowFilters(true)}
              >
                <Filter className="h-4 w-4" />
              </Button>
              
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="name_asc">Name (A-Z)</SelectItem>
                  <SelectItem value="name_desc">Name (Z-A)</SelectItem>
                  <SelectItem value="rating_desc">Highest Rated</SelectItem>
                  <SelectItem value="popular">Most Popular</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="hidden md:flex border rounded-md">
                <Button
                  variant={viewMode === "grid" ? "default" : "ghost"}
                  size="icon"
                  onClick={() => setViewMode("grid")}
                  className="rounded-r-none"
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Separator orientation="vertical" />
                <Button
                  variant={viewMode === "list" ? "default" : "ghost"}
                  size="icon"
                  onClick={() => setViewMode("list")}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          
          {/* Results info */}
          <div className="flex justify-between items-center text-sm text-muted-foreground">
            <div>
              Showing <strong>{filteredTools.length}</strong> of <strong>{tools.length}</strong> tools
            </div>
            {(selectedCategory !== null || selectedSubcategories.length > 0 || priceFilters.length > 0 || minRating > 0) && (
              <Button 
                variant="link" 
                className="h-auto p-0" 
                onClick={resetFilters}
              >
                Clear All Filters
              </Button>
            )}
          </div>
          
          {/* Mobile Filters Dialog */}
          <Dialog open={showFilters} onOpenChange={setShowFilters}>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Filter Tools</DialogTitle>
                <DialogDescription>
                  Narrow down your search results
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-5 py-4 max-h-[70vh] overflow-y-auto">
                <div className="space-y-1.5">
                  <Label className="text-base">Category</Label>
                  <Select
                    value={selectedCategory?.toString() || ""}
                    onValueChange={handleCategoryChange}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All Categories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Categories</SelectItem>
                      {categories.map((category) => (
                        <SelectItem 
                          key={category.id} 
                          value={category.id.toString()}
                        >
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                {filteredSubcategories.length > 0 && (
                  <div className="space-y-3">
                    <Label className="text-base">Subcategories</Label>
                    <div className="space-y-2 max-h-[180px] overflow-y-auto rounded-md border p-2">
                      {filteredSubcategories.map((subcategory) => (
                        <div key={subcategory.id} className="flex items-center space-x-2">
                          <Checkbox 
                            id={`mobile-subcat-${subcategory.id}`}
                            checked={selectedSubcategories.includes(subcategory.id)}
                            onCheckedChange={() => handleSubcategoryChange(subcategory.id.toString())}
                          />
                          <Label 
                            htmlFor={`mobile-subcat-${subcategory.id}`}
                            className="text-sm font-normal"
                          >
                            {subcategory.name}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="space-y-3">
                  <Label className="text-base">Price</Label>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="mobile-price-free"
                        checked={priceFilters.includes('free')}
                        onCheckedChange={() => handlePriceFilterChange('free')}
                      />
                      <Label 
                        htmlFor="mobile-price-free"
                        className="text-sm font-normal"
                      >
                        Free
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="mobile-price-freemium"
                        checked={priceFilters.includes('freemium')}
                        onCheckedChange={() => handlePriceFilterChange('freemium')}
                      />
                      <Label 
                        htmlFor="mobile-price-freemium"
                        className="text-sm font-normal"
                      >
                        Freemium
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="mobile-price-paid"
                        checked={priceFilters.includes('paid')}
                        onCheckedChange={() => handlePriceFilterChange('paid')}
                      />
                      <Label 
                        htmlFor="mobile-price-paid"
                        className="text-sm font-normal"
                      >
                        Paid
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="mobile-price-enterprise"
                        checked={priceFilters.includes('enterprise')}
                        onCheckedChange={() => handlePriceFilterChange('enterprise')}
                      />
                      <Label 
                        htmlFor="mobile-price-enterprise"
                        className="text-sm font-normal"
                      >
                        Enterprise
                      </Label>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <Label className="text-base">Minimum Rating</Label>
                    <span className="text-sm text-muted-foreground">{minRating}/5</span>
                  </div>
                  <Slider
                    value={[minRating]}
                    min={0}
                    max={5}
                    step={0.5}
                    onValueChange={(value) => setMinRating(value[0])}
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>0</span>
                    <span>1</span>
                    <span>2</span>
                    <span>3</span>
                    <span>4</span>
                    <span>5</span>
                  </div>
                </div>
              </div>
              <DialogFooter className="flex flex-col sm:flex-row gap-2">
                <Button 
                  variant="outline" 
                  className="sm:flex-1"
                  onClick={resetFilters}
                >
                  Reset Filters
                </Button>
                <Button 
                  className="sm:flex-1"
                  onClick={() => setShowFilters(false)}
                >
                  Apply Filters
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          {/* Tools Grid/List View */}
          {isLoading ? (
            <div className="flex justify-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : filteredTools.length === 0 ? (
            <Card className="py-12">
              <CardContent className="flex flex-col items-center text-center px-4">
                <Laptop className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">No tools found</h3>
                <p className="text-muted-foreground mb-6 max-w-md">
                  We couldn't find any tools matching your filters. Try adjusting your search criteria or browse all tools.
                </p>
                <Button onClick={resetFilters}>View All Tools</Button>
              </CardContent>
            </Card>
          ) : viewMode === "grid" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredTools.map((tool) => (
                <Card key={tool.id} className="overflow-hidden">
                  <div className="relative overflow-hidden aspect-video">
                    <img 
                      src={tool.imageUrl || "https://placehold.co/600x400/f5f5f5/666666?text=No+Image"} 
                      alt={tool.name}
                      className="w-full h-full object-cover transition-transform hover:scale-105"
                    />
                    <div className="absolute top-2 right-2 flex gap-1">
                      <Badge variant="outline" className="bg-black/70 text-white border-black/70">
                        {formatPriceModel(tool.priceModel)}
                      </Badge>
                    </div>
                  </div>
                  <CardHeader className="p-4 pb-0">
                    <CardTitle className="text-lg">
                      <div 
                        className="cursor-pointer hover:underline" 
                        onClick={() => navigate(`/tool/${tool.id}`)}
                      >
                        {tool.name}
                      </div>
                    </CardTitle>
                    <CardDescription className="line-clamp-2 h-10">
                      {tool.description || "No description available"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-4 pt-2">
                    <div className="flex justify-between items-center mb-3">
                      <Badge variant="secondary">
                        {getCategoryName(tool.categoryId)}
                      </Badge>
                      {renderStars(tool.averageRating || 0)}
                    </div>
                    <div className="flex justify-between">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => navigate(`/tool/${tool.id}`)}
                      >
                        View Details
                      </Button>
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="icon"
                              className={compareList.includes(tool.id) ? "bg-primary text-primary-foreground" : ""}
                              onClick={() => handleCompareToggle(tool.id)}
                              disabled={compareList.length >= MAX_COMPARE && !compareList.includes(tool.id)}
                            >
                              <BarChart3 className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            {compareList.includes(tool.id) 
                              ? "Remove from comparison" 
                              : compareList.length >= MAX_COMPARE 
                                ? `Maximum ${MAX_COMPARE} tools for comparison`
                                : "Add to comparison"}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredTools.map((tool) => (
                <Card key={tool.id} className="overflow-hidden">
                  <div className="flex flex-col sm:flex-row">
                    <div className="relative overflow-hidden sm:w-48 h-40 sm:h-auto">
                      <img 
                        src={tool.imageUrl || "https://placehold.co/600x400/f5f5f5/666666?text=No+Image"} 
                        alt={tool.name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-2 right-2">
                        <Badge variant="outline" className="bg-black/70 text-white border-black/70">
                          {formatPriceModel(tool.priceModel)}
                        </Badge>
                      </div>
                    </div>
                    <div className="p-4 flex-1 flex flex-col">
                      <div className="flex justify-between items-start mb-1">
                        <h3 
                          className="text-lg font-medium cursor-pointer hover:underline"
                          onClick={() => navigate(`/tool/${tool.id}`)}
                        >
                          {tool.name}
                        </h3>
                        <div className="flex items-center">
                          {renderStars(tool.averageRating || 0)}
                        </div>
                      </div>
                      <div className="mb-2">
                        <Badge variant="secondary">
                          {getCategoryName(tool.categoryId)}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground line-clamp-2 flex-1 mb-4">
                        {tool.description || "No description available"}
                      </p>
                      <div className="flex justify-between items-center mt-auto">
                        <div className="flex gap-2">
                          <Button 
                            variant="default" 
                            size="sm"
                            onClick={() => navigate(`/tool/${tool.id}`)}
                          >
                            View Details
                          </Button>
                          
                          {tool.website && (
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => window.open(tool.website, '_blank')}
                            >
                              <ExternalLink className="h-4 w-4 mr-1" />
                              Visit Website
                            </Button>
                          )}
                        </div>
                        
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button 
                                variant="outline" 
                                size="icon"
                                className={compareList.includes(tool.id) ? "bg-primary text-primary-foreground" : ""}
                                onClick={() => handleCompareToggle(tool.id)}
                                disabled={compareList.length >= MAX_COMPARE && !compareList.includes(tool.id)}
                              >
                                <BarChart3 className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              {compareList.includes(tool.id) 
                                ? "Remove from comparison" 
                                : compareList.length >= MAX_COMPARE 
                                  ? `Maximum ${MAX_COMPARE} tools for comparison`
                                  : "Add to comparison"}
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
          
          {/* Comparison Footer */}
          {compareList.length > 0 && (
            <div className="fixed bottom-0 left-0 w-full bg-background border-t shadow-md p-4 lg:hidden">
              <div className="container mx-auto">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-medium">Compare Tools</h4>
                    <p className="text-sm text-muted-foreground">
                      {compareList.length} of {MAX_COMPARE} selected
                    </p>
                  </div>
                  <Button 
                    onClick={goToComparison}
                    disabled={compareList.length < 2}
                  >
                    <BarChart2 className="h-4 w-4 mr-2" />
                    Compare
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}