import { Request, Response, NextFunction } from 'express';
import session from 'express-session';
import passport from 'passport';
import { Strategy as LocalStrategy } from 'passport-local';
import { pool } from './db';
import MemoryStore from 'memorystore';
import { storage } from './storage';
import * as bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { sendVerificationEmail } from './mail';
import { User } from '@shared/schema';

// Create memory store for sessions
const MemoryStoreSession = MemoryStore(session);

// Configure passport local strategy
passport.use(new LocalStrategy(
  { usernameField: 'email' },
  async (email, password, done) => {
    try {
      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        return done(null, false, { message: 'Incorrect email or password' });
      }

      // Check if user is verified
      if (!user.isVerified) {
        return done(null, false, { message: 'Please verify your email before logging in' });
      }
      
      // Verify password
      const isValid = await bcrypt.compare(password, user.password);
      
      if (!isValid) {
        return done(null, false, { message: 'Incorrect email or password' });
      }
      
      return done(null, user);
    } catch (err) {
      return done(err);
    }
  }
));

// Serialize and deserialize user
passport.serializeUser((user: User, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id: number, done) => {
  try {
    const user = await storage.getUser(id);
    done(null, user);
  } catch (err) {
    done(err);
  }
});

// Configure session middleware
export const configureAuth = (app: any) => {
  app.use(session({
    cookie: { maxAge: 86400000 }, // 24 hours
    store: new MemoryStoreSession({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    resave: false,
    saveUninitialized: false,
    secret: process.env.SESSION_SECRET || 'toolbloghub-secret'
  }));
  
  app.use(passport.initialize());
  app.use(passport.session());
};

// Authentication middleware
export const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: 'Authentication required' });
};

// Role-based access control middleware
export const hasRole = (roles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    const user = req.user as User;
    
    if (!user || !roles.includes(user.role)) {
      return res.status(403).json({ message: 'You do not have permission to access this resource' });
    }
    
    next();
  };
};

// Generate verification code
export const generateVerificationCode = (): string => {
  return crypto.randomBytes(32).toString('hex');
};

// Send verification email
export const generateAndSendVerificationCode = async (user: User): Promise<string> => {
  const verificationCode = generateVerificationCode();
  
  // Save verification code to database
  await storage.createVerificationCode({
    userId: user.id,
    code: verificationCode
  });
  
  // Send verification email
  await sendVerificationEmail(user.email, user.username, verificationCode);
  
  return verificationCode;
};
