// Application configuration
interface SMTPConfig {
  host: string;
  port: number;
  secure: boolean;
  user: string;
  password: string;
  from: string;
}

interface Config {
  appName: string;
  appUrl: string;
  defaultTheme: 'dark' | 'light' | 'system';
  maxToolsComparison: number;
  smtp: SMTPConfig;
}

// Get environment-specific configuration
export function getConfig(): Config {
  const environment = process.env.NODE_ENV || 'development';
  
  // Common configuration across environments
  const commonConfig: Config = {
    appName: process.env.APP_NAME || 'ToolBlogHub',
    appUrl: process.env.APP_URL || 'http://localhost:5000',
    defaultTheme: (process.env.DEFAULT_THEME as 'dark' | 'light' | 'system') || 'system',
    maxToolsComparison: Number(process.env.MAX_TOOLS_COMPARISON) || 5,
    smtp: {
      host: process.env.SMTP_HOST || 'smtp.example.com',
      port: Number(process.env.SMTP_PORT) || 587,
      secure: process.env.SMTP_SECURE === 'true',
      user: process.env.SMTP_USER || 'user@example.com',
      password: process.env.SMTP_PASSWORD || 'password',
      from: process.env.SMTP_FROM || 'noreply@toolbloghub.com'
    }
  };
  
  // Environment-specific overrides
  const environmentConfigs: Record<string, Partial<Config>> = {
    development: {
      // Development-specific config
    },
    test: {
      // Test-specific config
    },
    production: {
      // Production-specific config
    }
  };
  
  return {
    ...commonConfig,
    ...(environmentConfigs[environment] || {})
  };
}
