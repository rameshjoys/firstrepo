import nodemailer from 'nodemailer';
import { getConfig } from './config';

// Get mail configuration from environment variables
const config = getConfig();

// Create transport
let transporter: nodemailer.Transporter;

if (process.env.NODE_ENV === 'production') {
  // Production - use SMTP
  transporter = nodemailer.createTransport({
    host: config.smtp.host,
    port: config.smtp.port,
    secure: config.smtp.secure,
    auth: {
      user: config.smtp.user,
      pass: config.smtp.password
    }
  });
} else {
  // Development - use console transport
  transporter = {
    sendMail: async (options: any) => {
      console.log('---- Development Email ----');
      console.log('To:', options.to);
      console.log('Subject:', options.subject);
      console.log('Text:', options.text);
      console.log('HTML:', options.html);
      console.log('---------------------------');
      return { messageId: 'development-email-' + Date.now() };
    }
  } as any;
}

// Send verification email
export async function sendVerificationEmail(email: string, username: string, verificationCode: string): Promise<void> {
  const baseUrl = config.appUrl || 'http://localhost:5000';
  const verifyUrl = `${baseUrl}/verify-email?code=${verificationCode}`;
  
  const mailOptions = {
    from: `"${config.appName}" <${config.smtp.from}>`,
    to: email,
    subject: `Verify your email for ${config.appName}`,
    text: `
      Hi ${username},
      
      Thank you for registering with ${config.appName}. Please verify your email address by clicking on the link below:
      
      ${verifyUrl}
      
      This link will expire in 24 hours.
      
      If you did not create an account, you can safely ignore this email.
      
      Regards,
      The ${config.appName} Team
    `,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #7c3aed; padding: 20px; text-align: center; color: white;">
          <h1>${config.appName}</h1>
        </div>
        <div style="padding: 20px; border: 1px solid #e5e7eb; border-top: none;">
          <p>Hi ${username},</p>
          <p>Thank you for registering with ${config.appName}. Please verify your email address by clicking on the link below:</p>
          <p style="text-align: center; margin: 30px 0;">
            <a href="${verifyUrl}" style="background-color: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">Verify Email</a>
          </p>
          <p>This link will expire in 24 hours.</p>
          <p>If you did not create an account, you can safely ignore this email.</p>
          <p>Regards,<br>The ${config.appName} Team</p>
        </div>
        <div style="background-color: #f9fafb; padding: 10px; text-align: center; font-size: 12px; color: #6b7280;">
          <p>&copy; ${new Date().getFullYear()} ${config.appName}. All rights reserved.</p>
        </div>
      </div>
    `
  };
  
  await transporter.sendMail(mailOptions);
}

// Send password reset email
export async function sendPasswordResetEmail(email: string, username: string, resetCode: string): Promise<void> {
  const baseUrl = config.appUrl || 'http://localhost:5000';
  const resetUrl = `${baseUrl}/reset-password?code=${resetCode}`;
  
  const mailOptions = {
    from: `"${config.appName}" <${config.smtp.from}>`,
    to: email,
    subject: `Reset your password for ${config.appName}`,
    text: `
      Hi ${username},
      
      We received a request to reset your password. Click on the link below to reset your password:
      
      ${resetUrl}
      
      This link will expire in 24 hours.
      
      If you did not request a password reset, you can safely ignore this email.
      
      Regards,
      The ${config.appName} Team
    `,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #7c3aed; padding: 20px; text-align: center; color: white;">
          <h1>${config.appName}</h1>
        </div>
        <div style="padding: 20px; border: 1px solid #e5e7eb; border-top: none;">
          <p>Hi ${username},</p>
          <p>We received a request to reset your password. Click on the link below to reset your password:</p>
          <p style="text-align: center; margin: 30px 0;">
            <a href="${resetUrl}" style="background-color: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">Reset Password</a>
          </p>
          <p>This link will expire in 24 hours.</p>
          <p>If you did not request a password reset, you can safely ignore this email.</p>
          <p>Regards,<br>The ${config.appName} Team</p>
        </div>
        <div style="background-color: #f9fafb; padding: 10px; text-align: center; font-size: 12px; color: #6b7280;">
          <p>&copy; ${new Date().getFullYear()} ${config.appName}. All rights reserved.</p>
        </div>
      </div>
    `
  };
  
  await transporter.sendMail(mailOptions);
}
