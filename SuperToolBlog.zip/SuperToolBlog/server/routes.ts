import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { configureAuth, isAuthenticated, hasRole, generateAndSendVerificationCode } from "./auth";
import passport from "passport";
import { 
  userSchema, insertUserSchema, loginSchema, 
  toolSchema, insertToolSchema, updateToolSchema,
  categorySchema, insertCategorySchema, updateCategorySchema,
  subcategorySchema, insertSubcategorySchema, updateSubcategorySchema,
  blogSchema, insertBlogSchema, updateBlogSchema,
  commentSchema, insertCommentSchema,
  reviewSchema, insertReviewSchema, 
  verifyEmailSchema
} from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { optimizeSEO } from "./seo";
import { parse as csvParse } from 'csv-parse/sync';
import * as fs from 'fs';
import multer from 'multer';
import path from 'path';
import { getConfig } from "./config";

// Configure upload storage
const storage_upload = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.resolve('uploads');
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage_upload,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    // Accept CSV files or images
    if (file.fieldname === 'csv' && file.mimetype === 'text/csv') {
      cb(null, true);
    } else if (file.fieldname === 'image' && file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  configureAuth(app);

  // Get application configuration
  const config = getConfig();

  // API routes prefix
  const API_PREFIX = '/api';

  // Helper for error responses
  const handleApiError = (res: Response, error: any) => {
    console.error('API Error:', error);
    
    if (error instanceof ZodError) {
      return res.status(400).json({ 
        message: 'Validation error', 
        errors: error.errors
      });
    }
    
    const status = error.status || 500;
    const message = error.message || 'Internal server error';
    
    return res.status(status).json({ message });
  };

  // Authentication endpoints
  app.post(`${API_PREFIX}/auth/login`, async (req, res, next) => {
    try {
      const data = loginSchema.parse(req.body);
      
      passport.authenticate('local', (err: any, user: any, info: any) => {
        if (err) return next(err);
        if (!user) return res.status(401).json({ message: info.message });
        
        req.logIn(user, (err) => {
          if (err) return next(err);
          
          // Return safe user object (omit password)
          const { password, ...safeUser } = user;
          return res.json({ user: safeUser });
        });
      })(req, res, next);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.post(`${API_PREFIX}/auth/signup`, async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      
      // Check if email is already in use
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(400).json({ message: 'Email is already in use' });
      }
      
      // Check if username is already in use
      const existingUsername = await storage.getUserByUsername(data.username);
      if (existingUsername) {
        return res.status(400).json({ message: 'Username is already in use' });
      }
      
      // Create new user (defaults to 'user' role if not specified)
      const roleToUse = data.role || 'user';
      
      const newUser = await storage.createUser({
        ...data,
        role: roleToUse,
        isVerified: false
      });
      
      // Generate and send verification code
      await generateAndSendVerificationCode(newUser);
      
      // Return safe user object (omit password)
      const { password, ...safeUser } = newUser;
      
      res.status(201).json({ 
        user: safeUser,
        message: 'Registration successful. Please check your email to verify your account.'
      });
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.post(`${API_PREFIX}/auth/verify-email`, async (req, res) => {
    try {
      const { userId, code } = verifyEmailSchema.parse(req.body);
      
      // Check if verification code is valid
      const verificationCode = await storage.getVerificationCode(userId, code);
      
      if (!verificationCode) {
        return res.status(400).json({ message: 'Invalid verification code' });
      }
      
      // Mark user as verified
      const user = await storage.updateUser(userId, { isVerified: true });
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Delete verification code
      await storage.deleteVerificationCode(verificationCode.id);
      
      // Return safe user object (omit password)
      const { password, ...safeUser } = user;
      
      res.json({ 
        user: safeUser,
        message: 'Email verified successfully. You can now login.'
      });
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.post(`${API_PREFIX}/auth/logout`, (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: 'Failed to logout' });
      }
      res.json({ message: 'Logged out successfully' });
    });
  });

  app.get(`${API_PREFIX}/auth/me`, isAuthenticated, (req, res) => {
    const { password, ...user } = req.user as any;
    res.json({ user });
  });

  // User management (Admin & SuperAdmin only)
  app.get(`${API_PREFIX}/users`, isAuthenticated, hasRole(['admin', 'superadmin']), async (req, res) => {
    try {
      const users = await storage.getUsers();
      
      // Remove passwords from response
      const safeUsers = users.map(user => {
        const { password, ...safeUser } = user;
        return safeUser;
      });
      
      res.json(safeUsers);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.get(`${API_PREFIX}/users/:id`, isAuthenticated, hasRole(['admin', 'superadmin']), async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Remove password from response
      const { password, ...safeUser } = user;
      
      res.json(safeUser);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.post(`${API_PREFIX}/users`, isAuthenticated, hasRole(['admin', 'superadmin']), async (req, res) => {
    try {
      const currentUser = req.user as any;
      const data = insertUserSchema.parse(req.body);
      
      // Super admin can create any user, admin can only create regular users
      if (currentUser.role === 'admin' && data.role === 'superadmin') {
        return res.status(403).json({ message: 'You do not have permission to create super admin users' });
      }
      
      // Check if email is already in use
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(400).json({ message: 'Email is already in use' });
      }
      
      // Check if username is already in use
      const existingUsername = await storage.getUserByUsername(data.username);
      if (existingUsername) {
        return res.status(400).json({ message: 'Username is already in use' });
      }
      
      const newUser = await storage.createUser({
        ...data,
        isVerified: true // Users created by admins are automatically verified
      });
      
      // Return safe user object (omit password)
      const { password, ...safeUser } = newUser;
      
      res.status(201).json(safeUser);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.put(`${API_PREFIX}/users/:id`, isAuthenticated, hasRole(['admin', 'superadmin']), async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const currentUser = req.user as any;
      const data = userSchema.partial().parse(req.body);
      
      // Get user to update
      const userToUpdate = await storage.getUser(userId);
      
      if (!userToUpdate) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Admin cannot modify super admin users
      if (currentUser.role === 'admin' && userToUpdate.role === 'superadmin') {
        return res.status(403).json({ message: 'You do not have permission to modify super admin users' });
      }
      
      // Admin cannot change user role to super admin
      if (currentUser.role === 'admin' && data.role === 'superadmin') {
        return res.status(403).json({ message: 'You do not have permission to promote users to super admin' });
      }
      
      const updatedUser = await storage.updateUser(userId, data);
      
      if (!updatedUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Return safe user object (omit password)
      const { password, ...safeUser } = updatedUser;
      
      res.json(safeUser);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.delete(`${API_PREFIX}/users/:id`, isAuthenticated, hasRole(['superadmin']), async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const currentUser = req.user as any;
      
      // Users cannot delete themselves
      if (userId === currentUser.id) {
        return res.status(400).json({ message: 'You cannot delete your own account' });
      }
      
      const success = await storage.deleteUser(userId);
      
      if (!success) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      res.json({ message: 'User deleted successfully' });
    } catch (error) {
      handleApiError(res, error);
    }
  });

  // Tool management
  app.get(`${API_PREFIX}/tools`, async (req, res) => {
    try {
      const { search, categoryId, subcategoryId, priceModel, sort } = req.query;
      
      const filters: any = {};
      
      if (search) filters.search = search as string;
      if (categoryId) filters.categoryId = parseInt(categoryId as string);
      if (subcategoryId) filters.subcategoryId = parseInt(subcategoryId as string);
      if (priceModel) filters.priceModel = priceModel as string;
      if (sort) filters.sort = sort as string;
      
      const tools = await storage.getTools(filters);
      
      res.json(tools);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.get(`${API_PREFIX}/tools/trending`, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const tools = await storage.getTrendingTools(limit);
      
      res.json(tools);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.get(`${API_PREFIX}/tools/most-rated`, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const tools = await storage.getMostRatedTools(limit);
      
      res.json(tools);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.get(`${API_PREFIX}/tools/:id`, async (req, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const tool = await storage.getTool(toolId);
      
      if (!tool) {
        return res.status(404).json({ message: 'Tool not found' });
      }
      
      // Increment view count
      await storage.updateTool(toolId, { viewCount: (tool.viewCount || 0) + 1 });
      
      res.json(tool);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.post(`${API_PREFIX}/tools`, isAuthenticated, hasRole(['admin', 'superadmin']), async (req, res) => {
    try {
      const data = insertToolSchema.parse(req.body);
      const newTool = await storage.createTool(data);
      
      res.status(201).json(newTool);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.put(`${API_PREFIX}/tools/:id`, isAuthenticated, hasRole(['admin', 'superadmin']), async (req, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const data = updateToolSchema.parse(req.body);
      
      const updatedTool = await storage.updateTool(toolId, data);
      
      if (!updatedTool) {
        return res.status(404).json({ message: 'Tool not found' });
      }
      
      res.json(updatedTool);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.delete(`${API_PREFIX}/tools/:id`, isAuthenticated, hasRole(['superadmin']), async (req, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const success = await storage.deleteTool(toolId);
      
      if (!success) {
        return res.status(404).json({ message: 'Tool not found' });
      }
      
      res.json({ message: 'Tool deleted successfully' });
    } catch (error) {
      handleApiError(res, error);
    }
  });

  // CSV upload for tools
  app.post(
    `${API_PREFIX}/tools/import-csv`,
    isAuthenticated, 
    hasRole(['admin', 'superadmin']),
    upload.single('csv'),
    async (req, res) => {
      try {
        if (!req.file) {
          return res.status(400).json({ message: 'No file uploaded' });
        }
        
        const csvFile = req.file;
        const csvData = fs.readFileSync(csvFile.path, 'utf8');
        
        // Parse CSV
        const records = csvParse(csvData, {
          columns: true,
          skip_empty_lines: true
        });
        
        const results = {
          success: 0,
          failed: 0,
          errors: [] as string[]
        };
        
        // Process each record
        for (const record of records) {
          try {
            // Map CSV record to tool data
            const toolData = {
              name: record.name,
              description: record.description,
              website: record.website,
              categoryId: parseInt(record.categoryId),
              subcategoryId: record.subcategoryId ? parseInt(record.subcategoryId) : null,
              priceModel: record.priceModel,
              features: record.features ? record.features.split(',').map((f: string) => f.trim()) : [],
              imageUrl: record.imageUrl || null
            };
            
            // Validate data
            insertToolSchema.parse(toolData);
            
            // Create tool
            await storage.createTool(toolData);
            
            results.success++;
          } catch (error) {
            results.failed++;
            results.errors.push(`Row ${results.success + results.failed}: ${error instanceof Error ? error.message : 'Unknown error'}`);
          }
        }
        
        // Delete the temporary file
        fs.unlinkSync(csvFile.path);
        
        res.json(results);
      } catch (error) {
        handleApiError(res, error);
      }
    }
  );

  // Get CSV template
  app.get(`${API_PREFIX}/tools/csv-template`, (req, res) => {
    const templatePath = path.resolve('./uploads/tool-template.csv');
    
    // Create template file if it doesn't exist
    if (!fs.existsSync(templatePath)) {
      const template = 'name,description,website,categoryId,subcategoryId,priceModel,features,imageUrl\n' +
                       'Example Tool,This is an example tool description,https://example.com,1,,freemium,"Feature 1,Feature 2,Feature 3",https://example.com/image.jpg';
      
      // Create directory if it doesn't exist
      const dir = path.dirname(templatePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      fs.writeFileSync(templatePath, template);
    }
    
    res.download(templatePath, 'tool-template.csv');
  });

  // Category management
  app.get(`${API_PREFIX}/categories`, async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.get(`${API_PREFIX}/categories/:id`, async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      const category = await storage.getCategory(categoryId);
      
      if (!category) {
        return res.status(404).json({ message: 'Category not found' });
      }
      
      res.json(category);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.post(`${API_PREFIX}/categories`, isAuthenticated, hasRole(['admin', 'superadmin']), async (req, res) => {
    try {
      const data = insertCategorySchema.parse(req.body);
      const newCategory = await storage.createCategory(data);
      
      res.status(201).json(newCategory);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.put(`${API_PREFIX}/categories/:id`, isAuthenticated, hasRole(['admin', 'superadmin']), async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      const data = updateCategorySchema.parse(req.body);
      
      const updatedCategory = await storage.updateCategory(categoryId, data);
      
      if (!updatedCategory) {
        return res.status(404).json({ message: 'Category not found' });
      }
      
      res.json(updatedCategory);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.delete(`${API_PREFIX}/categories/:id`, isAuthenticated, hasRole(['superadmin']), async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      const success = await storage.deleteCategory(categoryId);
      
      if (!success) {
        return res.status(404).json({ message: 'Category not found' });
      }
      
      res.json({ message: 'Category deleted successfully' });
    } catch (error) {
      handleApiError(res, error);
    }
  });

  // Subcategory management
  app.get(`${API_PREFIX}/subcategories`, async (req, res) => {
    try {
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
      const subcategories = await storage.getSubcategories(categoryId);
      
      res.json(subcategories);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.get(`${API_PREFIX}/subcategories/:id`, async (req, res) => {
    try {
      const subcategoryId = parseInt(req.params.id);
      const subcategory = await storage.getSubcategory(subcategoryId);
      
      if (!subcategory) {
        return res.status(404).json({ message: 'Subcategory not found' });
      }
      
      res.json(subcategory);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.post(`${API_PREFIX}/subcategories`, isAuthenticated, hasRole(['admin', 'superadmin']), async (req, res) => {
    try {
      const data = insertSubcategorySchema.parse(req.body);
      const newSubcategory = await storage.createSubcategory(data);
      
      res.status(201).json(newSubcategory);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.put(`${API_PREFIX}/subcategories/:id`, isAuthenticated, hasRole(['admin', 'superadmin']), async (req, res) => {
    try {
      const subcategoryId = parseInt(req.params.id);
      const data = updateSubcategorySchema.parse(req.body);
      
      const updatedSubcategory = await storage.updateSubcategory(subcategoryId, data);
      
      if (!updatedSubcategory) {
        return res.status(404).json({ message: 'Subcategory not found' });
      }
      
      res.json(updatedSubcategory);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.delete(`${API_PREFIX}/subcategories/:id`, isAuthenticated, hasRole(['superadmin']), async (req, res) => {
    try {
      const subcategoryId = parseInt(req.params.id);
      const success = await storage.deleteSubcategory(subcategoryId);
      
      if (!success) {
        return res.status(404).json({ message: 'Subcategory not found' });
      }
      
      res.json({ message: 'Subcategory deleted successfully' });
    } catch (error) {
      handleApiError(res, error);
    }
  });

  // Blog management
  app.get(`${API_PREFIX}/blogs`, async (req, res) => {
    try {
      const { search, categoryId, authorId, status, sort } = req.query;
      
      const filters: any = {};
      
      if (search) filters.search = search as string;
      if (categoryId) filters.categoryId = parseInt(categoryId as string);
      if (authorId) filters.authorId = parseInt(authorId as string);
      if (status) filters.status = status as string;
      if (sort) filters.sort = sort as string;
      
      // If not authenticated, only show published blogs
      if (!req.isAuthenticated()) {
        filters.status = 'published';
      }
      
      const blogs = await storage.getBlogs(filters);
      
      res.json(blogs);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.get(`${API_PREFIX}/blogs/trending`, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const blogs = await storage.getTrendingBlogs(limit);
      
      res.json(blogs);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.get(`${API_PREFIX}/blogs/:id`, async (req, res) => {
    try {
      const blogId = parseInt(req.params.id);
      const blog = await storage.getBlog(blogId);
      
      if (!blog) {
        return res.status(404).json({ message: 'Blog not found' });
      }
      
      // Non-authenticated users can only view published blogs
      if (!req.isAuthenticated() && blog.status !== 'published') {
        return res.status(404).json({ message: 'Blog not found' });
      }
      
      // Users can only view their own drafts
      if (req.isAuthenticated() && blog.status !== 'published') {
        const user = req.user as any;
        
        if (blog.authorId !== user.id && user.role !== 'admin' && user.role !== 'superadmin') {
          return res.status(403).json({ message: 'You do not have permission to view this blog' });
        }
      }
      
      // Increment view count
      await storage.updateBlog(blogId, { viewCount: (blog.viewCount || 0) + 1 });
      
      res.json(blog);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.post(`${API_PREFIX}/blogs`, isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const data = insertBlogSchema.parse(req.body);
      
      const newBlog = await storage.createBlog({
        ...data,
        authorId: user.id
      });
      
      res.status(201).json(newBlog);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.put(`${API_PREFIX}/blogs/:id`, isAuthenticated, async (req, res) => {
    try {
      const blogId = parseInt(req.params.id);
      const data = updateBlogSchema.parse(req.body);
      const user = req.user as any;
      
      // Get the blog
      const blog = await storage.getBlog(blogId);
      
      if (!blog) {
        return res.status(404).json({ message: 'Blog not found' });
      }
      
      // Check if user has permission to update blog
      if (blog.authorId !== user.id && user.role !== 'admin' && user.role !== 'superadmin') {
        return res.status(403).json({ message: 'You do not have permission to update this blog' });
      }
      
      const updatedBlog = await storage.updateBlog(blogId, data);
      
      res.json(updatedBlog);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.delete(`${API_PREFIX}/blogs/:id`, isAuthenticated, async (req, res) => {
    try {
      const blogId = parseInt(req.params.id);
      const user = req.user as any;
      
      // Get the blog
      const blog = await storage.getBlog(blogId);
      
      if (!blog) {
        return res.status(404).json({ message: 'Blog not found' });
      }
      
      // Check if user has permission to delete blog
      if (blog.authorId !== user.id && user.role !== 'admin' && user.role !== 'superadmin') {
        return res.status(403).json({ message: 'You do not have permission to delete this blog' });
      }
      
      const success = await storage.deleteBlog(blogId);
      
      res.json({ message: 'Blog deleted successfully' });
    } catch (error) {
      handleApiError(res, error);
    }
  });

  // SEO optimization
  app.post(`${API_PREFIX}/seo/optimize`, isAuthenticated, async (req, res) => {
    try {
      const { type, id, content } = req.body;
      
      if (!['blog', 'tool'].includes(type)) {
        return res.status(400).json({ message: 'Invalid content type' });
      }
      
      if (!id) {
        return res.status(400).json({ message: 'ID is required' });
      }
      
      // Get entity to optimize
      let entity;
      if (type === 'blog') {
        entity = await storage.getBlog(id);
      } else if (type === 'tool') {
        entity = await storage.getTool(id);
      }
      
      if (!entity) {
        return res.status(404).json({ message: `${type} not found` });
      }
      
      // Get content to optimize
      const contentToOptimize = content || (type === 'blog' ? entity.content : entity.description);
      
      // Optimize SEO
      const optimizationResult = await optimizeSEO(type, entity.name || entity.title, contentToOptimize);
      
      res.json(optimizationResult);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  // Comment management
  app.get(`${API_PREFIX}/comments`, async (req, res) => {
    try {
      const { entityId, entityType } = req.query;
      
      if (!entityId || !entityType) {
        return res.status(400).json({ message: 'Entity ID and type are required' });
      }
      
      const comments = await storage.getComments(
        parseInt(entityId as string),
        entityType as string
      );
      
      res.json(comments);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.post(`${API_PREFIX}/comments`, isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const data = insertCommentSchema.parse(req.body);
      
      const newComment = await storage.createComment({
        ...data,
        userId: user.id
      });
      
      res.status(201).json(newComment);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.put(`${API_PREFIX}/comments/:id`, isAuthenticated, async (req, res) => {
    try {
      const commentId = parseInt(req.params.id);
      const { content } = req.body;
      const user = req.user as any;
      
      // Get the comment
      const comment = await storage.getComment(commentId);
      
      if (!comment) {
        return res.status(404).json({ message: 'Comment not found' });
      }
      
      // Check if user has permission to update comment
      if (comment.userId !== user.id && user.role !== 'admin' && user.role !== 'superadmin') {
        return res.status(403).json({ message: 'You do not have permission to update this comment' });
      }
      
      const updatedComment = await storage.updateComment(commentId, { content });
      
      res.json(updatedComment);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.delete(`${API_PREFIX}/comments/:id`, isAuthenticated, async (req, res) => {
    try {
      const commentId = parseInt(req.params.id);
      const user = req.user as any;
      
      // Get the comment
      const comment = await storage.getComment(commentId);
      
      if (!comment) {
        return res.status(404).json({ message: 'Comment not found' });
      }
      
      // Check if user has permission to delete comment
      if (comment.userId !== user.id && user.role !== 'admin' && user.role !== 'superadmin') {
        return res.status(403).json({ message: 'You do not have permission to delete this comment' });
      }
      
      const success = await storage.deleteComment(commentId);
      
      res.json({ message: 'Comment deleted successfully' });
    } catch (error) {
      handleApiError(res, error);
    }
  });

  // Review management
  app.get(`${API_PREFIX}/reviews`, async (req, res) => {
    try {
      const { toolId } = req.query;
      
      if (!toolId) {
        return res.status(400).json({ message: 'Tool ID is required' });
      }
      
      const reviews = await storage.getReviews(parseInt(toolId as string));
      
      res.json(reviews);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.post(`${API_PREFIX}/reviews`, isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const data = insertReviewSchema.parse(req.body);
      
      // Check if user has already reviewed this tool
      const toolId = data.toolId;
      const reviews = await storage.getReviews(toolId);
      const existingReview = reviews.find(review => review.userId === user.id);
      
      if (existingReview) {
        return res.status(400).json({ message: 'You have already reviewed this tool' });
      }
      
      const newReview = await storage.createReview({
        ...data,
        userId: user.id
      });
      
      res.status(201).json(newReview);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.put(`${API_PREFIX}/reviews/:id`, isAuthenticated, async (req, res) => {
    try {
      const reviewId = parseInt(req.params.id);
      const data = insertReviewSchema.partial().parse(req.body);
      const user = req.user as any;
      
      // Get the review
      const review = await storage.getReview(reviewId);
      
      if (!review) {
        return res.status(404).json({ message: 'Review not found' });
      }
      
      // Check if user has permission to update review
      if (review.userId !== user.id && user.role !== 'admin' && user.role !== 'superadmin') {
        return res.status(403).json({ message: 'You do not have permission to update this review' });
      }
      
      const updatedReview = await storage.updateReview(reviewId, data);
      
      res.json(updatedReview);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.delete(`${API_PREFIX}/reviews/:id`, isAuthenticated, async (req, res) => {
    try {
      const reviewId = parseInt(req.params.id);
      const user = req.user as any;
      
      // Get the review
      const review = await storage.getReview(reviewId);
      
      if (!review) {
        return res.status(404).json({ message: 'Review not found' });
      }
      
      // Check if user has permission to delete review
      if (review.userId !== user.id && user.role !== 'admin' && user.role !== 'superadmin') {
        return res.status(403).json({ message: 'You do not have permission to delete this review' });
      }
      
      const success = await storage.deleteReview(reviewId);
      
      res.json({ message: 'Review deleted successfully' });
    } catch (error) {
      handleApiError(res, error);
    }
  });

  // Tool comparison
  app.get(`${API_PREFIX}/comparison`, isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const comparison = await storage.getToolComparison(user.id);
      
      if (!comparison) {
        return res.json({ toolIds: [] });
      }
      
      res.json(comparison);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.post(`${API_PREFIX}/comparison`, isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const { toolIds } = req.body;
      
      // Validate tool IDs
      if (!Array.isArray(toolIds) || toolIds.length === 0 || toolIds.length > 5) {
        return res.status(400).json({ message: 'Tool IDs must be an array with 1-5 items' });
      }
      
      // Check if user already has a comparison
      const existingComparison = await storage.getToolComparison(user.id);
      
      let comparison;
      if (existingComparison) {
        comparison = await storage.updateToolComparison(existingComparison.id, toolIds);
      } else {
        comparison = await storage.createToolComparison({
          userId: user.id,
          toolIds
        });
      }
      
      res.json(comparison);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.put(`${API_PREFIX}/comparison/:id`, isAuthenticated, async (req, res) => {
    try {
      const comparisonId = parseInt(req.params.id);
      const { toolIds } = req.body;
      const user = req.user as any;
      
      // Validate tool IDs
      if (!Array.isArray(toolIds) || toolIds.length === 0 || toolIds.length > 5) {
        return res.status(400).json({ message: 'Tool IDs must be an array with 1-5 items' });
      }
      
      // Get the comparison
      const comparison = await storage.getToolComparison(user.id);
      
      if (!comparison || comparison.id !== comparisonId) {
        return res.status(404).json({ message: 'Comparison not found' });
      }
      
      // Update comparison
      const updatedComparison = await storage.updateToolComparison(comparisonId, toolIds);
      
      res.json(updatedComparison);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  app.delete(`${API_PREFIX}/comparison/:id`, isAuthenticated, async (req, res) => {
    try {
      const comparisonId = parseInt(req.params.id);
      const user = req.user as any;
      
      // Get the comparison
      const comparison = await storage.getToolComparison(user.id);
      
      if (!comparison || comparison.id !== comparisonId) {
        return res.status(404).json({ message: 'Comparison not found' });
      }
      
      const success = await storage.deleteToolComparison(comparisonId);
      
      res.json({ message: 'Comparison deleted successfully' });
    } catch (error) {
      handleApiError(res, error);
    }
  });

  // Application configuration
  app.get(`${API_PREFIX}/config`, async (req, res) => {
    try {
      const publicConfig = {
        appName: config.appName,
        defaultTheme: config.defaultTheme,
        maxToolsComparison: config.maxToolsComparison
      };
      
      res.json(publicConfig);
    } catch (error) {
      handleApiError(res, error);
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
