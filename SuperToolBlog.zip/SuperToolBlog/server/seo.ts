import { Groq } from 'groq-sdk';

interface SEOOptimizationResult {
  title: string;
  description: string;
  keywords: string[];
  openGraph: {
    title: string;
    description: string;
  };
  twitter: {
    title: string;
    description: string;
  };
  suggestions: string[];
}

// Initialize Groq client
const apiKey = process.env.GROQ_API_KEY || '';
const groq = new Groq({ apiKey });

// Optimize content for SEO
export async function optimizeSEO(
  type: 'blog' | 'tool',
  title: string,
  content: string
): Promise<SEOOptimizationResult> {
  try {
    // Create a prompt for Groq
    const prompt = `
    You are an SEO expert. I need you to optimize the following ${type} content for search engines.
    
    Title: ${title}
    
    Content: 
    ${content.slice(0, 2000)}${content.length > 2000 ? '...' : ''}
    
    Please provide the following in valid JSON format:
    1. An optimized SEO title (max 60 characters)
    2. An optimized meta description (max 160 characters)
    3. 5-10 relevant keywords or phrases for this content
    4. Optimized Open Graph title and description for social media sharing
    5. Optimized Twitter title and description
    6. 3-5 suggestions to improve the content for better SEO
    
    Your response should be in this JSON structure:
    {
      "title": "Optimized SEO title",
      "description": "Optimized meta description",
      "keywords": ["keyword1", "keyword2", "..."],
      "openGraph": {
        "title": "Open Graph title",
        "description": "Open Graph description"
      },
      "twitter": {
        "title": "Twitter title",
        "description": "Twitter description"
      },
      "suggestions": ["suggestion1", "suggestion2", "..."]
    }
    `;

    // Call Groq API
    const response = await groq.chat.completions.create({
      model: 'llama3-70b-8192',
      messages: [
        {
          role: 'system',
          content: 'You are an SEO expert that optimizes content for search engines.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.3,
      max_tokens: 1500
    });

    // Parse the response
    const result = JSON.parse(response.choices[0].message.content || '{}');

    // Return formatted result
    return {
      title: result.title || title,
      description: result.description || '',
      keywords: result.keywords || [],
      openGraph: result.openGraph || { title: title, description: '' },
      twitter: result.twitter || { title: title, description: '' },
      suggestions: result.suggestions || []
    };
  } catch (error) {
    console.error('SEO optimization error:', error);
    
    // Return default values if optimization fails
    return {
      title: title,
      description: content.slice(0, 160),
      keywords: [],
      openGraph: {
        title: title,
        description: content.slice(0, 160)
      },
      twitter: {
        title: title,
        description: content.slice(0, 160)
      },
      suggestions: ['Enable Groq API for SEO optimization']
    };
  }
}
