import { 
  users, tools, categories, subcategories, toolSubcategories, blogs, comments, reviews, 
  verificationCodes, toolComparisons,
  type User, type InsertUser, type Tool, type InsertTool, 
  type Category, type InsertCategory, type Subcategory, type InsertSubcategory,
  type Blog, type InsertBlog, type Comment, type InsertComment, 
  type Review, type InsertReview, type VerificationCode, type InsertVerificationCode, 
  type ToolComparison, type InsertToolComparison
} from "@shared/schema";
import { db } from "./db";
import { eq, and, inArray, like, desc, sql, isNull, or } from "drizzle-orm";
import * as bcrypt from "bcryptjs";

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<Omit<User, "id">>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getUsers(): Promise<User[]>;
  getUsersByRole(role: string): Promise<User[]>;

  // Tool operations
  getTool(id: number): Promise<Tool | undefined>;
  getTools(filters?: {
    search?: string;
    categoryId?: number;
    subcategoryId?: number;
    priceModel?: string;
    sort?: string;
  }): Promise<Tool[]>;
  createTool(tool: InsertTool): Promise<Tool>;
  updateTool(id: number, data: Partial<Omit<Tool, "id">>): Promise<Tool | undefined>;
  deleteTool(id: number): Promise<boolean>;
  getToolsByCategory(categoryId: number): Promise<Tool[]>;
  getTrendingTools(limit?: number): Promise<Tool[]>;
  getMostRatedTools(limit?: number): Promise<Tool[]>;

  // Category operations
  getCategory(id: number): Promise<Category | undefined>;
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, data: Partial<Omit<Category, "id">>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;

  // Subcategory operations
  getSubcategory(id: number): Promise<Subcategory | undefined>;
  getSubcategories(categoryId?: number): Promise<Subcategory[]>;
  createSubcategory(subcategory: InsertSubcategory): Promise<Subcategory>;
  updateSubcategory(id: number, data: Partial<Omit<Subcategory, "id">>): Promise<Subcategory | undefined>;
  deleteSubcategory(id: number): Promise<boolean>;

  // Blog operations
  getBlog(id: number): Promise<Blog | undefined>;
  getBlogs(filters?: {
    search?: string;
    categoryId?: number;
    authorId?: number;
    status?: string;
    sort?: string;
  }): Promise<Blog[]>;
  createBlog(blog: InsertBlog): Promise<Blog>;
  updateBlog(id: number, data: Partial<Omit<Blog, "id">>): Promise<Blog | undefined>;
  deleteBlog(id: number): Promise<boolean>;
  getTrendingBlogs(limit?: number): Promise<Blog[]>;

  // Comment operations
  getComment(id: number): Promise<Comment | undefined>;
  getComments(entityId: number, entityType: string): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  updateComment(id: number, data: Partial<Omit<Comment, "id">>): Promise<Comment | undefined>;
  deleteComment(id: number): Promise<boolean>;

  // Review operations
  getReview(id: number): Promise<Review | undefined>;
  getReviews(toolId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  updateReview(id: number, data: Partial<Omit<Review, "id">>): Promise<Review | undefined>;
  deleteReview(id: number): Promise<boolean>;
  getAverageRating(toolId: number): Promise<number>;

  // Verification Code operations
  createVerificationCode(code: InsertVerificationCode): Promise<VerificationCode>;
  getVerificationCode(userId: number, code: string): Promise<VerificationCode | undefined>;
  deleteVerificationCode(id: number): Promise<boolean>;

  // Tool Comparison operations
  getToolComparison(userId: number): Promise<ToolComparison | undefined>;
  createToolComparison(comparison: InsertToolComparison): Promise<ToolComparison>;
  updateToolComparison(id: number, toolIds: number[]): Promise<ToolComparison | undefined>;
  deleteToolComparison(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    // Hash password before storing
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        password: hashedPassword,
        createdAt: new Date()
      })
      .returning();
    return user;
  }

  async updateUser(id: number, data: Partial<Omit<User, "id">>): Promise<User | undefined> {
    if (data.password) {
      data.password = await bcrypt.hash(data.password, 10);
    }
    
    const [updatedUser] = await db
      .update(users)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return true;
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(users.createdAt);
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role));
  }

  // Tool operations
  async getTool(id: number): Promise<Tool | undefined> {
    const [tool] = await db.select().from(tools).where(eq(tools.id, id));
    return tool;
  }

  async getTools(filters?: {
    search?: string;
    categoryId?: number;
    subcategoryId?: number;
    priceModel?: string;
    sort?: string;
  }): Promise<Tool[]> {
    let query = db.select().from(tools);
    
    if (filters) {
      // Apply filters
      if (filters.search) {
        query = query.where(
          or(
            like(tools.name, `%${filters.search}%`),
            like(tools.description, `%${filters.search}%`)
          )
        );
      }
      
      if (filters.categoryId) {
        query = query.where(eq(tools.categoryId, filters.categoryId));
      }
      
      if (filters.priceModel) {
        query = query.where(eq(tools.priceModel, filters.priceModel));
      }
      
      // Apply sorting
      if (filters.sort) {
        switch (filters.sort) {
          case 'trending':
            query = query.orderBy(desc(tools.viewCount));
            break;
          case 'latest':
            query = query.orderBy(desc(tools.updatedAt));
            break;
          case 'rating':
            query = query.orderBy(desc(tools.averageRating));
            break;
          case 'name':
            query = query.orderBy(tools.name);
            break;
          default:
            query = query.orderBy(desc(tools.createdAt));
        }
      } else {
        query = query.orderBy(desc(tools.createdAt));
      }
    } else {
      query = query.orderBy(desc(tools.createdAt));
    }
    
    return await query;
  }

  async createTool(toolData: InsertTool): Promise<Tool> {
    const [tool] = await db
      .insert(tools)
      .values({
        ...toolData,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return tool;
  }

  async updateTool(id: number, data: Partial<Omit<Tool, "id">>): Promise<Tool | undefined> {
    const [updatedTool] = await db
      .update(tools)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(tools.id, id))
      .returning();
    return updatedTool;
  }

  async deleteTool(id: number): Promise<boolean> {
    await db.delete(tools).where(eq(tools.id, id));
    return true;
  }

  async getToolsByCategory(categoryId: number): Promise<Tool[]> {
    return await db
      .select()
      .from(tools)
      .where(eq(tools.categoryId, categoryId))
      .orderBy(desc(tools.createdAt));
  }

  async getTrendingTools(limit: number = 10): Promise<Tool[]> {
    return await db
      .select()
      .from(tools)
      .orderBy(desc(tools.viewCount))
      .limit(limit);
  }

  async getMostRatedTools(limit: number = 10): Promise<Tool[]> {
    return await db
      .select()
      .from(tools)
      .orderBy(desc(tools.averageRating))
      .limit(limit);
  }

  // Category operations
  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category;
  }

  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(categories.name);
  }

  async createCategory(categoryData: InsertCategory): Promise<Category> {
    const [category] = await db
      .insert(categories)
      .values({
        ...categoryData,
        createdAt: new Date()
      })
      .returning();
    return category;
  }

  async updateCategory(id: number, data: Partial<Omit<Category, "id">>): Promise<Category | undefined> {
    const [updatedCategory] = await db
      .update(categories)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(categories.id, id))
      .returning();
    return updatedCategory;
  }

  async deleteCategory(id: number): Promise<boolean> {
    await db.delete(categories).where(eq(categories.id, id));
    return true;
  }

  // Subcategory operations
  async getSubcategory(id: number): Promise<Subcategory | undefined> {
    const [subcategory] = await db.select().from(subcategories).where(eq(subcategories.id, id));
    return subcategory;
  }

  async getSubcategories(categoryId?: number): Promise<Subcategory[]> {
    if (categoryId) {
      return await db
        .select()
        .from(subcategories)
        .where(eq(subcategories.categoryId, categoryId))
        .orderBy(subcategories.name);
    }
    return await db.select().from(subcategories).orderBy(subcategories.name);
  }

  async createSubcategory(subcategoryData: InsertSubcategory): Promise<Subcategory> {
    const [subcategory] = await db
      .insert(subcategories)
      .values({
        ...subcategoryData,
        createdAt: new Date()
      })
      .returning();
    return subcategory;
  }

  async updateSubcategory(id: number, data: Partial<Omit<Subcategory, "id">>): Promise<Subcategory | undefined> {
    const [updatedSubcategory] = await db
      .update(subcategories)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(subcategories.id, id))
      .returning();
    return updatedSubcategory;
  }

  async deleteSubcategory(id: number): Promise<boolean> {
    await db.delete(subcategories).where(eq(subcategories.id, id));
    return true;
  }

  // Blog operations
  async getBlog(id: number): Promise<Blog | undefined> {
    const [blog] = await db.select().from(blogs).where(eq(blogs.id, id));
    return blog;
  }

  async getBlogs(filters?: {
    search?: string;
    categoryId?: number;
    authorId?: number;
    status?: string;
    sort?: string;
  }): Promise<Blog[]> {
    let query = db.select().from(blogs);
    
    if (filters) {
      // Apply filters
      if (filters.search) {
        query = query.where(
          or(
            like(blogs.title, `%${filters.search}%`),
            like(blogs.content, `%${filters.search}%`)
          )
        );
      }
      
      if (filters.categoryId) {
        query = query.where(eq(blogs.categoryId, filters.categoryId));
      }
      
      if (filters.authorId) {
        query = query.where(eq(blogs.authorId, filters.authorId));
      }
      
      if (filters.status) {
        query = query.where(eq(blogs.status, filters.status));
      }
      
      // Apply sorting
      if (filters.sort) {
        switch (filters.sort) {
          case 'trending':
            query = query.orderBy(desc(blogs.viewCount));
            break;
          case 'latest':
            query = query.orderBy(desc(blogs.updatedAt));
            break;
          default:
            query = query.orderBy(desc(blogs.createdAt));
        }
      } else {
        query = query.orderBy(desc(blogs.createdAt));
      }
    } else {
      query = query.orderBy(desc(blogs.createdAt));
    }
    
    return await query;
  }

  async createBlog(blogData: InsertBlog): Promise<Blog> {
    const [blog] = await db
      .insert(blogs)
      .values({
        ...blogData,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return blog;
  }

  async updateBlog(id: number, data: Partial<Omit<Blog, "id">>): Promise<Blog | undefined> {
    const [updatedBlog] = await db
      .update(blogs)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(blogs.id, id))
      .returning();
    return updatedBlog;
  }

  async deleteBlog(id: number): Promise<boolean> {
    await db.delete(blogs).where(eq(blogs.id, id));
    return true;
  }

  async getTrendingBlogs(limit: number = 10): Promise<Blog[]> {
    return await db
      .select()
      .from(blogs)
      .where(eq(blogs.status, 'published'))
      .orderBy(desc(blogs.viewCount))
      .limit(limit);
  }

  // Comment operations
  async getComment(id: number): Promise<Comment | undefined> {
    const [comment] = await db.select().from(comments).where(eq(comments.id, id));
    return comment;
  }

  async getComments(entityId: number, entityType: string): Promise<Comment[]> {
    return await db
      .select()
      .from(comments)
      .where(
        and(
          eq(comments.entityId, entityId),
          eq(comments.entityType, entityType)
        )
      )
      .orderBy(desc(comments.createdAt));
  }

  async createComment(commentData: InsertComment): Promise<Comment> {
    const [comment] = await db
      .insert(comments)
      .values({
        ...commentData,
        createdAt: new Date()
      })
      .returning();
    return comment;
  }

  async updateComment(id: number, data: Partial<Omit<Comment, "id">>): Promise<Comment | undefined> {
    const [updatedComment] = await db
      .update(comments)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(comments.id, id))
      .returning();
    return updatedComment;
  }

  async deleteComment(id: number): Promise<boolean> {
    await db.delete(comments).where(eq(comments.id, id));
    return true;
  }

  // Review operations
  async getReview(id: number): Promise<Review | undefined> {
    const [review] = await db.select().from(reviews).where(eq(reviews.id, id));
    return review;
  }

  async getReviews(toolId: number): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.toolId, toolId))
      .orderBy(desc(reviews.createdAt));
  }

  async createReview(reviewData: InsertReview): Promise<Review> {
    const [review] = await db
      .insert(reviews)
      .values({
        ...reviewData,
        createdAt: new Date()
      })
      .returning();
    
    // Update the tool's average rating
    await this.updateToolAverageRating(reviewData.toolId);
    
    return review;
  }

  async updateReview(id: number, data: Partial<Omit<Review, "id">>): Promise<Review | undefined> {
    const [updatedReview] = await db
      .update(reviews)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(reviews.id, id))
      .returning();
    
    if (updatedReview) {
      // Update the tool's average rating
      await this.updateToolAverageRating(updatedReview.toolId);
    }
    
    return updatedReview;
  }

  async deleteReview(id: number): Promise<boolean> {
    const [review] = await db.select().from(reviews).where(eq(reviews.id, id));
    
    if (review) {
      await db.delete(reviews).where(eq(reviews.id, id));
      // Update the tool's average rating after deletion
      await this.updateToolAverageRating(review.toolId);
      return true;
    }
    
    return false;
  }

  async getAverageRating(toolId: number): Promise<number> {
    const result = await db
      .select({
        averageRating: sql`AVG(${reviews.rating})`.mapWith(Number)
      })
      .from(reviews)
      .where(eq(reviews.toolId, toolId));
    
    return result[0]?.averageRating || 0;
  }

  private async updateToolAverageRating(toolId: number): Promise<void> {
    const averageRating = await this.getAverageRating(toolId);
    
    await db
      .update(tools)
      .set({ averageRating })
      .where(eq(tools.id, toolId));
  }

  // Verification Code operations
  async createVerificationCode(codeData: InsertVerificationCode): Promise<VerificationCode> {
    const [code] = await db
      .insert(verificationCodes)
      .values({
        ...codeData,
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // Expires in 24 hours
      })
      .returning();
    return code;
  }

  async getVerificationCode(userId: number, code: string): Promise<VerificationCode | undefined> {
    const [verificationCode] = await db
      .select()
      .from(verificationCodes)
      .where(
        and(
          eq(verificationCodes.userId, userId),
          eq(verificationCodes.code, code),
          sql`${verificationCodes.expiresAt} > NOW()`
        )
      );
    return verificationCode;
  }

  async deleteVerificationCode(id: number): Promise<boolean> {
    await db.delete(verificationCodes).where(eq(verificationCodes.id, id));
    return true;
  }

  // Tool Comparison operations
  async getToolComparison(userId: number): Promise<ToolComparison | undefined> {
    const [comparison] = await db
      .select()
      .from(toolComparisons)
      .where(eq(toolComparisons.userId, userId));
    return comparison;
  }

  async createToolComparison(comparisonData: InsertToolComparison): Promise<ToolComparison> {
    const [comparison] = await db
      .insert(toolComparisons)
      .values({
        ...comparisonData,
        createdAt: new Date()
      })
      .returning();
    return comparison;
  }

  async updateToolComparison(id: number, toolIds: number[]): Promise<ToolComparison | undefined> {
    const [updatedComparison] = await db
      .update(toolComparisons)
      .set({
        toolIds,
        updatedAt: new Date()
      })
      .where(eq(toolComparisons.id, id))
      .returning();
    return updatedComparison;
  }

  async deleteToolComparison(id: number): Promise<boolean> {
    await db.delete(toolComparisons).where(eq(toolComparisons.id, id));
    return true;
  }
}

export const storage = new DatabaseStorage();
