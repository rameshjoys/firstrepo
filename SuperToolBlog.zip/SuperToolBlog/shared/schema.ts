import { pgTable, text, serial, integer, timestamp, boolean, json, pgEnum, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from 'drizzle-orm';

// Enum definitions
export const userRoleEnum = pgEnum('user_role', ['user', 'admin', 'superadmin']);
export const blogStatusEnum = pgEnum('blog_status', ['draft', 'published', 'scheduled']);
export const priceModelEnum = pgEnum('price_model', ['free', 'freemium', 'paid', 'enterprise']);

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  role: userRoleEnum("role").notNull().default('user'),
  isVerified: boolean("is_verified").notNull().default(false),
  avatar: text("avatar"),
  bio: text("bio"),
  createdAt: timestamp("created_at"),
  updatedAt: timestamp("updated_at"),
});

// Category schema
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at"),
  updatedAt: timestamp("updated_at"),
});

// Subcategory schema
export const subcategories = pgTable("subcategories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  categoryId: integer("category_id").notNull().references(() => categories.id),
  createdAt: timestamp("created_at"),
  updatedAt: timestamp("updated_at"),
});

// Tool schema
export const tools = pgTable("tools", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  website: text("website"),
  categoryId: integer("category_id").notNull().references(() => categories.id),
  subcategoryId: integer("subcategory_id").references(() => subcategories.id),
  priceModel: priceModelEnum("price_model").notNull(),
  priceDescription: text("price_description"),
  features: json("features").$type<string[]>(),
  imageUrl: text("image_url"),
  viewCount: integer("view_count").notNull().default(0),
  averageRating: integer("average_rating").notNull().default(0),
  createdAt: timestamp("created_at"),
  updatedAt: timestamp("updated_at"),
});

// Tool - Subcategory relation
export const toolSubcategories = pgTable("tool_subcategories", {
  id: serial("id").primaryKey(),
  toolId: integer("tool_id").notNull().references(() => tools.id),
  subcategoryId: integer("subcategory_id").notNull().references(() => subcategories.id),
});

// Blog schema
export const blogs = pgTable("blogs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  excerpt: text("excerpt"),
  status: blogStatusEnum("status").notNull().default('draft'),
  authorId: integer("author_id").notNull().references(() => users.id),
  categoryId: integer("category_id").references(() => categories.id),
  tags: json("tags").$type<string[]>(),
  featuredImageUrl: text("featured_image_url"),
  viewCount: integer("view_count").notNull().default(0),
  seoTitle: text("seo_title"),
  seoDescription: text("seo_description"),
  seoKeywords: json("seo_keywords").$type<string[]>(),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at"),
  updatedAt: timestamp("updated_at"),
});

// Comment schema
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  userId: integer("user_id").notNull().references(() => users.id),
  entityId: integer("entity_id").notNull(),
  entityType: text("entity_type").notNull(), // 'blog' or 'tool'
  createdAt: timestamp("created_at"),
  updatedAt: timestamp("updated_at"),
});

// Review schema
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  rating: integer("rating").notNull(),
  userId: integer("user_id").notNull().references(() => users.id),
  toolId: integer("tool_id").notNull().references(() => tools.id),
  createdAt: timestamp("created_at"),
  updatedAt: timestamp("updated_at"),
});

// Verification code schema
export const verificationCodes = pgTable("verification_codes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  code: text("code").notNull(),
  createdAt: timestamp("created_at"),
  expiresAt: timestamp("expires_at").notNull(),
});

// Tool comparison schema
export const toolComparisons = pgTable("tool_comparisons", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  toolIds: json("tool_ids").$type<number[]>().notNull(),
  createdAt: timestamp("created_at"),
  updatedAt: timestamp("updated_at"),
});

// Define relations between tables

export const usersRelations = relations(users, ({ many }) => ({
  blogs: many(blogs, { relationName: "author_blogs" }),
  comments: many(comments, { relationName: "user_comments" }),
  reviews: many(reviews, { relationName: "user_reviews" }),
  verificationCodes: many(verificationCodes, { relationName: "user_verification_codes" }),
  toolComparisons: many(toolComparisons, { relationName: "user_tool_comparisons" })
}));

export const toolsRelations = relations(tools, ({ one, many }) => ({
  category: one(categories, {
    fields: [tools.categoryId],
    references: [categories.id],
    relationName: "tool_category"
  }),
  subcategory: one(subcategories, {
    fields: [tools.subcategoryId],
    references: [subcategories.id],
    relationName: "tool_subcategory"
  }),
  toolSubcategories: many(toolSubcategories, { relationName: "tool_subcategory_relations" }),
  reviews: many(reviews, { relationName: "tool_reviews" })
}));

export const categoriesRelations = relations(categories, ({ many }) => ({
  tools: many(tools, { relationName: "category_tools" }),
  subcategories: many(subcategories, { relationName: "category_subcategories" }),
  blogs: many(blogs, { relationName: "category_blogs" })
}));

export const subcategoriesRelations = relations(subcategories, ({ one, many }) => ({
  category: one(categories, {
    fields: [subcategories.categoryId],
    references: [categories.id],
    relationName: "subcategory_category"
  }),
  tools: many(tools, { relationName: "subcategory_tools" }),
  toolSubcategories: many(toolSubcategories, { relationName: "subcategory_tool_relations" })
}));

export const toolSubcategoriesRelations = relations(toolSubcategories, ({ one }) => ({
  tool: one(tools, {
    fields: [toolSubcategories.toolId],
    references: [tools.id],
    relationName: "tool_subcategory_tool"
  }),
  subcategory: one(subcategories, {
    fields: [toolSubcategories.subcategoryId],
    references: [subcategories.id],
    relationName: "tool_subcategory_subcategory"
  })
}));

export const blogsRelations = relations(blogs, ({ one, many }) => ({
  author: one(users, {
    fields: [blogs.authorId],
    references: [users.id],
    relationName: "blog_author"
  }),
  category: one(categories, {
    fields: [blogs.categoryId],
    references: [categories.id],
    relationName: "blog_category"
  }),
  comments: many(comments, { relationName: "blog_comments" })
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  user: one(users, {
    fields: [comments.userId],
    references: [users.id],
    relationName: "comment_user"
  })
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  user: one(users, {
    fields: [reviews.userId],
    references: [users.id],
    relationName: "review_user"
  }),
  tool: one(tools, {
    fields: [reviews.toolId],
    references: [tools.id],
    relationName: "review_tool"
  })
}));

export const verificationCodesRelations = relations(verificationCodes, ({ one }) => ({
  user: one(users, {
    fields: [verificationCodes.userId],
    references: [users.id],
    relationName: "verification_code_user"
  })
}));

export const toolComparisonsRelations = relations(toolComparisons, ({ one }) => ({
  user: one(users, {
    fields: [toolComparisons.userId],
    references: [users.id],
    relationName: "tool_comparison_user"
  })
}));

// Zod schemas for validation
export const userSchema = createInsertSchema(users);
export const insertUserSchema = userSchema.omit({ id: true, createdAt: true, updatedAt: true });
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
});
export const verifyEmailSchema = z.object({
  userId: z.number(),
  code: z.string()
});

export const toolSchema = createInsertSchema(tools);
export const insertToolSchema = toolSchema.omit({ id: true, viewCount: true, averageRating: true, createdAt: true, updatedAt: true });
export const updateToolSchema = toolSchema.partial().omit({ id: true, createdAt: true });

export const categorySchema = createInsertSchema(categories);
export const insertCategorySchema = categorySchema.omit({ id: true, createdAt: true, updatedAt: true });
export const updateCategorySchema = categorySchema.partial().omit({ id: true, createdAt: true });

export const subcategorySchema = createInsertSchema(subcategories);
export const insertSubcategorySchema = subcategorySchema.omit({ id: true, createdAt: true, updatedAt: true });
export const updateSubcategorySchema = subcategorySchema.partial().omit({ id: true, createdAt: true });

export const blogSchema = createInsertSchema(blogs);
export const insertBlogSchema = blogSchema.omit({ id: true, authorId: true, viewCount: true, createdAt: true, updatedAt: true });
export const updateBlogSchema = blogSchema.partial().omit({ id: true, authorId: true, createdAt: true });

export const commentSchema = createInsertSchema(comments);
export const insertCommentSchema = commentSchema.omit({ id: true, userId: true, createdAt: true, updatedAt: true });

export const reviewSchema = createInsertSchema(reviews);
export const insertReviewSchema = reviewSchema.omit({ id: true, userId: true, createdAt: true, updatedAt: true });

export const verificationCodeSchema = createInsertSchema(verificationCodes);
export const insertVerificationCodeSchema = verificationCodeSchema.omit({ id: true, createdAt: true, expiresAt: true });

export const toolComparisonSchema = createInsertSchema(toolComparisons);
export const insertToolComparisonSchema = toolComparisonSchema.omit({ id: true, createdAt: true, updatedAt: true });

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Tool = typeof tools.$inferSelect;
export type InsertTool = z.infer<typeof insertToolSchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type Subcategory = typeof subcategories.$inferSelect;
export type InsertSubcategory = z.infer<typeof insertSubcategorySchema>;

export type Blog = typeof blogs.$inferSelect;
export type InsertBlog = z.infer<typeof insertBlogSchema>;

export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;

export type VerificationCode = typeof verificationCodes.$inferSelect;
export type InsertVerificationCode = z.infer<typeof insertVerificationCodeSchema>;

export type ToolComparison = typeof toolComparisons.$inferSelect;
export type InsertToolComparison = z.infer<typeof insertToolComparisonSchema>;